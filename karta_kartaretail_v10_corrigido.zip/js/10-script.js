
(function(){
  var IDLE_MS    = 12 * 60 * 60 * 1000; // 12 horas
  var WARN_MS    = 60 * 1000;      // aviso 60s antes
  var _idleTimer, _countTimer;

  function _expire() {
    clearInterval(_countTimer);
    var ov = document.getElementById('idle-overlay');
    var ex = document.getElementById('idle-expired');
    if(ov) ov.style.display = 'none';
    if(ex) { ex.style.display = 'flex'; }
  }

  function _showWarning() {
    var ov = document.getElementById('idle-overlay');
    if(ov) ov.style.display = 'flex';
    var cd = document.getElementById('idle-countdown');
    var secs = 60;
    if(cd) cd.textContent = secs;
    clearInterval(_countTimer);
    _countTimer = setInterval(function(){
      secs--;
      if(cd) cd.textContent = Math.max(0, secs);
      if(secs <= 0) _expire();
    }, 1000);
  }

  function _schedule() {
    clearTimeout(_idleTimer);
    _idleTimer = setTimeout(_showWarning, IDLE_MS - WARN_MS);
  }

  window.idleReset = function() {
    clearInterval(_countTimer);
    var ov = document.getElementById('idle-overlay');
    if(ov) ov.style.display = 'none';
    _schedule();
  };

  ['mousemove','mousedown','keydown','touchstart','scroll','click'].forEach(function(ev){
    document.addEventListener(ev, function(){
      var ov = document.getElementById('idle-overlay');
      var ex = document.getElementById('idle-expired');
      // Só resetar se o overlay de aviso não estiver visível e a sessão não tiver expirado
      if(ex && ex.style.display === 'flex') return;
      if(ov && ov.style.display === 'flex') return;
      clearTimeout(_idleTimer);
      _schedule();
    }, {passive:true});
  });

  _schedule();
})();
