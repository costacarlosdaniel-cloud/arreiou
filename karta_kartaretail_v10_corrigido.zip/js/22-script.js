
/* PATCH FINAL — Dif. Contagens sem recursão
   Causa: _dcgGetLojas chamava _dcgNomeLoja, e _dcgNomeLoja chamava _dcgGetLojas.
   Resultado: Maximum call stack size exceeded. */
(function(){
  function _dcgFinalData(){
    try { return window.CONT_DATA || (typeof contDataLoad === 'function' ? contDataLoad() : {}) || {}; }
    catch(e){ return {}; }
  }
  function _dcgFinalAdmLojas(){
    try { return ((window.ADMCFG && window.ADMCFG.lojas) || []).filter(function(l){ return l && l.c; }); }
    catch(e){ return []; }
  }
  function _dcgFinalDates(){
    var days = window._dcgPeriodDays || 7;
    var arr = [];
    for (var i = days - 1; i >= 0; i--) {
      if (typeof isoToday === 'function') arr.push(isoToday(-i));
      else arr.push(new Date(Date.now() - i * 86400000).toISOString().slice(0,10));
    }
    return arr;
  }
  function _dcgFinalNameFromSources(code){
    code = String(code || '').trim();
    if (!code) return '';
    var adm = _dcgFinalAdmLojas();
    for (var i=0;i<adm.length;i++) {
      if (String(adm[i].c).trim() === code) return adm[i].n || code;
    }
    try {
      var paoLojas = window.D && window.D.pao && window.D.pao.lojas ? window.D.pao.lojas : [];
      for (var j=0;j<paoLojas.length;j++) {
        if (String(paoLojas[j].c).trim() === code) return paoLojas[j].n || code;
      }
    } catch(e) {}
    return code;
  }
  window._dcgNomeLoja = function(code){
    return _dcgFinalNameFromSources(code);
  };
  window._dcgGetLojas = function(){
    var map = {};
    _dcgFinalAdmLojas().forEach(function(l){
      map[String(l.c).trim()] = { c:String(l.c).trim(), n:l.n || String(l.c).trim(), s:l.s || '' };
    });
    var data = _dcgFinalData();
    _dcgFinalDates().forEach(function(d){
      var day = data[d] || {};
      Object.keys(day).forEach(function(c){
        c = String(c || '').trim();
        if (!c) return;
        if (!map[c]) map[c] = { c:c, n:_dcgFinalNameFromSources(c), s:'' };
      });
    });
    return Object.keys(map).sort().map(function(k){ return map[k]; });
  };
  window.dcgCalorRender = window.dcgCalorRender || window.dcgCaiorRender;
  window.dcgCaiorRender = window.dcgCalorRender || window.dcgCaiorRender;
})();


/* PATCH 2026-05-18 — Forçar leitura Firestore para Fechos de Caixa e Dif. Contagens
   Motivo: os dados novos estavam gravados no Firestore, mas algumas análises ficavam presas no cache/localStorage. */
(function(){
  function _kartaTodayIso(){
    try { return new Date().toISOString().slice(0,10); } catch(e){ return ''; }
  }
  function _kartaCashSetStatus(msg){
    try {
      var c = document.getElementById('ana-caixa-content');
      if (c) c.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);font-size:12px">'+msg+'</div>';
    } catch(e) {}
  }

  // 1) Fechos de Caixa: ao abrir a análise, carregar SEMPRE uma vez do Firestore neste arranque.
  var _oldCaixaRenderAnaliseAna = window.caixaRenderAnaliseAna;
  window.caixaRenderAnaliseAna = function(){
    try {
      if (!window._kartaCashFreshLoaded && typeof window.fbRefreshCashClosures === 'function') {
        window._kartaCashFreshLoaded = true;
        _kartaCashSetStatus('⏳ A carregar fechos de caixa do Firebase…');
        window.fbRefreshCashClosures().then(function(data){
          try {
            if (data && Object.keys(data).length) {
              localStorage.setItem('arreiou_caixa_v1', JSON.stringify(data));
            }
          } catch(e) {}
          try {
            var diaInp = document.getElementById('caixa-flt-val-dia');
            if (diaInp && !diaInp.value) diaInp.value = _kartaTodayIso();
          } catch(e) {}
          if (typeof _oldCaixaRenderAnaliseAna === 'function') _oldCaixaRenderAnaliseAna();
        }).catch(function(e){
          window._kartaCashFreshLoaded = false;
          _kartaCashSetStatus('⚠ Erro ao carregar fechos de caixa: ' + (e && e.message ? e.message : e));
        });
        return;
      }
    } catch(e) {}
    if (typeof _oldCaixaRenderAnaliseAna === 'function') return _oldCaixaRenderAnaliseAna.apply(this, arguments);
  };

  // 2) Dif. Contagens: ao abrir, sincronizar automaticamente os últimos 30 dias de inventory_counts.
  var _oldDcgInit = window._dcgInit;
  window._dcgInit = function(){
    if (typeof _oldDcgInit === 'function') {
      try { _oldDcgInit.apply(this, arguments); } catch(e) {}
    }
    try {
      var now = Date.now();
      var last = +(sessionStorage.getItem('karta_dcg_last_sync') || 0);
      if (typeof window.fbSyncContagens === 'function' && (!last || (now - last) > 5 * 60 * 1000)) {
        sessionStorage.setItem('karta_dcg_last_sync', String(now));
        window.fbSyncContagens(30).then(function(){
          try { if (typeof window.dcgDiaRender === 'function') window.dcgDiaRender(); } catch(e) {}
          try { if (typeof window.dcgRankingRender === 'function') window.dcgRankingRender(); } catch(e) {}
          try { if (typeof window.dcgSemContRender === 'function') window.dcgSemContRender(); } catch(e) {}
        }).catch(function(e){
          window._KARTA_DEBUG && console.warn('[DCG] sync auto error:', e);
        });
      }
    } catch(e) {}
  };

  // 3) Botão seguro para refrescar manualmente os fechos de caixa, útil em testes.
  window.caixaForceSyncFirebase = function(){
    window._kartaCashFreshLoaded = false;
    try { localStorage.removeItem('arreiou_caixa_v1'); } catch(e) {}
    return window.caixaRenderAnaliseAna && window.caixaRenderAnaliseAna();
  };
})();
