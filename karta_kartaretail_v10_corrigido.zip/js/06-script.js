
// ── Lembretes: mostrar sempre que se muda de menu ────────────────────────────
// Usa delegação de eventos no document — não interfere com monkey-patches do switchView
(function(){
  // Elementos de navegação que disparam mudança de vista
  var NAV_SELECTORS = [
    '.tb',           // top nav tabs
    '.mnb',          // mobile bottom nav
    '#mobile-nav .mnb'
  ].join(',');

  document.addEventListener('click', function(e) {
    var target = e.target;
    // Subir até encontrar um elemento de nav
    while (target && target !== document.body) {
      if (target.matches && target.matches(NAV_SELECTORS)) {
        // Esperar que o switchView e todos os patches terminem, depois mostrar lembretes
        setTimeout(function() {
          if (typeof lembretesCheckAndShow === 'function') {
            try { lembretesCheckAndShow(); } catch(err) {}
          }
        }, 350);
        return;
      }
      target = target.parentElement;
    }
  }, true); // capture phase — garante que corre mesmo que handlers parem propagação
})();
