
// ── Auto-update: detects new deploy and notifies user (no forced reload) ────
(function() {
  var CURRENT_VERSION = '20260515002';
  var CHECK_INTERVAL  = 24 * 60 * 60 * 1000; // verificar uma vez por dia

  function checkForUpdate() {
    fetch(location.pathname + '?_v=' + Date.now(), {
      method: 'GET',
      cache: 'no-store',
      headers: { 'Cache-Control': 'no-cache' }
    })
    .then(function(r) { return r.text(); })
    .then(function(html) {
      var m = html.match(/<meta name="app-version" content="([^"]+)"/);
      if (!m) return;
      var remoteVersion = m[1];
      if (remoteVersion !== CURRENT_VERSION) {
        window._KARTA_DEBUG&&console.log('[update] Nova versão disponível:', remoteVersion);
        // Mostrar banner — o utilizador decide quando recarregar (sem reload forçado)
        var banner = document.getElementById('update-banner');
        if (!banner) {
          banner = document.createElement('div');
          banner.id = 'update-banner';
          banner.style.cssText = 'position:fixed;bottom:16px;left:50%;transform:translateX(-50%);' +
            'background:#111;color:#fff;padding:10px 20px;border-radius:8px;font-size:12px;' +
            'z-index:99999;display:flex;align-items:center;gap:12px;box-shadow:0 4px 16px rgba(0,0,0,.3)';
          banner.innerHTML = '🔄 Nova versão disponível — ' +
            '<button onclick="location.reload(true)" style="background:#fff;color:#111;border:none;' +
            'border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;font-weight:600">Actualizar agora</button>' +
            '<button onclick="this.parentElement.remove()" style="background:transparent;color:#aaa;border:none;' +
            'font-size:16px;cursor:pointer;padding:0 4px;line-height:1">×</button>';
          document.body.appendChild(banner);
        }
        // Sem reload automatico — o utilizador controla quando actualiza
      }
    })
    .catch(function() {}); // silent fail if offline
  }

  // Register Service Worker for cache control
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(function() {});

    // Quando o service worker detecta novo deploy, recarrega automaticamente
    navigator.serviceWorker.addEventListener('message', function(e) {
      if (e.data && e.data.type === 'NEW_VERSION') {
        // Pequeno delay para não interromper utilizadores que acabaram de abrir a app
        setTimeout(function() {
          // Só recarrega se não houver dados por gravar (formulário activo)
          var _safe = !window._supFormDirty && !window._kpiFormDirty;
          if (_safe) {
            console.log('[Karta] Novo deploy — a recarregar automaticamente…');
            location.reload();
          } else {
            // Mostrar banner em vez de forçar reload
            var banner = document.getElementById('update-banner');
            if (!banner) {
              banner = document.createElement('div');
              banner.id = 'update-banner';
              banner.style.cssText = 'position:fixed;bottom:16px;left:50%;transform:translateX(-50%);' +
                'background:#111;color:#fff;padding:10px 20px;border-radius:8px;font-size:12px;' +
                'z-index:99999;display:flex;align-items:center;gap:12px;box-shadow:0 4px 16px rgba(0,0,0,.3)';
              banner.innerHTML = '🔄 Nova versão disponível — ' +
                '<button onclick="location.reload()" style="background:#fff;color:#111;border:none;' +
                'border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;font-weight:600">Actualizar agora</button>' +
                '<button onclick="this.parentElement.remove()" style="background:transparent;color:#aaa;border:none;' +
                'font-size:16px;cursor:pointer;padding:0 4px;line-height:1">×</button>';
              document.body.appendChild(banner);
            }
          }
        }, 3000); // aguardar 3s para não interromper o carregamento inicial
      }
    });
  }

  // Primeira verificacao 24h apos o carregamento
  window.addEventListener('load', function() {
    setTimeout(checkForUpdate, CHECK_INTERVAL);
    window._kartaUpdateInterval = setInterval(checkForUpdate, CHECK_INTERVAL);
  });
})();
