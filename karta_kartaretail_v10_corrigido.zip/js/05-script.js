
(function(){
  var _supDateUnlocked = false;
  var LOCK_ICON = '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>';
  var UNLOCK_ICON = '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a3 3 0 0 1 6 0"/>';

  function todayStr(){
    return (typeof TODAY !== 'undefined' && TODAY) ? TODAY : new Date().toISOString().split('T')[0];
  }

  function getAdminPin(){
    return _getAdminPin(); // delegar para função central sem fallback hardcoded
  }

  function setDateToday(){
    var el = document.getElementById('sup-form-date-display');
    if (el) el.value = todayStr();
  }

  window.supDateLock = function lockDate(){
    _supDateUnlocked = false;
    var el  = document.getElementById('sup-form-date-display');
    var note = document.getElementById('sup-date-unlocked-note');
    var btn  = document.getElementById('sup-date-lock-btn');
    var icon = document.getElementById('sup-date-lock-icon');
    if(el){ el.setAttribute('readonly',''); el.style.cursor='default'; el.value=todayStr(); }
    if(note) note.style.display='none';
    if(btn){ btn.title='Alterar data (requer PIN de administração)'; btn.style.color=''; btn.style.borderColor=''; }
    if(icon) icon.innerHTML = LOCK_ICON;
  };

  window.supDateUnlockPrompt = function(){
    if(_supDateUnlocked){ window.supDateLock(); return; }
    document.getElementById('sup-date-pin-input').value='';
    document.getElementById('sup-date-pin-err').textContent='';
    document.getElementById('sup-date-pin-modal').style.display='flex';
    setTimeout(function(){ document.getElementById('sup-date-pin-input').focus(); }, 80);
  };

  window.supDatePinClose = function(){
    document.getElementById('sup-date-pin-modal').style.display='none';
  };

  window.supDatePinConfirm = function(){
    var entered = document.getElementById('sup-date-pin-input').value;
    if(entered === getAdminPin()){
      _supDateUnlocked = true;
      document.getElementById('sup-date-pin-modal').style.display='none';
      var el   = document.getElementById('sup-form-date-display');
      var note = document.getElementById('sup-date-unlocked-note');
      var btn  = document.getElementById('sup-date-lock-btn');
      var icon = document.getElementById('sup-date-lock-icon');
      if(el){ el.removeAttribute('readonly'); el.style.cursor='pointer'; el.focus(); }
      if(note) note.style.display='block';
      if(btn){ btn.title='Clique para re-bloquear a data'; btn.style.color='var(--amber)'; btn.style.borderColor='var(--amber)'; }
      if(icon) icon.innerHTML = UNLOCK_ICON;
    } else {
      document.getElementById('sup-date-pin-err').textContent='PIN incorrecto. Tente novamente.';
      document.getElementById('sup-date-pin-input').select();
    }
  };

  document.getElementById('sup-date-pin-modal').addEventListener('click', function(e){
    if(e.target === this) supDatePinClose();
  });

  // ── Set today on page load ───────────────────────────────────────
  function initDate(){
    window.supDateLock(); // sets today + readonly state
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', initDate);
  } else {
    initDate();
  }

  // ── Patch switchView so navigating to 'sup' always resets to today ──
  function patchSwitchView(){
    if(typeof window.switchView !== 'function') return;
    if(window.switchView._supDatePatched) return;
    var _orig = window.switchView;
    window.switchView = function(v){
      _orig(v);
      if(v === 'sup' && !_supDateUnlocked) setDateToday();
    };
    window.switchView._supDatePatched = true;
  }

  // ── Patch supFormClear to re-lock ────────────────────────────────
  function patchClear(){
    if(typeof window.supFormClear !== 'function') return;
    if(window.supFormClear._supDatePatched) return;
    var _orig = window.supFormClear;
    window.supFormClear = function(){
      _orig.apply(this, arguments);
      window.supDateLock();
    };
    window.supFormClear._supDatePatched = true;
  }

  // Apply patches — try immediately, then retry after scripts settle
  patchSwitchView(); patchClear();
  setTimeout(function(){ patchSwitchView(); patchClear(); }, 300);
  setTimeout(function(){ patchSwitchView(); patchClear(); }, 1500);
})();
