
// ── OFFLINE DETECTION ─────────────────────────────────────────────────────
(function(){
  var banner = document.getElementById('offline-banner');
  function updateOnline() {
    if (banner) banner.classList.toggle('show', !navigator.onLine);
  }
  window.addEventListener('online',  updateOnline);
  window.addEventListener('offline', updateOnline);
  updateOnline();

  // When coming back online — sync pending drafts and submits
  window.addEventListener('online', function() {
    setTimeout(function() {
      // Sync pending drafts
      try {
        if (typeof _supDraftsMemory !== 'undefined' && _supDraftsMemory) {
          Object.keys(_supDraftsMemory).forEach(function(centro) {
            var d = _supDraftsMemory[centro];
            if (d && d.__pendingSync__ && typeof supDraftSaveForCentro === 'function') {
              window._KARTA_DEBUG&&console.log('[offline] A sincronizar draft:', centro);
              supDraftSaveForCentro(centro, d).then(function() {
                delete d.__pendingSync__;
              }).catch(function(){});
            }
          });
        }
      } catch(e) {}
      // Sync pending submits (forms submitted while offline)
      try {
        var pending = JSON.parse(localStorage.getItem('arreiou_sup_pending_v1') || '[]');
        if (pending.length > 0) {
          window._KARTA_DEBUG&&console.log('[offline] A sincronizar', pending.length, 'roteiros pendentes…');
          var synced = 0;
          pending.forEach(function(p) {
            if (typeof supDataSaveLS === 'function') {
              delete p.val.__pendingSubmit__;
              supDataSaveLS(null, {mes: p.mes, sup: p.sup, key: p.key, val: p.val})
                .then(function() {
                  synced++;
                  if (synced === pending.length) {
                    localStorage.removeItem('arreiou_sup_pending_v1');
                    window._supPendingSubmits = [];
                    // Show success toast
                    var b = document.getElementById('offline-banner');
                    if (b) { b.style.background='#1a7040'; b.textContent='✓ '+synced+' roteiro(s) sincronizado(s) com sucesso!'; b.classList.add('show'); setTimeout(function(){ b.classList.remove('show'); b.style.background=''; b.textContent='📵 Sem internet — formulários guardados localmente e enviados quando voltar a ligar'; }, 4000); }
                  }
                }).catch(function(){});
            }
          });
        }
      } catch(e) {}
    }, 2000);
  });
})();

// ── PWA INSTALL PROMPT ────────────────────────────────────────────────────
(function(){
  var _deferredPrompt = null;
  var dismissed = localStorage.getItem('pwa-dismissed');
  if (dismissed) return;

  window.addEventListener('beforeinstallprompt', function(e) {
    e.preventDefault();
    _deferredPrompt = e;
    // Show after 3s if on mobile
    if (window.innerWidth <= 768) {
      setTimeout(function() {
        var b = document.getElementById('pwa-install-banner');
        if (b) b.classList.add('show');
      }, 3000);
    }
  });

  var installBtn = document.getElementById('pwa-install-btn');
  if (installBtn) {
    installBtn.addEventListener('click', function() {
      if (!_deferredPrompt) return;
      _deferredPrompt.prompt();
      _deferredPrompt.userChoice.then(function(r) {
        _deferredPrompt = null;
        var b = document.getElementById('pwa-install-banner');
        if (b) b.classList.remove('show');
        if (r.outcome === 'accepted') localStorage.setItem('pwa-dismissed','1');
      });
    });
  }
})();
