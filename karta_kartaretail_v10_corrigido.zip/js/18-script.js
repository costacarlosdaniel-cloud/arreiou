
// ── Fecho automático por inactividade (1 hora) ──────────────────────────────
(function() {
  const TIMEOUT_MS = 60 * 60 * 1000; // 1 hora
  const WARN_MS    = 55 * 60 * 1000; // aviso 5 min antes
  var _inactTimer = null, _warnTimer = null, _warnEl = null;

  function _clearTimers() {
    if (_inactTimer) clearTimeout(_inactTimer);
    if (_warnTimer)  clearTimeout(_warnTimer);
  }

  function _hideWarning() {
    if (_warnEl) { _warnEl.style.display = 'none'; }
  }

  function _showWarning() {
    if (!_warnEl) {
      _warnEl = document.createElement('div');
      _warnEl.id = 'inact-warn';
      _warnEl.style.cssText = [
        'position:fixed','bottom:24px','left:50%','transform:translateX(-50%)',
        'background:#1a1a2e','color:#fff','padding:14px 24px','border-radius:12px',
        'font-size:14px','z-index:99999','box-shadow:0 4px 20px rgba(0,0,0,0.4)',
        'display:flex','align-items:center','gap:12px','max-width:360px'
      ].join(';');
      _warnEl.innerHTML =
        '<span>⏱ A app fecha em <b id="inact-countdown">5:00</b> por inactividade.</span>' +
        '<button onclick="window._inactReset()" style="background:#f39c12;border:none;color:#fff;' +
        'padding:6px 14px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600">Continuar</button>';
      document.body.appendChild(_warnEl);
    }
    _warnEl.style.display = 'flex';
    // Countdown 5min → 0
    var _remaining = 5 * 60;
    if (_warnEl._cdInterval) clearInterval(_warnEl._cdInterval);
    _warnEl._cdInterval = setInterval(function() {
      _remaining--;
      var cdEl = document.getElementById('inact-countdown');
      if (cdEl) {
        var m = Math.floor(_remaining / 60);
        var s = String(_remaining % 60).padStart(2, '0');
        cdEl.textContent = m + ':' + s;
      }
      if (_remaining <= 0) clearInterval(_warnEl._cdInterval);
    }, 1000);
  }

  // Overlay de bloqueio — mantém a página e listeners vivos (sem recarregar)
  var _lockEl = null;
  function _doClose() {
    _hideWarning();
    if (!_lockEl) {
      _lockEl = document.createElement('div');
      _lockEl.id = 'inact-lock';
      _lockEl.style.cssText = [
        'position:fixed','inset:0','z-index:999999',
        'background:#0a0a14','display:flex','flex-direction:column',
        'align-items:center','justify-content:center','gap:16px',
        'font-family:sans-serif','color:#fff'
      ].join(';');
      _lockEl.innerHTML =
        '<div style="font-size:52px">🔒</div>' +
        '<div style="font-size:20px;font-weight:700">Sessão expirada</div>' +
        '<div style="font-size:14px;color:#888;text-align:center">A app fechou por inactividade (1 hora).</div>' +
        '<button onclick="window._inactUnlock()" style="margin-top:8px;background:#f39c12;border:none;' +
        'color:#fff;padding:10px 28px;border-radius:10px;cursor:pointer;font-size:15px;font-weight:600">' +
        'Reabrir</button>';
      document.body.appendChild(_lockEl);
    }
    _lockEl.style.display = 'flex';
  }

  window._inactUnlock = function() {
    if (_lockEl) _lockEl.style.display = 'none';
    _reset(); // reiniciar timer de inactividade
  };

  function _reset() {
    _clearTimers();
    _hideWarning();
    _warnTimer  = setTimeout(_showWarning, WARN_MS);
    _inactTimer = setTimeout(_doClose,    TIMEOUT_MS);
  }

  // Expor reset para o botão "Continuar"
  window._inactReset = _reset;

  // Eventos de actividade
  ['mousemove','mousedown','keydown','touchstart','touchmove','scroll','click'].forEach(function(ev) {
    document.addEventListener(ev, _reset, { passive: true });
  });

  // Arrancar
  _reset();
})();
// ─────────────────────────────────────────────────────────────────────────────
