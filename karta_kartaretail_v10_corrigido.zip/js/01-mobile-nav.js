
// ── MOBILE NAV & SIDEBAR LOGIC ────────────────────────────────────────────────
(function(){
  var MOBILE_BP = 768;

  function isMobile(){ return window.innerWidth <= MOBILE_BP; }

  // Icons for bottom nav
  var NAV_ITEMS = [
    {id:'kpi',        label:'KPI',      icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>'},
    {id:'caixa',      label:'Caixa',    icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h2M10 15h4"/></svg>', protected:true},
    {id:'contagens',  label:'Contagens',icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>'},
    {id:'caixatop20', label:'Top 20',   icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M18 20V10M12 20V4M6 20v-6"/><circle cx="18" cy="8" r="2"/></svg>'},
    {id:'analises',   label:'Análises', icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M3 3v18h18"/><path d="M7 16l4-4 4 4 4-8"/></svg>'},
    {id:'imob',       label:'Imobil.',  icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-4 0v2M12 12v4M10 14h4"/></svg>', protected:true},
    {id:'docs',       label:'Docs',     icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>'},
    {id:'lojaescala', label:'Escalas',  icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 2v4M16 2v4M3 10h18"/></svg>'},
    {id:'lojas',      label:'Lojas',    icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>'},
    {id:'gerrank',    label:'Gerentes', icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>'},
    {id:'suprank',    label:'Rank Sup', icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M18 20V10M12 20V4M6 20v-6"/></svg>'},
    {id:'sup',        label:'Roteiro',  icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4"/></svg>'},
    {id:'form',       label:'Form SM',  icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>'},
    {id:'adm',        label:'Admin',    icon:'<svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M6 20v-2a6 6 0 0 1 12 0v2"/></svg>'},
  ];

  function buildMobileNav(){
    if(document.getElementById('mobile-nav')) return;
    var nav = document.createElement('nav');
    nav.id = 'mobile-nav';
    NAV_ITEMS.forEach(function(item){
      var btn = document.createElement('div');
      btn.className = 'mnb';
      btn.id = 'mnb-'+item.id;
      btn.innerHTML = item.icon + '<span>' + item.label + '</span>';
      btn.onclick = function(){
        var _id = item.id;
        try {
          var _cfg = tabCfgLoad();
          if(item.protected || (_cfg[_id] && _cfg[_id].pwd && _cfg[_id].pwd.trim())){
            switchViewProtected(_id);
          } else if(_id==='suprank'){ switchView('suprank'); }
          else { switchView(_id); }
        } catch(e) { switchView(_id); }
        updateMobileNav(_id);
      };
      nav.appendChild(btn);
    });
    document.body.appendChild(nav);
    // Mark current active
    updateMobileNav('kpi');
  }

  function updateMobileNav(active){
    // Map aliases to nav item ids
    var _map = {
      'suprank':'gerrank','gerrank':'gerrank',
      'diariolojas':'analises','topflop':'analises','rotdia':'analises',
      'quebras':'analises','vendas':'analises','cobertura':'analises',
      'fechocaixa':'analises','inventario':'analises',
      'downtime':'analises','sales':'analises','trend10':'analises','vdlost':'analises',
      'analises':'analises'
    };
    var mapped = _map[active] || active;
    document.querySelectorAll('.mnb').forEach(function(el){
      el.classList.toggle('on', el.id === 'mnb-'+mapped);
    });
    var el = document.getElementById('mnb-'+mapped);
    if(el) el.scrollIntoView({behavior:'smooth',block:'nearest',inline:'center'});
  }

  // Patch switchView to also update mobile nav
  window.addEventListener('load', function(){
    if(isMobile()){
      buildMobileNav();
      buildStoreToggle();
      buildSecondaryDrawers();
    }
  });

  window.addEventListener('resize', function(){
    if(isMobile() && !document.getElementById('mobile-nav')){
      buildMobileNav();
      buildStoreToggle();
      buildSecondaryDrawers();
    }
  });

  // ── KPI store sidebar toggle ──────────────────────────────────────────────
  function buildStoreToggle(){
    var kpiShell = document.getElementById('sh-kpi');
    if(!kpiShell || document.getElementById('sb-toggle')) return;
    var sb = kpiShell.querySelector('.sb');
    if(!sb) return;

    var toggle = document.createElement('div');
    toggle.id = 'sb-toggle';
    toggle.innerHTML = '<span id="sb-toggle-label">Seleccionar loja</span>'
      + '<svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>';
    toggle.onclick = function(){
      var isOpen = sb.classList.toggle('open');
      toggle.classList.toggle('open', isOpen);
    };
    kpiShell.insertBefore(toggle, kpiShell.firstChild);

    // When a store is selected, update toggle label and close drawer
    var origLoadStore = window.loadStore;
    window.loadStore = function(c){
      origLoadStore(c);
      var name = (window.DB && window.DB[c]) ? window.DB[c].n : c;
      var lbl = document.getElementById('sb-toggle-label');
      if(lbl) lbl.textContent = c + ' · ' + name;
      if(isMobile()){ sb.classList.remove('open'); toggle.classList.remove('open'); }
    };
  }

  // ── Secondary drawers for imob / caixa / lojaescala ─────────────────────
  function buildSecondaryDrawers(){
    ['imob','caixa','lojaescala'].forEach(function(id){
      var shell = document.getElementById('sh-'+id);
      if(!shell || document.getElementById(id+'-sb-toggle')) return;
      var sb = shell.querySelector('.sb, aside');
      if(!sb) return;
      var toggle = document.createElement('div');
      toggle.id = id+'-sb-toggle';
      toggle.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:var(--w);border-bottom:1px solid var(--bd);font-size:13px;font-weight:600;color:var(--tx);cursor:pointer;flex-shrink:0;user-select:none;';
      toggle.innerHTML = '<span>Seleccionar loja</span><svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>';
      toggle.onclick = function(){
        var isOpen = sb.classList.toggle('open');
        toggle.querySelector('svg').style.transform = isOpen ? 'rotate(180deg)' : '';
      };
      shell.firstElementChild.insertBefore(toggle, shell.firstElementChild.firstChild);
    });
  }

  // Patch switchView to update mobile nav indicator — lazy wrap at load time
  window.addEventListener('load', function(){
    var _sv = window.switchView;
    if(_sv) window.switchView = function(v){
      _sv(v);
      updateMobileNav(v==='suprank'?'suprank':v);
    };
    var _svp = window.switchViewProtected;
    if(_svp) window.switchViewProtected = function(v){
      _svp(v);
      updateMobileNav(v);
    };
  });
})();
