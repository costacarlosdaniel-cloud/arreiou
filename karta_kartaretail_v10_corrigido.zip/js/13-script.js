
// ══════════════════════════════════════════════════════════════════════════════
// MÓDULO: CONTAGENS DIÁRIAS
// ══════════════════════════════════════════════════════════════════════════════
(function(){

var CONT_CFG_KEY  = 'arreiou_cont_cfg_v1';
var CONT_DATA_KEY = 'arreiou_cont_data_v1';

// Cache do catálogo carregado do Google Sheet
var _contSheetData = []; // [{sku, nome}]
var _contSheetLoaded = false;
var _contSheetLoading = false;

function contCfgLoad()  { try { return JSON.parse(localStorage.getItem(CONT_CFG_KEY)  || '{"artigos":[]}'); } catch(e){ return {artigos:[]}; } }
function contDataLoad() { try { return JSON.parse(localStorage.getItem(CONT_DATA_KEY) || '{}'); } catch(e){ return {}; } }

if (!window.CONT_CFG)  window.CONT_CFG  = contCfgLoad();
if (!window.CONT_DATA) window.CONT_DATA = contDataLoad();

var _contTurno = 'manha';

var TURNOS = [
  {id:'manha', label:'Manhã',  hora:'07:00'},
  {id:'tarde', label:'Tarde',  hora:'14:00'},
  {id:'noite', label:'Noite',  hora:'21:30'},
];

// ══════════════════════════════════════════════════════════════════════════════
// CARREGAMENTO DO CATÁLOGO (Google Sheet)
// ══════════════════════════════════════════════════════════════════════════════
window.contAdmLoadSheet = function() {
  // Reset sempre — evitar estado travado de tentativa anterior
  _contSheetLoading = false;
  _contSheetLoaded  = false;
  _contSheetData    = [];

  var btn    = document.getElementById('cont-load-btn');
  var status = document.getElementById('cont-search-status');
  var res    = document.getElementById('cont-search-results');

  _contSheetLoading = true;
  if (btn)    { btn.textContent = '⏳ A carregar...'; btn.disabled = true; }
  if (status) { status.textContent = 'A carregar catálogo...'; status.style.color = 'var(--t3)'; }
  if (res)    { res.style.display = 'none'; }

  // GS_ID é const noutro script — não entra no window automaticamente
  var _gsId = window.GS_ID || '1ybnb1bMtRxwgcn6OL5fsZ6ID8XBkpXjY';
  var sheetName = 'SalesKPIsStore 1';
  var url = 'https://docs.google.com/spreadsheets/d/' + _gsId + '/gviz/tq?tqx=out:csv&sheet=' + encodeURIComponent(sheetName) + '&t=' + Date.now();

  fetch(url)
    .then(function(r){ if(!r.ok) throw new Error('HTTP '+r.status); return r.text(); })
    .then(function(text){
      var rows = window.Papa ? Papa.parse(text, {skipEmptyLines:true}).data : _csvParse(text);
      // Encontrar colunas SKU e Descrição — cabeçalho na linha 0
      var header = rows[0] || [];
      var skuCol  = -1;
      var descCol = -1;
      header.forEach(function(h, i){
        var hn = (h||'').toString().trim().toUpperCase();
        if (hn.includes('SKU') && !hn.includes('DESCRI')) skuCol = i;
        if (hn.includes('DESCRI') && hn.includes('SKU')) descCol = i;
      });
      // Fallback: col D=3 (SKU), col E=4 (Descrição)
      if (skuCol  < 0) skuCol  = 3;
      if (descCol < 0) descCol = 4;

      _contSheetData = [];
      var seen = new Set();
      rows.slice(1).forEach(function(row){
        var sku  = (row[skuCol]  || '').toString().trim();
        var nome = (row[descCol] || '').toString().trim();
        if (!sku && !nome) return;
        var key = sku + '|' + nome;
        if (seen.has(key)) return;
        seen.add(key);
        _contSheetData.push({sku: sku, nome: nome});
      });
      _contSheetLoaded = true;
      _contSheetLoading = false;
      if (btn) {
        btn.textContent = '✓ ' + _contSheetData.length + ' artigos carregados';
        btn.style.color = 'var(--green)';
        btn.style.borderColor = 'var(--green)';
        btn.disabled = false;
      }
      if (status) status.textContent = _contSheetData.length + ' artigos. Pesquise por SKU ou nome.';
      // Auto-mostrar resultados se há texto na pesquisa
      var inp = document.getElementById('cont-search-inp');
      if (inp && inp.value.trim()) contAdmSearch();
    })
    .catch(function(e){
      _contSheetLoading = false;
      if (btn) { btn.textContent = '↺ Tentar novamente'; btn.style.color = 'var(--red)'; btn.disabled = false; }
      if (status) { status.textContent = '⚠ Erro: ' + e.message; status.style.color = 'var(--red)'; }
    });
};

function _csvParse(text) {
  return text.split('\n').map(function(l){ return l.split(',').map(function(c){ return c.replace(/^"|"$/g,''); }); });
}

// ── Pesquisa em tempo real ────────────────────────────────────────────────────
window.contAdmSearch = function() {
  var inp = document.getElementById('cont-search-inp');
  var res = document.getElementById('cont-search-results');
  var status = document.getElementById('cont-search-status');
  if (!inp || !res) return;

  var q = inp.value.trim().toLowerCase();
  if (!q) { res.style.display='none'; return; }

  if (!_contSheetLoaded) {
    if (status) { status.textContent = 'Clique em "Carregar catálogo" para pesquisar.'; status.style.color='var(--amber)'; }
    res.style.display = 'none';
    return;
  }

  var matches = _contSheetData.filter(function(a){
    return a.sku.toLowerCase().includes(q) || a.nome.toLowerCase().includes(q);
  }).slice(0, 80);

  if (!matches.length) {
    res.style.display = 'block';
    res.innerHTML = '<div style="padding:12px 14px;font-size:12px;color:var(--t3)">Nenhum resultado para "'+escHtml(q)+'"</div>';
    return;
  }

  var cfg = window.CONT_CFG || contCfgLoad();
  var existingSKUs = new Set((cfg.artigos||[]).map(function(a){ return a.sku; }));

  res.style.display = 'block';
  res.innerHTML = matches.map(function(a){
    var already = existingSKUs.has(a.sku) && a.sku;
    return '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-bottom:1px solid var(--bd);cursor:'+(already?'default':'pointer')+';transition:background .08s" '
      + (already ? '' : 'onclick="contAdmAddFromSheet(\''+escAttr(a.sku)+'\',\''+escAttr(a.nome)+'\')" onmouseover="this.style.background=\'var(--s2)\'" onmouseout="this.style.background=\'\'"')
      + '>'
      + '<div style="font-size:10px;font-weight:600;color:var(--t3);min-width:60px;flex-shrink:0">'+(a.sku||'—')+'</div>'
      + '<div style="flex:1;font-size:12px;color:var(--tx)">'+ escHtml(a.nome) +'</div>'
      + (already
        ? '<span style="font-size:9px;font-weight:600;background:var(--gbg);color:var(--green);padding:2px 7px;border-radius:3px;flex-shrink:0">✓ Adicionado</span>'
        : '<span style="font-size:9px;font-weight:600;background:var(--s3);color:var(--t2);padding:2px 7px;border-radius:3px;flex-shrink:0">+ Adicionar</span>')
      + '</div>';
  }).join('');
};

// ── Adicionar artigo do sheet ─────────────────────────────────────────────────
window.contAdmAddFromSheet = function(sku, nome) {
  _contAdmShowLojaModal(sku, nome);
};

// ── Modal de selecção de lojas ────────────────────────────────────────────────
function _contAdmShowLojaModal(sku, nome) {
  var existing = document.getElementById('cont-loja-modal');
  if (existing) existing.remove();

  var lojas = (typeof ADMCFG !== 'undefined' && ADMCFG && ADMCFG.lojas) ? ADMCFG.lojas : (window.ADMCFG && window.ADMCFG.lojas) || [];
  var lojaRows = lojas.map(function(l){
    return '<label style="display:flex;align-items:center;gap:8px;padding:5px 12px;cursor:pointer;transition:background .08s;border-radius:4px" onmouseover="this.style.background=\'var(--s2)\'" onmouseout="this.style.background=\'\'">'
      + '<input type="checkbox" class="cont-loja-chk" value="'+l.c+'" style="width:14px;height:14px;accent-color:var(--tx);cursor:pointer">'
      + '<span style="font-size:11.5px;color:var(--tx)">'+ escHtml(l.c+' — '+l.n) +'</span>'
      + '</label>';
  }).join('');

  var ov = document.createElement('div');
  ov.id = 'cont-loja-modal';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9000;display:flex;align-items:center;justify-content:center;padding:20px';
  ov.innerHTML =
    '<div style="background:var(--w);border-radius:12px;width:480px;max-width:95vw;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.25)">'
    // Header
    + '<div style="padding:18px 20px;border-bottom:1px solid var(--bd)">'
    +   '<div style="font-size:14px;font-weight:700;color:var(--tx);margin-bottom:3px">+ Adicionar artigo às lojas</div>'
    +   '<div style="font-size:11px;color:var(--t3)">'+(sku?'SKU '+sku+' · ':'')+escHtml(nome)+'</div>'
    + '</div>'
    // Unidade
    + '<div style="padding:12px 20px;border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:10px;flex-wrap:wrap">'
    +   '<label style="font-size:11px;font-weight:600;color:var(--t3);text-transform:uppercase;letter-spacing:.04em;white-space:nowrap">Unidade:</label>'
    +   '<input id="cont-mod-unidade" type="text" value="unid" style="width:80px;padding:6px 8px;border:1px solid var(--bd);border-radius:5px;font-family:inherit;font-size:12px;color:var(--tx);background:var(--bg);outline:none">'
    +   '<span style="font-size:10px;color:var(--t3)">ex: unid, cx, kg, lt</span>'
    + '</div>'
    // Lojas
    + '<div style="padding:12px 20px;border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:8px;flex-wrap:wrap">'
    +   '<div style="font-size:11px;font-weight:600;color:var(--t3);text-transform:uppercase;letter-spacing:.04em">Aplicar a:</div>'
    +   '<button onclick="contLojaSelAll(true)"  style="padding:4px 10px;font-size:11px;border:1px solid var(--bd);border-radius:4px;background:var(--w);cursor:pointer">✓ Todas</button>'
    +   '<button onclick="contLojaSelAll(false)" style="padding:4px 10px;font-size:11px;border:1px solid var(--bd);border-radius:4px;background:var(--w);cursor:pointer">Nenhuma</button>'
    +   '<span id="cont-loja-count" style="font-size:10px;color:var(--t3)">0 lojas seleccionadas</span>'
    + '</div>'
    + '<div style="overflow-y:auto;padding:8px 8px;flex:1">'+ lojaRows +'</div>'
    // Footer
    + '<div style="padding:14px 20px;border-top:1px solid var(--bd);display:flex;gap:8px;justify-content:flex-end">'
    +   '<button onclick="document.getElementById(\'cont-loja-modal\').remove()" style="padding:8px 18px;border:1px solid var(--bd);border-radius:6px;background:var(--w);font-family:inherit;font-size:12px;cursor:pointer">Cancelar</button>'
    +   '<button onclick="contAdmConfirmAdd(\''+escAttr(sku)+'\',\''+escAttr(nome)+'\')" style="padding:8px 18px;background:var(--tx);color:#fff;border:none;border-radius:6px;font-family:inherit;font-size:12px;font-weight:600;cursor:pointer">Adicionar às lojas seleccionadas</button>'
    + '</div>'
    + '</div>';
  document.body.appendChild(ov);
  ov.addEventListener('click', function(e){ if(e.target===ov) ov.remove(); });

  // Update count on check
  ov.addEventListener('change', _contUpdateLojaCount);
}

window.contLojaSelAll = function(val) {
  var modal = document.getElementById('cont-loja-modal');
  var scope = modal || document;
  scope.querySelectorAll('.cont-loja-chk').forEach(function(c){ c.checked = val; });
  _contUpdateLojaCount();
};

function _contUpdateLojaCount() {
  var modal = document.getElementById('cont-loja-modal');
  var scope = modal || document;
  var n = scope.querySelectorAll('.cont-loja-chk:checked').length;
  var el = document.getElementById('cont-loja-count');
  if (el) el.textContent = n + ' loja' + (n!==1?'s':'') + ' seleccionada' + (n!==1?'s':'');
}

window.contAdmConfirmAdd = function(sku, nome) {
  var unidade = (document.getElementById('cont-mod-unidade')||{}).value || 'unid';
  var modal = document.getElementById('cont-loja-modal');
  var scope = modal || document;
  var allChks = scope.querySelectorAll('.cont-loja-chk');
  var checked = Array.from(scope.querySelectorAll('.cont-loja-chk:checked')).map(function(c){ return c.value; });
  // Se não há checkboxes (lojas não carregaram), tratar como "todas"
  if (allChks.length === 0) { checked = []; }
  else if (!checked.length) { alert('Seleccione pelo menos uma loja.'); return; }

  var cfg = window.CONT_CFG || contCfgLoad();
  if (!cfg.artigos) cfg.artigos = [];

  // Verificar se o artigo já existe
  var existing = cfg.artigos.find(function(a){ return a.sku === sku && a.nome === nome; });
  if (existing) {
    // Merge lojas
    var lojaSet = new Set(existing.lojas || []);
    checked.forEach(function(l){ lojaSet.add(l); });
    existing.lojas = Array.from(lojaSet);
    existing.ativo = true;
  } else {
    cfg.artigos.push({
      id: 'art_' + Date.now(),
      sku: sku,
      nome: nome,
      unidade: unidade.trim() || 'unid',
      lojas: checked, // [] = todas, array de códigos = específicas
      ativo: true
    });
  }

  _contCfgSave(cfg);
  var modal = document.getElementById('cont-loja-modal');
  if (modal) modal.remove();
  contAdmRender();
  // Refresh pesquisa para mostrar badge "Adicionado"
  contAdmSearch();
  _contAdmMsg('✓ Artigo adicionado a ' + checked.length + ' loja(s)!');
};

// ══════════════════════════════════════════════════════════════════════════════
// RENDER LISTA DE ARTIGOS CONFIGURADOS
// ══════════════════════════════════════════════════════════════════════════════
window.contAdmRender = function() {
  var el = document.getElementById('cont-adm-list');
  var ct = document.getElementById('cont-adm-count');
  if (!el) return;

  var cfg = window.CONT_CFG || contCfgLoad();
  var artigos = cfg.artigos || [];
  if (ct) ct.textContent = artigos.length + ' artigo' + (artigos.length!==1?'s':'');

  // Populate loja select nos dados
  var lojaAdmEl = document.getElementById('cont-adm-loja');
  if (lojaAdmEl && lojaAdmEl.options.length <= 1) {
    ((typeof ADMCFG!=='undefined'&&ADMCFG&&ADMCFG.lojas)?ADMCFG.lojas:(window.ADMCFG&&window.ADMCFG.lojas)||[]).forEach(function(l){
      var o = document.createElement('option'); o.value=l.c; o.textContent=l.c+' — '+l.n; lojaAdmEl.appendChild(o);
    });
  }
  var dadEl = document.getElementById('cont-adm-date');
  if (dadEl && !dadEl.value) {
    var n=new Date();
    dadEl.value=n.getFullYear()+'-'+String(n.getMonth()+1).padStart(2,'0')+'-'+String(n.getDate()).padStart(2,'0');
    contAdmDataRender();
  }

  if (!artigos.length) {
    el.innerHTML = '<div style="padding:24px 16px;text-align:center;color:var(--t3);font-size:12px">Nenhum artigo adicionado ainda. Pesquise no catálogo acima.</div>';
    return;
  }

  var lojas = (window.ADMCFG && window.ADMCFG.lojas) || [];
  var html = '';
  artigos.forEach(function(a, i){
    var lojasList = (a.lojas && a.lojas.length) ? a.lojas.length + ' loja(s)' : 'Todas as lojas';
    var lojasDetail = (a.lojas && a.lojas.length) ? a.lojas.map(function(c){
      var l = lojas.find(function(x){ return x.c===c; });
      return c + (l ? ' '+l.n : '');
    }).join(', ') : 'Todas as lojas (' + lojas.length + ')';

    html += '<div style="display:flex;align-items:center;gap:10px;padding:9px 16px;border-bottom:1px solid var(--bd);flex-wrap:wrap">';
    // SKU + nome
    html += '<div style="min-width:0;flex:1">'
          + '<div style="display:flex;align-items:center;gap:8px">'
          + (a.sku ? '<span style="font-size:10px;font-weight:600;background:var(--bbg);color:var(--blue);padding:1px 6px;border-radius:3px;flex-shrink:0">'+escHtml(a.sku)+'</span>' : '')
          + '<span style="font-size:12px;font-weight:500;color:var(--tx)">'+escHtml(a.nome)+'</span>'
          + '</div>'
          + '<div style="font-size:10px;color:var(--t3);margin-top:2px" title="'+escAttr(lojasDetail)+'">'
          + '📍 '+lojasList+' · '+(a.unidade||'unid')
          + '</div>'
          + '</div>';
    // Estado
    html += '<span style="font-size:9px;font-weight:600;padding:2px 7px;border-radius:3px;flex-shrink:0;background:'
          + (a.ativo!==false?'var(--gbg)':'var(--s3)')+';color:'+(a.ativo!==false?'var(--green)':'var(--t3)')+';">'
          + (a.ativo!==false?'Activo':'Inactivo')+'</span>';
    // Acções
    html += '<div style="display:flex;gap:4px;flex-shrink:0">'
          + '<button onclick="contAdmEditLojas('+i+')" title="Editar lojas" style="padding:4px 8px;font-size:11px;border:1px solid var(--bd);border-radius:4px;background:var(--w);cursor:pointer">📍 Lojas</button>'
          + '<button onclick="contAdmToggle('+i+')" style="padding:4px 8px;font-size:11px;border:1px solid var(--bd);border-radius:4px;background:var(--w);cursor:pointer">'+(a.ativo!==false?'⏸':'▶')+'</button>'
          + '<button onclick="contAdmDelete('+i+')" style="padding:4px 8px;font-size:11px;border:1px solid var(--rbg);border-radius:4px;background:var(--rbg);color:var(--red);cursor:pointer">🗑</button>'
          + '</div>';
    html += '</div>';
  });
  el.innerHTML = html;
};

// ── Editar lojas de um artigo já configurado ──────────────────────────────────
window.contAdmEditLojas = function(i) {
  var cfg = window.CONT_CFG || contCfgLoad();
  var art = cfg.artigos[i];
  if (!art) return;

  var lojas = (typeof ADMCFG !== 'undefined' && ADMCFG && ADMCFG.lojas) ? ADMCFG.lojas : (window.ADMCFG && window.ADMCFG.lojas) || [];
  var selected = new Set(art.lojas || []);
  var allSelected = !art.lojas || !art.lojas.length;

  var lojaRows = lojas.map(function(l){
    return '<label style="display:flex;align-items:center;gap:8px;padding:5px 12px;cursor:pointer;border-radius:4px" onmouseover="this.style.background=\'var(--s2)\'" onmouseout="this.style.background=\'\'">'
      + '<input type="checkbox" class="cont-loja-chk" value="'+l.c+'" '+(allSelected||selected.has(l.c)?'checked':'')+' style="width:14px;height:14px;accent-color:var(--tx);cursor:pointer">'
      + '<span style="font-size:11.5px;color:var(--tx)">'+escHtml(l.c+' — '+l.n)+'</span>'
      + '</label>';
  }).join('');

  var ov = document.createElement('div');
  ov.id = 'cont-loja-modal';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9000;display:flex;align-items:center;justify-content:center;padding:20px';
  ov.innerHTML =
    '<div style="background:var(--w);border-radius:12px;width:480px;max-width:95vw;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.25)">'
    + '<div style="padding:18px 20px;border-bottom:1px solid var(--bd)">'
    +   '<div style="font-size:14px;font-weight:700;color:var(--tx);margin-bottom:3px">📍 Lojas — '+escHtml(art.nome)+'</div>'
    +   '<div style="font-size:11px;color:var(--t3)">'+(art.sku?'SKU '+art.sku+' · ':'')+'Seleccione as lojas onde este artigo é contado</div>'
    + '</div>'
    + '<div style="padding:12px 20px;border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:8px;flex-wrap:wrap">'
    +   '<button onclick="contLojaSelAll(true)"  style="padding:4px 10px;font-size:11px;border:1px solid var(--bd);border-radius:4px;background:var(--w);cursor:pointer">✓ Todas</button>'
    +   '<button onclick="contLojaSelAll(false)" style="padding:4px 10px;font-size:11px;border:1px solid var(--bd);border-radius:4px;background:var(--w);cursor:pointer">Nenhuma</button>'
    +   '<span id="cont-loja-count" style="font-size:10px;color:var(--t3)"></span>'
    + '</div>'
    + '<div style="overflow-y:auto;padding:8px;flex:1">'+lojaRows+'</div>'
    + '<div style="padding:14px 20px;border-top:1px solid var(--bd);display:flex;gap:8px;justify-content:flex-end">'
    +   '<button onclick="document.getElementById(\'cont-loja-modal\').remove()" style="padding:8px 18px;border:1px solid var(--bd);border-radius:6px;background:var(--w);font-family:inherit;font-size:12px;cursor:pointer">Cancelar</button>'
    +   '<button onclick="contAdmSaveLojas('+i+')" style="padding:8px 18px;background:var(--tx);color:#fff;border:none;border-radius:6px;font-family:inherit;font-size:12px;font-weight:600;cursor:pointer">Guardar</button>'
    + '</div>'
    + '</div>';
  document.body.appendChild(ov);
  ov.addEventListener('click', function(e){ if(e.target===ov) ov.remove(); });
  ov.addEventListener('change', _contUpdateLojaCount);
  _contUpdateLojaCount();
};

window.contAdmSaveLojas = function(i) {
  var modal2 = document.getElementById('cont-loja-modal');
  var scope2 = modal2 || document;
  var checked = Array.from(scope2.querySelectorAll('.cont-loja-chk:checked')).map(function(c){ return c.value; });
  var total = ((typeof ADMCFG!=='undefined'&&ADMCFG&&ADMCFG.lojas)?ADMCFG.lojas:(window.ADMCFG&&window.ADMCFG.lojas)||[]).length;
  var cfg = window.CONT_CFG || contCfgLoad();
  // Se todas seleccionadas, guardar [] (= todas)
  cfg.artigos[i].lojas = (checked.length === total) ? [] : checked;
  _contCfgSave(cfg);
  var modal = document.getElementById('cont-loja-modal');
  if (modal) modal.remove();
  contAdmRender();
  _contAdmMsg('✓ Lojas actualizadas!');
};

window.contAdmToggle = function(i) {
  var cfg = window.CONT_CFG || contCfgLoad();
  cfg.artigos[i].ativo = !(cfg.artigos[i].ativo !== false);
  _contCfgSave(cfg);
  contAdmRender();
};

window.contAdmDelete = function(i) {
  if (!confirm('Remover este artigo da lista de contagens?')) return;
  var cfg = window.CONT_CFG || contCfgLoad();
  cfg.artigos.splice(i, 1);
  _contCfgSave(cfg);
  contAdmRender();
  contAdmSearch(); // refresh results
};

// ══════════════════════════════════════════════════════════════════════════════
// INIT VIEW DE CONTAGENS (para as lojas)
// ══════════════════════════════════════════════════════════════════════════════

// Loja actualmente seleccionada nas contagens
var _contLojaActual = '';


// ════════════════════════════════════════════════════════════════════════════
// ANÁLISE GLOBAL DE CONTAGENS
// ════════════════════════════════════════════════════════════════════════════
var _cgTab = 'dif';

window.cgSetTab = function(t) {
  _cgTab = t;
  ['dif','miss','rank'].forEach(function(id) {
    var btn = document.getElementById('cg-tab-'+id);
    if (!btn) return;
    var on = id === t;
    btn.style.borderBottomColor = on ? 'var(--accent)' : 'transparent';
    btn.style.color = on ? 'var(--accent)' : 'var(--t2)';
  });
  cgRender();
};

window.cgPeriodChange = function() {
  var p = (document.getElementById('cg-period')||{}).value || 'mes';
  var wrap = document.getElementById('cg-period-inputs');
  if (!wrap) return;
  var today = new Date().toISOString().slice(0,10);
  var curMes = today.slice(0,7);
  var curAno = today.slice(0,4);
  var inp = function(type, id, val) {
    return '<div style="display:flex;flex-direction:column;gap:3px"><label style="font-size:10px;font-weight:600;color:var(--t3);text-transform:uppercase;letter-spacing:.04em">'+(type==='date'?'Data':type==='month'?'Mês':'Ano')+'</label>'
      +'<input type="'+type+'" id="'+id+'" value="'+val+'" onchange="cgRender()" style="font-size:11px;padding:5px 8px;border:1px solid var(--bd);border-radius:5px;background:var(--bg);color:var(--tx)"></div>';
  };
  var selAno = function(id) {
    var opts = '';
    for (var y = 2024; y <= 2030; y++) opts += '<option value="'+y+'"'+(y===+curAno?' selected':'')+'>'+y+'</option>';
    return '<div style="display:flex;flex-direction:column;gap:3px"><label style="font-size:10px;font-weight:600;color:var(--t3);text-transform:uppercase;letter-spacing:.04em">Ano</label>'
      +'<select id="'+id+'" onchange="cgRender()" style="font-size:11px;padding:5px 8px;border:1px solid var(--bd);border-radius:5px;background:var(--bg);color:var(--tx)">'+opts+'</select></div>';
  };
  if (p==='dia')   wrap.innerHTML = inp('date','cg-d1',today);
  else if (p==='mes')  wrap.innerHTML = inp('month','cg-m1',curMes);
  else if (p==='ano')  wrap.innerHTML = selAno('cg-a1');
  else wrap.innerHTML = inp('date','cg-r1',today.slice(0,7)+'-01')+inp('date','cg-r2',today);
  cgRender();
};

// Obter datas filtradas segundo o período seleccionado
function _cgDates() {
  var p = (document.getElementById('cg-period')||{}).value || 'mes';
  var data = window.CONT_DATA || contDataLoad();
  var allDates = Object.keys(data).sort();
  if (p==='dia') {
    var d = (document.getElementById('cg-d1')||{}).value || '';
    return d ? allDates.filter(function(x){return x===d;}) : [];
  } else if (p==='mes') {
    var m = (document.getElementById('cg-m1')||{}).value || '';
    return m ? allDates.filter(function(x){return x.slice(0,7)===m;}) : [];
  } else if (p==='ano') {
    var a = (document.getElementById('cg-a1')||{}).value || '';
    return a ? allDates.filter(function(x){return x.slice(0,4)===a;}) : [];
  } else {
    var r1 = (document.getElementById('cg-r1')||{}).value || '';
    var r2 = (document.getElementById('cg-r2')||{}).value || '';
    return (r1&&r2) ? allDates.filter(function(x){return x>=r1&&x<=r2;}) : [];
  }
}

// Obter lojas filtradas
function _cgLojas() {
  var lojaF = (document.getElementById('cg-loja')||{}).value || '';
  var supF  = (document.getElementById('cg-sup')||{}).value  || '';
  var lojas = (typeof ADMCFG!=='undefined'&&ADMCFG&&ADMCFG.lojas)||[];
  return lojas.filter(function(l){
    if (lojaF && l.c !== lojaF) return false;
    if (supF  && l.s !== supF)  return false;
    return true;
  });
}

// Inicializar selects de loja e supervisor
function _cgInitSelects() {
  var ls = document.getElementById('cg-loja');
  var ss = document.getElementById('cg-sup');
  if (!ls || !ss) return;
  if (ls.options.length > 1) return; // já populado
  var lojas = (typeof ADMCFG!=='undefined'&&ADMCFG&&ADMCFG.lojas)||[];
  lojas.sort(function(a,b){return a.c.localeCompare(b.c);}).forEach(function(l){
    var o = document.createElement('option'); o.value=l.c; o.textContent=l.c+' — '+l.n; ls.appendChild(o);
  });
  var sups = [...new Set(lojas.map(function(l){return l.s||'';}).filter(Boolean))].sort();
  sups.forEach(function(s){
    var o = document.createElement('option'); o.value=s; o.textContent=s.split(' ').slice(0,2).join(' '); ss.appendChild(o);
  });
}

window.cgRender = function() {
  _cgInitSelects();
  if (_cgTab==='dif')  cgRenderDif();
  else if (_cgTab==='miss') cgRenderMiss();
  else cgRenderRank();
  // Add click handlers for navigable rows
  setTimeout(function(){
    var el = document.getElementById('cg-body');
    if (!el) return;
    el.querySelectorAll('tr[data-loja]').forEach(function(tr){
      tr.style.cursor='pointer';
      tr.addEventListener('mouseover', function(){ tr.style.filter='brightness(.96)'; });
      tr.addEventListener('mouseout',  function(){ tr.style.filter=''; });
      tr.addEventListener('click', function(){
        var c = tr.getAttribute('data-loja');
        if (c) { window.scrollTo(0,0); contagensLoadLoja(c); }
      });
    });
  }, 50);
};

// ── Tab: Diferenças por loja ──────────────────────────────────────────────
window.cgRenderDif = function() {
  var el = document.getElementById('cg-body'); if (!el) return;
  var dates = _cgDates();
  var lojas = _cgLojas();
  var data  = window.CONT_DATA || contDataLoad();
  var cfg   = window.CONT_CFG  || contCfgLoad();
  var artigos = (cfg.artigos||[]).filter(function(a){return a.ativo!==false;});

  if (!dates.length) { el.innerHTML='<div style="padding:24px;text-align:center;color:var(--t3);font-size:12px">Seleccione um período.</div>'; return; }

  // Para cada loja: calcular nº de diferenças e total de Δ negativo
  var rows = lojas.map(function(l){
    var totalDif = 0, negDif = 0, posDif = 0, contagens = 0;
    dates.forEach(function(d){
      var ld = (data[d]||{})[l.c];
      if (!ld) return;
      var arts = artigos.filter(function(a){ return !a.lojas||!a.lojas.length||a.lojas.indexOf(l.c)>=0; });
      arts.forEach(function(a){
        var prevQtd = null;
        var prevVndAcum = 0;
        TURNOS.forEach(function(t, ti){
          var entry = (ld[t.id]||{});
          var av = entry[a.id];
          var qtd = (av&&typeof av==='object') ? av.qtd : null;
          var ent = (av&&typeof av==='object') ? (av.entrada||0) : 0;
          var qbr = (av&&typeof av==='object') ? (av.quebra||0)  : 0;
          var vndTurno = (av&&typeof av==='object'&&ti>0) ? (av.venda||0) : 0;
          if (ti===0) { if(qtd!==null)prevQtd=qtd; return; }
          if (ti>0 && prevQtd!==null && qtd!==null) {
            var diff = _calcDiff(prevQtd, qtd, ent, qbr, vndTurno, 0);
            if (diff !== 0) totalDif++;
            if (diff < 0) negDif += diff;
            if (diff > 0) posDif += diff;
          }
          if (qtd!==null) { prevQtd=qtd; contagens++; }
        });
      });
    });
    return {c:l.c, n:l.n, s:l.s||'—', totalDif:totalDif, negDif:negDif, posDif:posDif, contagens:contagens};
  }).filter(function(r){return r.contagens>0;}).sort(function(a,b){return a.negDif-b.negDif;});

  if (!rows.length) { el.innerHTML='<div style="padding:24px;text-align:center;color:var(--t3);font-size:12px">Sem registos para o período e filtros seleccionados.</div>'; return; }

  var th = function(t,align){ return '<th style="padding:7px 10px;font-size:10px;font-weight:700;color:var(--t3);text-transform:uppercase;background:var(--s2);border-bottom:1px solid var(--bd);text-align:'+(align||'left')+'">'+t+'</th>'; };

  var trs = rows.map(function(r){
    var negCol = r.negDif<0?'color:var(--red);font-weight:700':'color:var(--t3)';
    var posCol = r.posDif>0?'color:var(--blue);font-weight:600':'color:var(--t3)';
    var difBg  = r.totalDif>0?'background:var(--rbg)':'';
    return '<tr data-loja="'+r.c+'" class="cg-row-link" style="border-bottom:1px solid var(--bd);'+difBg+';cursor:pointer">'
      +'<td style="padding:6px 10px;font-size:11px;font-weight:600;color:var(--accent)">'+r.c+' ↗</td>'
      +'<td style="padding:6px 10px;font-size:11px;color:var(--tx)">'+escHtml(r.n)+'</td>'
      +'<td style="padding:6px 10px;font-size:10px;color:var(--t3)">'+escHtml(r.s)+'</td>'
      +'<td style="padding:6px 10px;font-size:12px;font-weight:700;text-align:center;'+negCol+'">'+r.negDif+'</td>'
      +'<td style="padding:6px 10px;font-size:12px;text-align:center;'+posCol+'">'+r.posDif+'</td>'
      +'<td style="padding:6px 10px;font-size:12px;text-align:center;color:var(--t2)">'+r.totalDif+'</td>'
      +'</tr>';
  }).join('');

  el.innerHTML = '<div style="overflow-x:auto;border:1px solid var(--bd);border-radius:8px">'
    +'<table style="width:100%;border-collapse:collapse">'
    +'<thead><tr>'+th('Centro')+th('Loja')+th('Supervisor')+th('Δ Negativo','center')+th('Δ Positivo','center')+th('Total Dif.','center')+'</tr></thead>'
    +'<tbody>'+trs+'</tbody>'
    +'</table></div>'
    +'<div style="margin-top:8px;display:flex;justify-content:flex-end">'
    +'<button onclick="cgCopiar()" style="font-size:11px;padding:5px 12px;border:1px solid var(--bd);border-radius:5px;background:var(--bg);color:var(--t2);cursor:pointer;font-family:inherit">📋 Copiar lista</button>'
    +'</div>';
};

// ── Tab: Lojas sem contagem ───────────────────────────────────────────────
window.cgRenderMiss = function() {
  var el = document.getElementById('cg-body'); if (!el) return;
  var dates = _cgDates();
  var lojas = _cgLojas();
  var data  = window.CONT_DATA || contDataLoad();

  if (!dates.length) { el.innerHTML='<div style="padding:24px;text-align:center;color:var(--t3);font-size:12px">Seleccione um período.</div>'; return; }

  // Filtro de turno
  var turnoFiltros = ['manha','tarde','noite'];
  var rows = lojas.map(function(l){
    var miss = {manha:0, tarde:0, noite:0, total:0};
    dates.forEach(function(d){
      var ld = (data[d]||{})[l.c];
      turnoFiltros.forEach(function(t){
        if (!ld || !ld[t] || Object.keys(ld[t]).length===0) {
          miss[t]++;
          miss.total++;
        }
      });
    });
    return {c:l.c, n:l.n, s:l.s||'—', miss:miss, dias:dates.length};
  }).filter(function(r){return r.miss.total>0;}).sort(function(a,b){return b.miss.total-a.miss.total;});

  // Cabeçalho com filtro de turno
  var filterBtns = '<div style="display:flex;gap:4px;margin-bottom:10px;flex-wrap:wrap">'
    +['todos','manha','tarde','noite'].map(function(t){
      var labels={todos:'Todos os turnos',manha:'🌅 Manhã',tarde:'☀️ Tarde',noite:'🌙 Noite'};
      return '<button onclick="cgMissTurno(\''+t+'\')" id="cg-miss-btn-'+t+'" style="font-size:11px;padding:4px 10px;border:1px solid var(--bd);border-radius:5px;background:'+(t==='todos'?'var(--tx)':'var(--bg)')+';color:'+(t==='todos'?'#fff':'var(--t2)')+';cursor:pointer;font-family:inherit">'+labels[t]+'</button>';
    }).join('')+'</div>';

  if (!rows.length) {
    el.innerHTML = filterBtns+'<div style="padding:24px;text-align:center;color:var(--green);font-size:13px;font-weight:600">✅ Todas as lojas fizeram contagem no período seleccionado!</div>';
    return;
  }

  var th = function(t,align){ return '<th style="padding:7px 10px;font-size:10px;font-weight:700;color:var(--t3);text-transform:uppercase;background:var(--s2);border-bottom:1px solid var(--bd);text-align:'+(align||'left')+'">'+t+'</th>'; };

  var trs = rows.map(function(r){
    var mCol = r.miss.manha>0?'color:var(--red);font-weight:700':'color:var(--t3)';
    var tCol = r.miss.tarde>0?'color:var(--red);font-weight:700':'color:var(--t3)';
    var nCol = r.miss.noite>0?'color:var(--red);font-weight:700':'color:var(--t3)';
    return '<tr data-loja="'+r.c+'" class="cg-row-link" style="border-bottom:1px solid var(--bd)">'
      +'<td style="padding:6px 10px;font-size:11px;font-weight:600;color:var(--accent)">'+r.c+' ↗</td>'
      +'<td style="padding:6px 10px;font-size:11px;color:var(--tx)">'+escHtml(r.n)+'</td>'
      +'<td style="padding:6px 10px;font-size:10px;color:var(--t3)">'+escHtml(r.s)+'</td>'
      +'<td style="padding:6px 10px;text-align:center;font-size:12px;'+mCol+'">'+r.miss.manha+'/'+r.dias+'</td>'
      +'<td style="padding:6px 10px;text-align:center;font-size:12px;'+tCol+'">'+r.miss.tarde+'/'+r.dias+'</td>'
      +'<td style="padding:6px 10px;text-align:center;font-size:12px;'+nCol+'">'+r.miss.noite+'/'+r.dias+'</td>'
      +'<td style="padding:6px 10px;text-align:center;font-size:12px;color:var(--red);font-weight:700">'+r.miss.total+'</td>'
      +'</tr>';
  }).join('');

  el.innerHTML = filterBtns
    +'<div style="overflow-x:auto;border:1px solid var(--bd);border-radius:8px">'
    +'<table id="cg-miss-table" style="width:100%;border-collapse:collapse">'
    +'<thead><tr>'+th('Centro')+th('Loja')+th('Supervisor')+th('Manhã s/cont.','center')+th('Tarde s/cont.','center')+th('Noite s/cont.','center')+th('Total','center')+'</tr></thead>'
    +'<tbody>'+trs+'</tbody>'
    +'</table></div>'
    +'<div style="margin-top:8px;display:flex;justify-content:flex-end">'
    +'<button onclick="cgCopiarMiss()" style="font-size:11px;padding:5px 12px;border:1px solid var(--bd);border-radius:5px;background:var(--bg);color:var(--t2);cursor:pointer;font-family:inherit">📋 Copiar lista</button>'
    +'</div>';
};

window.cgMissTurno = function(t) {
  // highlight button
  ['todos','manha','tarde','noite'].forEach(function(id){
    var b=document.getElementById('cg-miss-btn-'+id);
    if(!b)return;
    var on=id===t;
    b.style.background=on?'var(--tx)':'var(--bg)';
    b.style.color=on?'#fff':'var(--t2)';
  });
  // filter table rows by turno column visibility
  var tbl = document.getElementById('cg-miss-table');
  if (!tbl) return;
  var cols = {manha:3, tarde:4, noite:5};
  tbl.querySelectorAll('tbody tr').forEach(function(tr){
    if (t==='todos') { tr.style.display=''; return; }
    var ci = cols[t];
    var cell = tr.querySelectorAll('td')[ci];
    var val = cell ? parseInt(cell.textContent) : 0;
    tr.style.display = val>0 ? '' : 'none';
  });
};

// ── Tab: Ranking lojas ────────────────────────────────────────────────────
window.cgRenderRank = function() {
  var el = document.getElementById('cg-body'); if (!el) return;
  var dates = _cgDates();
  var lojas = _cgLojas();
  var data  = window.CONT_DATA || contDataLoad();
  var cfg   = window.CONT_CFG  || contCfgLoad();
  var artigos = (cfg.artigos||[]).filter(function(a){return a.ativo!==false;});

  if (!dates.length) { el.innerHTML='<div style="padding:24px;text-align:center;color:var(--t3);font-size:12px">Seleccione um período.</div>'; return; }

  var rows = lojas.map(function(l){
    var arts = artigos.filter(function(a){ return !a.lojas||!a.lojas.length||a.lojas.indexOf(l.c)>=0; });
    var diaComCont=0, diaTotal=0, turnosOk=0, turnosTotal=0, totalAbsDif=0;
    dates.forEach(function(d){
      diaTotal++;
      var ld = (data[d]||{})[l.c];
      if (ld) diaComCont++;
      TURNOS.forEach(function(t){
        turnosTotal++;
        if (ld&&ld[t.id]&&Object.keys(ld[t.id]).length>0) turnosOk++;
      });
      if (!ld||!arts.length) return;
      arts.forEach(function(a){
        var prevQtd=null;
        var prevVndAcum=0;
        TURNOS.forEach(function(t,ti){
          var entry=(ld[t.id]||{}); var av=entry[a.id];
          var qtd=(av&&typeof av==='object')?av.qtd:null;
          var ent=(av&&typeof av==='object')?(av.entrada||0):0;
          var qbr=(av&&typeof av==='object')?(av.quebra||0):0;
          var vndAcum=(av&&typeof av==='object')?(av.venda||0):0;
          if(ti===0){if(qtd!==null)prevQtd=qtd;prevVndAcum=vndAcum;return;}
          if(prevQtd!==null&&qtd!==null) totalAbsDif+=Math.abs(_calcDiff(prevQtd,qtd,ent,qbr,vndAcum,prevVndAcum));
          if(qtd!==null) prevQtd=qtd;
          if(av!=null) prevVndAcum=vndAcum;
        });
      });
    });
    var pct = turnosTotal>0 ? Math.round(turnosOk/turnosTotal*100) : 0;
    return {c:l.c,n:l.n,s:l.s||'—',pct:pct,diaComCont:diaComCont,diaTotal:diaTotal,totalAbsDif:totalAbsDif};
  }).sort(function(a,b){return b.pct-a.pct||a.totalAbsDif-b.totalAbsDif;});

  if (!rows.length) { el.innerHTML='<div style="padding:24px;text-align:center;color:var(--t3);font-size:12px">Sem dados.</div>'; return; }

  var th = function(t,align){ return '<th style="padding:7px 10px;font-size:10px;font-weight:700;color:var(--t3);text-transform:uppercase;background:var(--s2);border-bottom:1px solid var(--bd);text-align:'+(align||'left')+'">'+t+'</th>'; };

  var trs = rows.map(function(r,i){
    var pctCol = r.pct>=90?'var(--green)':r.pct>=70?'var(--amber)':'var(--red)';
    var medal = i===0?'🥇':i===1?'🥈':i===2?'🥉':String(i+1)+'.';
    return '<tr data-loja="'+r.c+'" class="cg-row-link" style="border-bottom:1px solid var(--bd);cursor:pointer">'
      +'<td style="padding:6px 10px;font-size:13px;text-align:center">'+medal+'</td>'
      +'<td style="padding:6px 10px;font-size:11px;font-weight:600;color:var(--accent)">'+r.c+' ↗</td>'
      +'<td style="padding:6px 10px;font-size:11px;color:var(--tx)">'+escHtml(r.n)+'</td>'
      +'<td style="padding:6px 10px;font-size:10px;color:var(--t3)">'+escHtml(r.s)+'</td>'
      +'<td style="padding:6px 10px;text-align:center"><span style="font-size:13px;font-weight:700;color:'+pctCol+'">'+r.pct+'%</span></td>'
      +'<td style="padding:6px 10px;text-align:center;font-size:12px;color:var(--t2)">'+r.diaComCont+'/'+r.diaTotal+'</td>'
      +'<td style="padding:6px 10px;text-align:center;font-size:12px;color:var(--t2)">'+r.totalAbsDif+'</td>'
      +'</tr>';
  }).join('');

  el.innerHTML = '<div style="overflow-x:auto;border:1px solid var(--bd);border-radius:8px">'
    +'<table style="width:100%;border-collapse:collapse">'
    +'<thead><tr>'+th('#')+th('Centro')+th('Loja')+th('Supervisor')+th('% Turnos OK','center')+th('Dias c/cont.','center')+th('Total |Δ|','center')+'</tr></thead>'
    +'<tbody>'+trs+'</tbody>'
    +'</table></div>';
};

// ── Copiar listas ─────────────────────────────────────────────────────────
window.cgCopiar = function() {
  var dates = _cgDates();
  var lojas = _cgLojas();
  var data  = window.CONT_DATA || contDataLoad();
  var cfg   = window.CONT_CFG  || contCfgLoad();
  var artigos = (cfg.artigos||[]).filter(function(a){return a.ativo!==false;});
  var linhas = ['Centro\tLoja\tSupervisor\tΔ Negativo\tΔ Positivo\tTotal Dif.'];
  lojas.forEach(function(l){
    var negDif=0,posDif=0,totalDif=0,contagens=0;
    dates.forEach(function(d){
      var ld=(data[d]||{})[l.c]; if(!ld)return;
      var arts=artigos.filter(function(a){return !a.lojas||!a.lojas.length||a.lojas.indexOf(l.c)>=0;});
      arts.forEach(function(a){
        var prevQtd=null;
        var prevVndAcum=0;
        TURNOS.forEach(function(t,ti){
          var av=((ld[t.id]||{})[a.id])||null;
          var qtd=(av&&typeof av==='object')?av.qtd:null;
          var ent=(av&&typeof av==='object')?(av.entrada||0):0;
          var qbr=(av&&typeof av==='object')?(av.quebra||0):0;
          var vndAcum=(av&&typeof av==='object')?(av.venda||0):0;
          if(ti===0){if(qtd!==null)prevQtd=qtd;prevVndAcum=vndAcum;return;}
          if(prevQtd!==null&&qtd!==null){var diff=_calcDiff(prevQtd,qtd,ent,qbr,vndAcum,prevVndAcum);if(diff!==0)totalDif++;if(diff<0)negDif+=diff;if(diff>0)posDif+=diff;}
          if(qtd!==null){prevQtd=qtd;contagens++;}
          if(av!=null)prevVndAcum=vndAcum;
        });
      });
    });
    if(contagens>0) linhas.push([l.c,l.n,l.s||'—',negDif,posDif,totalDif].join('\t'));
  });
  navigator.clipboard.writeText(linhas.join('\n')).then(function(){
    alert('✓ Lista copiada! Cola no Excel ou Word.');
  }).catch(function(){ alert(linhas.join('\n')); });
};

window.cgCopiarMiss = function() {
  var dates = _cgDates();
  var lojas = _cgLojas();
  var data  = window.CONT_DATA || contDataLoad();
  var linhas = ['Centro\tLoja\tSupervisor\tManhã s/cont.\tTarde s/cont.\tNoite s/cont.\tTotal'];
  lojas.forEach(function(l){
    var miss={manha:0,tarde:0,noite:0,total:0};
    dates.forEach(function(d){
      var ld=(data[d]||{})[l.c];
      ['manha','tarde','noite'].forEach(function(t){
        if(!ld||!ld[t]||Object.keys(ld[t]).length===0){miss[t]++;miss.total++;}
      });
    });
    if(miss.total>0) linhas.push([l.c,l.n,l.s||'—',miss.manha+'/'+dates.length,miss.tarde+'/'+dates.length,miss.noite+'/'+dates.length,miss.total].join('\t'));
  });
  navigator.clipboard.writeText(linhas.join('\n')).then(function(){
    alert('✓ Lista copiada! Cola no Excel ou Word.');
  }).catch(function(){ alert(linhas.join('\n')); });
};

// Inicializar quando a secção de contagens é aberta
var _cgInited = false;
window.contagensInit = function() {
  // Data padrão: hoje
  var dEl = document.getElementById('cont-date');
  if (dEl && !dEl.value) {
    var n = new Date();
    dEl.value = n.getFullYear()+'-'+String(n.getMonth()+1).padStart(2,'0')+'-'+String(n.getDate()).padStart(2,'0');
  }
  // Ocultar lojas inactivas na sidebar (não presentes em ADMCFG.lojas)
  try {
    var _activeCodes = new Set(((typeof ADMCFG!=='undefined'&&ADMCFG&&ADMCFG.lojas)||[]).map(function(l){ return l.c; }));
    document.querySelectorAll('#cont-sbn .nav-item').forEach(function(el){
      var code = (el.querySelector('.nav-code')||{}).textContent || '';
      if (_activeCodes.size > 0 && !_activeCodes.has(code)) el.style.display = 'none';
    });
  } catch(e) {}
  // Detectar turno automático por hora
  var h = new Date().getHours();
  _contTurno = 'manha';
  _contUpdateTurnoTabs();
  // Se já havia uma loja seleccionada anteriormente, reactivar
  if (_contLojaActual) {
    _contActivarLoja(_contLojaActual);
  } else if (window.AS) {
    contagensLoadLoja(window.AS);
  } else {
    contagensRender();
  }
  // Inicializar modo de filtro do relatório
  setTimeout(function(){ try{ contRelModeChange(); }catch(e){} }, 80);

};

// Seleccionar loja via sidebar
window.contagensLoadLoja = function(c) {
  _contLojaActual = c;
  _contActivarLoja(c);
};

function _contActivarLoja(c) {
  // Highlight na sidebar
  document.querySelectorAll('#cont-sbn .nav-item').forEach(function(el){
    el.classList.toggle('on', el.id === 'cont-nav-'+c);
  });
  // Scroll para o item activo
  var active = document.getElementById('cont-nav-'+c);
  if (active) active.scrollIntoView({block:'nearest'});
  // Actualizar header
  var tag = document.getElementById('cont-loja-tag');
  var sub = document.getElementById('cont-loja-sub');
  var lojaInfo = ((typeof ADMCFG!=='undefined'&&ADMCFG&&ADMCFG.lojas)?ADMCFG.lojas:(window.ADMCFG&&window.ADMCFG.lojas)||[]).find(function(l){ return l.c===c; });
  if (tag) { tag.textContent = c; tag.style.display = ''; }
  if (sub) sub.textContent = lojaInfo ? lojaInfo.n : c;
  contagensRender();
  // Inicializar relatório de diferenças
  setTimeout(function(){ try{ _contRelInit(); }catch(e){} }, 100);
}

// Filtro de pesquisa na sidebar
window.contFiltrarLojas = function(q) {
  var nav = document.getElementById('cont-sbn');
  if (!nav) return;
  var v = q.trim().toLowerCase();
  nav.querySelectorAll('.nav-item').forEach(function(el){
    var code = (el.querySelector('.nav-code')||{}).textContent || '';
    var name = (el.querySelector('.nav-name')||{}).textContent || '';
    el.style.display = (!v || code.toLowerCase().includes(v) || name.toLowerCase().includes(v)) ? '' : 'none';
  });
};

window.contagensSetTurno = function(t) {
  _contTurno = t;
  contagensRender();
};

// ══════════════════════════════════════════════════════════════════════════════
// RENDER FORMULÁRIO DE CONTAGEM (vista das lojas)
// ══════════════════════════════════════════════════════════════════════════════
window.contagensRender = function() {
  _contUpdateTurnoTabs();
  var date  = (document.getElementById('cont-date') || {}).value || '';
  var loja  = _contLojaActual || '';
  var area  = document.getElementById('cont-form-area');
  if (!area) return;

  var cfg = window.CONT_CFG || contCfgLoad();
  // Filtrar artigos activos e que se aplicam a esta loja
  var artigos = (cfg.artigos || []).filter(function(a){
    if (a.ativo === false) return false;
    if (!loja) return true;
    // [] ou ausente = todas as lojas
    if (!a.lojas || !a.lojas.length) return true;
    return a.lojas.indexOf(loja) >= 0;
  });

  if (!artigos.length) {
    area.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);font-size:12px">'
      + (!loja ? 'Seleccione uma loja para registar a contagem.' : 'Nenhum artigo configurado para esta loja.<br>Configure os artigos em <b>Administração → 📦 Contagens</b>.')
      + '</div>';
    _contRenderSummary(date, loja);
    return;
  }
  if (!loja) {
    area.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);font-size:12px">Seleccione uma loja para registar a contagem.</div>';
    return;
  }

  var data = window.CONT_DATA || contDataLoad();
  var saved = _contGetEntry(data, date, loja, _contTurno) || {};

  var isManha = (_contTurno === 'manha');
  var gridCols = isManha ? '2fr 1fr 1fr' : '2fr 1fr 1fr 1fr 1fr';

  var html = '<div style="background:var(--w);border:1px solid var(--bd);border-radius:10px;overflow:hidden">';
  html += '<div style="display:grid;grid-template-columns:'+gridCols+';border-bottom:2px solid var(--bd);background:var(--s2)">';
  html += '<div style="padding:9px 14px;font-size:10px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.04em">Artigo</div>';
  html += '<div style="padding:9px 8px;font-size:10px;font-weight:700;color:var(--tx);text-transform:uppercase;letter-spacing:.04em;text-align:center;border-left:2px solid var(--bd)">Qtd Contada</div>';
  if (!isManha) {
    html += '<div style="padding:9px 8px;font-size:10px;font-weight:700;color:var(--blue);text-transform:uppercase;letter-spacing:.04em;text-align:center">+ Entrada</div>';
  }
  html += '<div style="padding:9px 8px;font-size:10px;font-weight:700;color:var(--red);text-transform:uppercase;letter-spacing:.04em;text-align:center">− Quebras</div>';
  if (!isManha) {
    html += '<div style="padding:9px 8px;font-size:10px;font-weight:700;color:var(--amber);text-transform:uppercase;letter-spacing:.04em;text-align:center">Vendas<div style="font-size:8px;font-weight:400;color:var(--t3);text-transform:none;margin-top:1px">acumulado desde manhã</div></div>';
  }
  html += '</div>';

  artigos.forEach(function(a, i){
    var sv = saved[a.id];
    var sv_qtd    = (sv && typeof sv==='object') ? sv.qtd     : null;
    var sv_ent    = (sv && typeof sv==='object') ? sv.entrada : null;
    var sv_qbr    = (sv && typeof sv==='object') ? sv.quebra  : null;
    var sv_vnd    = (sv && typeof sv==='object') ? sv.venda   : null;
    var rowBg = i%2===0 ? '' : 'background:var(--s2)';
    html += '<div style="display:grid;grid-template-columns:'+gridCols+';border-bottom:1px solid var(--bd);align-items:center;'+rowBg+'">';
    html += '<div style="padding:8px 14px">'
          + '<div style="font-size:12px;font-weight:500;color:var(--tx)">'+escHtml(a.nome)+'</div>'
          + (a.sku ? '<div style="font-size:10px;color:var(--t3)">SKU '+escHtml(a.sku)+'</div>' : '')
          + '</div>';
    // Qtd
    html += '<div style="padding:4px 6px;border-left:2px solid var(--bd)">'
          + _numInp('cont-f-'+a.id+'-qtd', sv_qtd, 'var(--tx)', true)
          + '</div>';
    // Entrada — só Tarde e Noite
    if (!isManha) {
      html += '<div style="padding:4px 6px">' + _numInp('cont-f-'+a.id+'-entrada', sv_ent, 'var(--blue)', false) + '</div>';
    }
    // Quebra
    html += '<div style="padding:4px 6px">' + _numInp('cont-f-'+a.id+'-quebra', sv_qbr, 'var(--red)', false) + '</div>';
    // Venda — só Tarde e Noite
    if (!isManha) {
      html += '<div style="padding:4px 6px">' + _numInp('cont-f-'+a.id+'-venda', sv_vnd, 'var(--amber)', false) + '</div>';
    }
    html += '</div>';
  });
  html += '</div>';

  var notaVal = saved.nota || '';
  html += '<div style="margin-top:10px">'
        + '<label style="font-size:10px;font-weight:600;color:var(--t3);text-transform:uppercase;letter-spacing:.04em;display:block;margin-bottom:4px">Nota / Observação</label>'
        + '<textarea id="cont-nota" rows="2" placeholder="Observações sobre este turno..." style="width:100%;padding:8px 10px;border:1px solid var(--bd);border-radius:6px;font-family:inherit;font-size:12px;color:var(--tx);background:var(--bg);resize:vertical;outline:none">'+escHtml(notaVal)+'</textarea>'
        + '</div>';

  area.innerHTML = html;
  _contRenderSummary(date, loja);
};

function _numInp(id, val, color, bold) {
  return '<input type="number" min="0" step="1" id="'+id+'" value="'+(val!=null?val:'')+'" placeholder="0" '
    + 'style="width:100%;text-align:center;padding:6px 2px;border:1px solid var(--bd);border-radius:5px;font-family:inherit;font-size:13px;font-weight:'+(bold?'700':'400')+';color:'+color+';background:var(--bg);outline:none" '
    + 'onfocus="this.style.borderColor=\'var(--bd2)\';this.select()" onblur="this.style.borderColor=\'var(--bd)\'">';
}

function _contUpdateTurnoTabs(){
  TURNOS.forEach(function(t){
    var btn = document.getElementById('cont-tab-'+t.id);
    if (!btn) return;
    var on = t.id === _contTurno;
    btn.style.borderColor = on ? 'var(--tx)' : 'var(--bd)';
    btn.style.background  = on ? 'var(--tx)' : 'var(--w)';
    btn.style.color       = on ? '#fff' : 'var(--tx)';
    var sp = btn.querySelector('span');
    if (sp) sp.style.color = on ? 'rgba(255,255,255,.6)' : 'var(--t3)';
  });
}

function _contRenderSummary(date, loja) {
  var el = document.getElementById('cont-summary');
  if (!el) return;
  if (!date || !loja) { el.innerHTML = ''; return; }
  var data = window.CONT_DATA || contDataLoad();
  var cfg  = window.CONT_CFG  || contCfgLoad();
  var artigos = (cfg.artigos || []).filter(function(a){
    if (a.ativo === false) return false;
    if (!a.lojas || !a.lojas.length) return true;
    return a.lojas.indexOf(loja) >= 0;
  });
  if (!artigos.length) { el.innerHTML = ''; return; }

  var rows = artigos.map(function(a){
    var cells = '<td style="padding:6px 10px;font-size:11.5px;font-weight:500;color:var(--tx);max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+escHtml(a.nome)+'</td>';
    cells += '<td style="padding:6px 8px;font-size:10px;color:var(--t3);">'+(a.sku||'—')+'</td>';

    // Calcular diferença entre turnos:
    // Stock esperado no turno N = Qtd(N-1) + Entradas(N-1) − Quebras(N-1) − Vendas(N-1)
    // Diferença(N) = Qtd(N) − Stock esperado(N)
    // (no primeiro turno não há turno anterior → sem diferença)
    // Vendas acumuladas são introduzidas como total desde manhã
    // vendas do turno = vendasAcum(turnoActual) - vendasAcum(turnoAnterior)
    var prevQtd = null;    // qtd contada no turno anterior
    var prevVndAcum = 0;   // vendas acumuladas do turno anterior

    TURNOS.forEach(function(t, ti){
      var entry = _contGetEntry(data, date, loja, t.id) || {};
      var av = entry[a.id];
      var qtd = (av&&typeof av==='object') ? av.qtd     : null;
      var ent = (av&&typeof av==='object') ? av.entrada : null;
      var qbr = (av&&typeof av==='object') ? av.quebra  : null;
      var vnd = (av&&typeof av==='object') ? av.venda   : null;
      var done = av != null;
      var ts = entry.ts || 0;
      var over24h = ts && (Date.now() - ts) > 24*60*60*1000;
      // Manhã (ti===0) é sempre a contagem de referência — não tem Δ
      if (ti === 0) {
        if (qtd !== null) prevQtd = qtd;
        // Guardar vendas acumuladas da manhã (normalmente 0)
        prevVndAcum = (av&&typeof av==='object') ? (av.venda||0) : 0;
        return;
      }

      // ── Cálculo da diferença ─────────────────────────────────────────────
      var diffHtml = '';
      if (done && qtd != null && prevQtd !== null) {
        var curEnt = (av&&typeof av==='object') ? (av.entrada||0) : 0;
        var curQbr = (av&&typeof av==='object') ? (av.quebra||0)  : 0;
        // Vendas acumuladas deste turno − vendas acumuladas do turno anterior = vendas deste turno
        var curVndAcum = (av&&typeof av==='object') ? (av.venda||0) : 0;
        var curVnd = Math.max(0, curVndAcum - prevVndAcum);
        var esperado  = prevQtd + curEnt - curQbr - curVnd;
        var diff      = qtd - esperado;
        var diffCol   = diff === 0 ? 'var(--t3)' : diff > 0 ? 'var(--blue)' : 'var(--red)';
        var diffSign  = diff > 0 ? '+' : '';
        var just = (av && typeof av==='object') ? (av.__just__||'') : '';
        diffHtml = '<div style="font-size:10px;font-weight:700;color:'+diffCol+';margin-top:1px;padding:0 3px;border-radius:3px;background:'+(diff===0?'transparent':diff>0?'var(--bbg)':'var(--rbg)')+'">Δ '+diffSign+diff+'</div>'
          + (just && diff!==0 ? '<div title="'+escHtml(just)+'" style="margin-top:2px;font-size:9px;color:var(--t3);font-style:italic;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">💬 '+escHtml(just)+'</div>' : '');
      }

      // Actualizar prevQtd e prevVndAcum para o próximo turno
      if (done && qtd != null) {
        prevQtd = qtd;
      }
      if (done) {
        prevVndAcum = (av&&typeof av==='object') ? (av.venda||0) : prevVndAcum;
      }

      var editIcon = done
        ? (over24h
          ? ' <span title="Mais de 24h — necessita PIN" style="font-size:9px;color:var(--t4);cursor:pointer" onclick="contEditEntry(\"'+date+'\",\"'+loja+'\",\"'+t.id+'\",\"'+a.id+'\",true)">🔒</span>'
          : ' <span title="Editar" style="font-size:9px;color:var(--t3);cursor:pointer;opacity:.6" onclick="contEditEntry(\"'+date+'\",\"'+loja+'\",\"'+t.id+'\",\"'+a.id+'\",false)">✏</span>')
        : '';

      // Calcular vendas do turno para mostrar no sub-texto
      var vndTurnoDisplay = null;
      if (vnd!=null) {
        var _prevAcum = ti===1 ? 0 : prevVndAcum;
        vndTurnoDisplay = Math.max(0, (vnd||0) - _prevAcum);
      }

      var relBtn = done
        ? ' <span title="Ver relatório" style="font-size:9px;color:var(--blue);cursor:pointer;opacity:.7" onclick="contShowRelatorio(\''+date+'\',\''+loja+'\',\''+t.id+'\',\''+a.id+'\')">📊</span>'
        : '';

      var cell = done
        ? '<div style="font-size:12px;font-weight:700;color:var(--tx);cursor:pointer" onclick="contShowRelatorio(\''+date+'\',\''+loja+'\',\''+t.id+'\',\''+a.id+'\')" title="Ver relatório desta contagem">'+(qtd!=null?qtd:'—')+editIcon+'</div>'
          + '<div style="font-size:9px;white-space:nowrap;color:var(--t3)">'
          + (ent!=null?'<span style="color:var(--blue)">+'+ent+'</span> ':'')
          + (qbr!=null?'<span style="color:var(--red)">−'+qbr+'</span> ':'')
          + (vnd!=null?'<span style="color:var(--amber)" title="Vendas acumuladas: '+vnd+' · deste turno: '+vndTurnoDisplay+'">v'+vnd+'</span>':'')
          + '</div>'
          + diffHtml
        : '<div style="font-size:10px;color:var(--t4);cursor:pointer" onclick="contEditEntry(\"'+date+'\",\"'+loja+'\",\"'+t.id+'\",\"'+a.id+'\",false)" title="Registar contagem">＋</div>';

      cells += '<td style="padding:4px 8px;text-align:center;border-left:1px solid var(--bd);cursor:'+(done?'pointer':'default')+'" '+(done?'onclick="contShowRelatorio(\''+date+'\',\''+loja+'\',\''+t.id+'\',\''+a.id+'\')" title="Ver relatório"':'')+'>'
        + cell + '</td>';
    });
    return '<tr style="border-bottom:1px solid var(--bd)">'+cells+'</tr>';
  }).join('');

  el.innerHTML = '<div style="background:var(--w);border:1px solid var(--bd);border-radius:10px;overflow:hidden;overflow-x:auto">'
    + '<div style="padding:8px 12px;border-bottom:1px solid var(--bd);font-size:10px;color:var(--t3);display:flex;align-items:center;gap:10px;flex-wrap:wrap">'
    + '<span>📊 clique na contagem para ver relatório · ✏ ícone lápis para editar · 🔒 &gt;24h requer PIN</span>'
    + '<span style="margin-left:auto;display:flex;align-items:center;gap:8px">'
    + '<span style="background:var(--rbg);color:var(--red);padding:1px 6px;border-radius:3px;font-weight:600">Δ−</span> diferença negativa (menos do esperado)'
    + '<span style="background:var(--bbg);color:var(--blue);padding:1px 6px;border-radius:3px;font-weight:600">Δ+</span> diferença positiva (mais do esperado)'
    + '</span>'
    + '</div>'
    + '<table style="width:100%;border-collapse:collapse;min-width:420px"><thead>'
    + '<tr style="background:var(--s2)">'
    + '<th style="padding:7px 10px;font-size:9.5px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:left">Artigo</th>'
    + '<th style="padding:7px 10px;font-size:9.5px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:left">SKU</th>'
    + TURNOS.filter(function(_,ti){return ti>0;}).map(function(t){ return '<th style="padding:7px 8px;font-size:9.5px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:center;border-left:1px solid var(--bd)">'+t.label+'<div style="font-size:8px;font-weight:400">'+t.hora+'</div></th>'; }).join('')
    + '</tr></thead><tbody>'+rows+'</tbody></table></div>';
}

// ── Relatório detalhado de uma contagem ──────────────────────────────────────
window.contShowRelatorio = function(date, loja, turno, artId) {
  var data = window.CONT_DATA || contDataLoad();
  var cfg  = window.CONT_CFG  || contCfgLoad();
  var art  = (cfg.artigos||[]).find(function(a){ return a.id===artId; }) || {};
  var lojaInfo = (typeof ADMCFG !== 'undefined' && ADMCFG && ADMCFG.lojas || []).find(function(l){ return l.c===loja; });
  var lojaNome = lojaInfo ? (loja+' · '+lojaInfo.n) : loja;

  var TURNO_LABELS = {manha:'🌅 Manhã (07:00)', tarde:'☀️ Tarde (14:00)', noite:'🌙 Noite (21:30)'};
  var TURNO_IDS    = ['manha','tarde','noite'];

  // Recolher dados de todos os turnos para este artigo neste dia
  var rows = [];
  var prevQtd = null, prevVndAcum = 0;

  TURNO_IDS.forEach(function(tid, ti) {
    var entry = _contGetEntry(data, date, loja, tid) || {};
    var av    = entry[artId];
    var qtd   = (av&&typeof av==='object') ? av.qtd     : null;
    var ent   = (av&&typeof av==='object') ? (av.entrada||null) : null;
    var qbr   = (av&&typeof av==='object') ? (av.quebra||null)  : null;
    var vndAcum = (av&&typeof av==='object') ? (av.venda||null) : null;
    var nota  = entry.nota || '';
    var ts    = entry.ts ? new Date(entry.ts).toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'}) : null;
    var done  = av != null;

    var diff = null, esperado = null;
    if (ti > 0 && done && qtd != null && prevQtd !== null) {
      var curEnt = ent||0, curQbr = qbr||0;
      var curVndAcum = vndAcum||0;
      var curVnd = Math.max(0, curVndAcum - prevVndAcum);
      esperado = prevQtd + curEnt - curQbr - curVnd;
      diff = qtd - esperado;
    }

    rows.push({ tid:tid, ti:ti, label:TURNO_LABELS[tid], done:done, qtd:qtd, ent:ent, qbr:qbr, vndAcum:vndAcum, nota:nota, ts:ts, diff:diff, esperado:esperado });

    if (qtd !== null) prevQtd = qtd;
    if (done) prevVndAcum = vndAcum||0;
  });

  // Formatar data
  var dp = date.split('-');
  var dateDisplay = dp[2]+'/'+dp[1]+'/'+dp[0];

  // Highlight o turno seleccionado
  var turnoHighlight = turno;

  function fmtVal(v, prefix, color) {
    if (v == null) return '<span style="color:var(--t4)">—</span>';
    return '<span style="color:'+color+';font-weight:600">'+(prefix||'')+v+'</span>';
  }

  var tableRows = rows.map(function(r) {
    var isActive = r.tid === turnoHighlight;
    var rowBg = isActive ? 'background:var(--asoft);' : (r.ti%2===0?'':'background:var(--s2);');

    var diffCell = '—';
    if (r.ti === 0) {
      diffCell = '<span style="font-size:10px;color:var(--t3)">referência</span>';
    } else if (!r.done) {
      diffCell = '<span style="color:var(--t4)">sem registo</span>';
    } else if (r.diff !== null) {
      var dc = r.diff===0?'var(--green)':r.diff>0?'var(--blue)':'var(--red)';
      var db = r.diff===0?'':'background:'+(r.diff>0?'var(--bbg)':'var(--rbg)')+';';
      diffCell = '<span style="'+db+'color:'+dc+';font-weight:700;padding:2px 8px;border-radius:4px">'+(r.diff>0?'+':'')+r.diff+'</span>';
      if (r.esperado !== null) diffCell += '<div style="font-size:9px;color:var(--t3);margin-top:2px">esperado: '+r.esperado+'</div>';
    }

    var tsDisplay = r.ts ? '<div style="font-size:9px;color:var(--t3);margin-top:2px">⏱ '+r.ts+'</div>' : '';
    var notaDisplay = r.nota ? '<div style="font-size:9px;color:var(--t3);margin-top:2px;font-style:italic">💬 '+escHtml(r.nota)+'</div>' : '';

    return '<tr style="border-bottom:1px solid var(--bd);'+rowBg+(isActive?'outline:2px solid var(--accent);outline-offset:-2px;':'')+'border-left:'+(isActive?'3px solid var(--accent)':'3px solid transparent')+';">'
      + '<td style="padding:8px 12px;font-size:12px;font-weight:'+(isActive?'700':'500')+';color:'+(isActive?'var(--accent)':'var(--t2)')+'">'+r.label+tsDisplay+'</td>'
      + '<td style="padding:8px 10px;text-align:center;font-size:13px;font-weight:700;color:var(--tx)">'+(r.done?(r.qtd!=null?r.qtd:'—'):'<span style="color:var(--t4);font-size:11px">não registado</span>')+'</td>'
      + '<td style="padding:8px 10px;text-align:center">'+fmtVal(r.ent,'+','var(--blue)')+'</td>'
      + '<td style="padding:8px 10px;text-align:center">'+fmtVal(r.qbr,'−','var(--red)')+'</td>'
      + '<td style="padding:8px 10px;text-align:center">'+fmtVal(r.vndAcum,'','var(--amber)')+'</td>'
      + '<td style="padding:8px 12px;text-align:center">'+diffCell+notaDisplay+'</td>'
      + '</tr>';
  }).join('');

  var existing = document.getElementById('cont-rel-popup');
  if (existing) existing.remove();

  var ov = document.createElement('div');
  ov.id = 'cont-rel-popup';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9800;display:flex;align-items:center;justify-content:center;padding:16px';

  ov.innerHTML =
    '<div style="background:var(--w);border-radius:14px;width:680px;max-width:98vw;max-height:90vh;overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,.3);display:flex;flex-direction:column">'
    // Header
    + '<div style="padding:16px 20px;border-bottom:1px solid var(--bd);display:flex;align-items:flex-start;gap:12px">'
    +   '<div style="flex:1">'
    +     '<div style="font-size:14px;font-weight:700;color:var(--tx);display:flex;align-items:center;gap:8px">'
    +       '📊 Relatório de Contagem'
    +       '<span style="font-size:11px;font-weight:600;background:var(--asoft);color:var(--accent);border-radius:5px;padding:2px 8px">'+dateDisplay+'</span>'
    +     '</div>'
    +     '<div style="font-size:11px;color:var(--t3);margin-top:3px">'+escHtml(lojaNome)+' · '+escHtml(art.nome||artId)+(art.sku?' (SKU '+escHtml(art.sku)+')':'')+'</div>'
    +   '</div>'
    +   '<button onclick="document.getElementById(\'cont-rel-popup\').remove()" style="padding:6px 10px;border:1px solid var(--bd);border-radius:7px;background:var(--bg);font-family:inherit;font-size:18px;cursor:pointer;color:var(--t2);line-height:1;flex-shrink:0">×</button>'
    + '</div>'
    // Table
    + '<div style="overflow-y:auto;flex:1">'
    +   '<table style="width:100%;border-collapse:collapse">'
    +   '<thead><tr style="background:var(--s2);position:sticky;top:0">'
    +     '<th style="padding:8px 12px;font-size:9.5px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:left;letter-spacing:.05em">Turno</th>'
    +     '<th style="padding:8px 10px;font-size:9.5px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:center;letter-spacing:.05em">Qtd Contada</th>'
    +     '<th style="padding:8px 10px;font-size:9.5px;font-weight:600;color:var(--blue);text-transform:uppercase;text-align:center;letter-spacing:.05em">+ Entrada</th>'
    +     '<th style="padding:8px 10px;font-size:9.5px;font-weight:600;color:var(--red);text-transform:uppercase;text-align:center;letter-spacing:.05em">− Quebras</th>'
    +     '<th style="padding:8px 10px;font-size:9.5px;font-weight:600;color:var(--amber);text-transform:uppercase;text-align:center;letter-spacing:.05em">Vendas (acum.)</th>'
    +     '<th style="padding:8px 12px;font-size:9.5px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:center;letter-spacing:.05em">Δ Diferença</th>'
    +   '</tr></thead>'
    +   '<tbody>'+tableRows+'</tbody>'
    +   '</table>'
    + '</div>'
    // Legend
    + '<div style="padding:10px 16px;border-top:1px solid var(--bd);background:var(--s2);display:flex;gap:14px;flex-wrap:wrap;font-size:10px;color:var(--t3)">'
    +   '<span>A linha destacada é a contagem seleccionada.</span>'
    +   '<span><b style="color:var(--red)">Δ−</b> stock inferior ao esperado</span>'
    +   '<span><b style="color:var(--blue)">Δ+</b> stock superior ao esperado</span>'
    +   '<span><b style="color:var(--green)">Δ0</b> sem diferença</span>'
    + '</div>'
    + '</div>';

  document.body.appendChild(ov);
  ov.addEventListener('click', function(e){ if(e.target===ov) ov.remove(); });
};

// ── Editar entrada do resumo ──────────────────────────────────────────────────
window.contEditEntry = function(date, loja, turno, artId, requirePin) {
  function _openEditModal(date, loja, turno, artId) {
    var data = window.CONT_DATA || contDataLoad();
    var entry = _contGetEntry(data, date, loja, turno) || {};
    var av = entry[artId] || {};
    var cfg = window.CONT_CFG || contCfgLoad();
    var art = (cfg.artigos||[]).find(function(a){ return a.id===artId; }) || {};
    var turnoLabel = {manha:'🌅 Manhã 7h', tarde:'☀️ Tarde 14h', noite:'🌙 Noite 21h30'};
    var ts = entry.ts ? new Date(entry.ts).toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'}) : '';

    var existing = document.getElementById('cont-edit-modal');
    if (existing) existing.remove();

    var ov = document.createElement('div');
    ov.id = 'cont-edit-modal';
    ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9500;display:flex;align-items:center;justify-content:center;padding:20px';
    ov.innerHTML =
      '<div style="background:var(--w);border-radius:12px;width:380px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.25)">'
      + '<div style="padding:16px 20px;border-bottom:1px solid var(--bd)">'
      +   '<div style="font-size:13px;font-weight:700;color:var(--tx)">✏ Editar contagem</div>'
      +   '<div style="font-size:11px;color:var(--t3);margin-top:2px">'+escHtml(art.nome||artId)+' · '+(turnoLabel[turno]||turno)+' · '+date+(ts?' · subm. '+ts:'')+'</div>'
      + '</div>'
      + '<div style="padding:16px 20px;display:grid;grid-template-columns:1fr 1fr;gap:10px">'
      + _editFld('Qtd Contada','ce-qtd', av.qtd!=null?av.qtd:'','var(--tx)',true)
      + _editFld('+Entrada','ce-ent', av.entrada!=null?av.entrada:'','var(--blue)',false)
      + _editFld('−Quebras','ce-qbr', av.quebra!=null?av.quebra:'','var(--red)',false)
      + _editFld('Vendas (acum.)','ce-vnd', av.venda!=null?av.venda:'','var(--amber)',false)
      + '</div>'
      + '<div style="padding:0 20px 16px">'
      +   '<label style="font-size:10px;font-weight:600;color:var(--t3);text-transform:uppercase;letter-spacing:.04em;display:block;margin-bottom:4px">Nota</label>'
      +   '<input id="ce-nota" type="text" value="'+escHtml(entry.nota||'')+'" placeholder="Observação opcional..." style="width:100%;padding:7px 10px;border:1px solid var(--bd);border-radius:5px;font-family:inherit;font-size:12px;color:var(--tx);background:var(--bg);outline:none;box-sizing:border-box">'
      + '</div>'
      + '<div style="padding:14px 20px;border-top:1px solid var(--bd);display:flex;gap:8px;justify-content:flex-end">'
      +   '<button onclick="document.getElementById(\'cont-edit-modal\').remove()" style="padding:8px 16px;border:1px solid var(--bd);border-radius:6px;background:var(--w);font-family:inherit;font-size:12px;cursor:pointer">Cancelar</button>'
      +   '<button onclick="window._contEditSaveArgs&&contEditSave(window._contEditSaveArgs[0],window._contEditSaveArgs[1],window._contEditSaveArgs[2],window._contEditSaveArgs[3])" style="padding:8px 20px;background:var(--tx);color:#fff;border:none;border-radius:6px;font-family:inherit;font-size:12px;font-weight:600;cursor:pointer">Guardar</button>'
      + '</div>'
      + '</div>';
    window._contEditSaveArgs = [date, loja, turno, artId];
    document.body.appendChild(ov);
    ov.addEventListener('click', function(e){ if(e.target===ov) ov.remove(); });
    var first = document.getElementById('ce-qtd');
    if (first) { first.focus(); first.select(); }
  }

  if (!requirePin) {
    _openEditModal(date, loja, turno, artId);
    return;
  }

  // Pedir PIN de administrador
  var pinOv = document.createElement('div');
  pinOv.id = 'cont-pin-modal';
  pinOv.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9600;display:flex;align-items:center;justify-content:center;padding:20px';
  pinOv.innerHTML =
    '<div style="background:var(--w);border-radius:12px;width:320px;max-width:95vw;padding:24px;box-shadow:0 20px 60px rgba(0,0,0,.3)">'
    + '<div style="font-size:15px;font-weight:700;margin-bottom:6px">🔒 Edição bloqueada</div>'
    + '<div style="font-size:12px;color:var(--t3);margin-bottom:18px">Esta contagem tem mais de 24h.<br>Introduza o PIN de administrador para editar.</div>'
    + '<input type="password" id="cont-pin-inp" placeholder="PIN..." maxlength="10" autocomplete="off" style="width:100%;padding:10px 12px;border:2px solid var(--bd);border-radius:7px;font-family:inherit;font-size:16px;letter-spacing:4px;text-align:center;background:var(--bg);color:var(--tx);outline:none;box-sizing:border-box">'
    + '<div id="cont-pin-msg" style="font-size:11px;color:var(--red);min-height:16px;margin-top:6px;text-align:center"></div>'
    + '<div style="display:flex;gap:8px;margin-top:14px">'
    +   '<button onclick="document.getElementById(\'cont-pin-modal\').remove()" style="flex:1;padding:9px;border:1px solid var(--bd);border-radius:6px;background:var(--w);font-family:inherit;font-size:12px;cursor:pointer">Cancelar</button>'
    +   '<button id="cont-pin-ok" style="flex:1;padding:9px;background:var(--tx);color:#fff;border:none;border-radius:6px;font-family:inherit;font-size:12px;font-weight:600;cursor:pointer">Confirmar</button>'
    + '</div>'
    + '</div>';
  document.body.appendChild(pinOv);
  pinOv.addEventListener('click', function(e){ if(e.target===pinOv) pinOv.remove(); });

  var pinInp = document.getElementById('cont-pin-inp');
  if (pinInp) pinInp.focus();

  function _checkPin() {
    var entered = (document.getElementById('cont-pin-inp')||{}).value || '';
    var correct = (window.ADMCFG && window.ADMCFG.admin_pin) ? window.ADMCFG.admin_pin : '5566';
    var msg = document.getElementById('cont-pin-msg');
    if (entered === correct) {
      pinOv.remove();
      _openEditModal(date, loja, turno, artId);
    } else {
      if (msg) { msg.textContent = 'PIN incorrecto.'; }
      if (pinInp) { pinInp.value=''; pinInp.style.borderColor='var(--red)'; pinInp.focus(); setTimeout(function(){ pinInp.style.borderColor='var(--bd)'; }, 1500); }
    }
  }

  document.getElementById('cont-pin-ok').onclick = _checkPin;
  if (pinInp) pinInp.onkeydown = function(e){ if(e.key==='Enter') _checkPin(); };
};

function _editFld(label, id, val, color, bold) {
  return '<div>'
    + '<label style="font-size:10px;font-weight:600;color:var(--t3);text-transform:uppercase;letter-spacing:.04em;display:block;margin-bottom:4px">'+label+'</label>'
    + '<input type="number" min="0" step="1" id="'+id+'" value="'+(val!==''?val:'')+'" placeholder="0" '
    + 'style="width:100%;padding:8px 10px;border:1px solid var(--bd);border-radius:5px;font-family:inherit;font-size:14px;font-weight:'+(bold?'700':'400')+';color:'+color+';background:var(--bg);outline:none;text-align:center;box-sizing:border-box" '
    + 'onfocus="this.style.borderColor=\'var(--bd2)\';this.select()" onblur="this.style.borderColor=\'var(--bd)\'">'  
    + '</div>';
}

window.contEditSave = function(date, loja, turno, artId) {
  var qtd  = document.getElementById('ce-qtd');
  var ent  = document.getElementById('ce-ent');
  var qbr  = document.getElementById('ce-qbr');
  var vnd  = document.getElementById('ce-vnd');
  var nota = document.getElementById('ce-nota');

  var data = window.CONT_DATA || contDataLoad();
  if (!data[date]) data[date] = {};
  if (!data[date][loja]) data[date][loja] = {};
  if (!data[date][loja][turno]) data[date][loja][turno] = { __ts__: Date.now() };

  var entry = data[date][loja][turno];
  // Guardar nota
  var notaVal = (nota && nota.value.trim()) ? nota.value.trim() : undefined;
  if (notaVal) entry.nota = notaVal; else delete entry.nota;
  // Actualizar __ts__ de edição
  entry.__ts_edit__ = Date.now();

  // Actualizar este artigo na entry
  var rec = entry[artId] || {};
  if (typeof rec !== 'object') rec = {};
  if (qtd && qtd.value !== '') rec.qtd = Number(qtd.value); else delete rec.qtd;
  if (ent && ent.value !== '') rec.entrada = Number(ent.value); else delete rec.entrada;
  if (qbr && qbr.value !== '') rec.quebra = Number(qbr.value); else delete rec.quebra;
  if (vnd && vnd.value !== '') rec.venda = Number(vnd.value); else delete rec.venda;

  if (Object.keys(rec).length) entry[artId] = rec;
  else delete entry[artId];

  window.CONT_DATA = data;
  try { localStorage.setItem(CONT_DATA_KEY, JSON.stringify(data)); } catch(e) {}

  // Gravar no Firebase (inventory_counts — mesmo caminho que contagensSave)
  try {
    if (window.fbWriteInventoryCount) window.fbWriteInventoryCount(date, loja, turno, entry).catch(function(e){ window._KARTA_DEBUG&&console.warn('[CONT] edit write error:', e); });
  } catch(e) {}

  var modal = document.getElementById('cont-edit-modal');
  if (modal) modal.remove();

  // Re-render resumo
  window.CONT_DATA = contDataLoad();
  var _date = (document.getElementById('cont-date')||{}).value || date;
  var _loja = _contLojaActual || loja;
  _contRenderSummary(_date, _loja);
};

// ══════════════════════════════════════════════════════════════════════════════
// GRAVAR CONTAGEM
// ══════════════════════════════════════════════════════════════════════════════
window.contagensSave = function() {
  var date = (document.getElementById('cont-date') || {}).value || '';
  var loja = _contLojaActual || '';
  var nota = ((document.getElementById('cont-nota') || {}).value || '').trim();
  if (!date || !loja) { _contMsg('⚠ Seleccione a data e a loja.', 'amber'); return; }

  var cfg = window.CONT_CFG || contCfgLoad();
  var artigos = (cfg.artigos || []).filter(function(a){
    if (a.ativo === false) return false;
    if (!a.lojas || !a.lojas.length) return true;
    return a.lojas.indexOf(loja) >= 0;
  });
  if (!artigos.length) { _contMsg('⚠ Nenhum artigo configurado para esta loja.', 'amber'); return; }

  var data = window.CONT_DATA || contDataLoad();
  if (!data[date]) data[date] = {};
  if (!data[date][loja]) data[date][loja] = {};

  var entry = { __ts__: Date.now() };
  if (nota) entry.__nota__ = nota;

  artigos.forEach(function(a){
    var qtd    = document.getElementById('cont-f-'+a.id+'-qtd');
    var entrada= document.getElementById('cont-f-'+a.id+'-entrada');
    var quebra = document.getElementById('cont-f-'+a.id+'-quebra');
    var venda  = document.getElementById('cont-f-'+a.id+'-venda');
    var rec = {};
    if (qtd    && qtd.value    !== '') rec.qtd     = Number(qtd.value);
    if (entrada&& entrada.value !== '') rec.entrada = Number(entrada.value);
    if (quebra && quebra.value  !== '') rec.quebra  = Number(quebra.value);
    if (venda  && venda.value   !== '') rec.venda   = Number(venda.value);
    if (Object.keys(rec).length) entry[a.id] = rec;
  });

  data[date][loja][_contTurno] = entry;
  window.CONT_DATA = data;
  try { localStorage.setItem(CONT_DATA_KEY, JSON.stringify(data)); } catch(e) {}

  // Granular Firebase write em coleção separada inventory_counts
  if (window.fbWriteInventoryCount) {
    window.fbWriteInventoryCount(date, loja, _contTurno, entry)
      .then(function(){ window._KARTA_DEBUG&&console.log('[CONT] gravado no Firestore OK:', date, loja, _contTurno); })
      .catch(function(e){ console.error('[CONT] ERRO ao gravar no Firestore:', e); _contMsg('⚠ Erro ao sincronizar com Firebase: '+e.message, 'red'); });
  }

  _contMsg('✓ Contagem gravada!', 'green');
  setTimeout(function(){ _contMsg('',''); }, 4000);
  // NÃO fazer contDataLoad() aqui — mantém window.CONT_DATA actualizado em memória
  _contRenderSummary(date, loja);

  // Pop-up com diferenças
  _contPopupDiffs(date, loja, artigos, entry);
};

function _contPopupDiffs(date, loja, artigos, entry) {
  var data = window.CONT_DATA || contDataLoad();
  var TURNO_IDX = TURNOS.findIndex(function(t){ return t.id === _contTurno; });
  if (TURNO_IDX <= 0) return;

  var prevTurno = TURNOS[TURNO_IDX - 1].id;
  var prevEntry = _contGetEntry(data, date, loja, prevTurno) || {};

  var diffs = [];
  artigos.forEach(function(a) {
    var av = entry[a.id];
    if (!av || av.qtd == null) return;
    var prevAv = prevEntry[a.id];
    var prevQtd = (prevAv && typeof prevAv === 'object') ? prevAv.qtd : null;
    if (prevQtd === null) return;
    var curEnt = av.entrada || 0, curQbr = av.quebra || 0, curVnd = av.venda || 0;
    var esperado = prevQtd + curEnt - curQbr - curVnd;
    var diff = av.qtd - esperado;
    if (diff !== 0) diffs.push({ artId: a.id, nome: a.nome, diff: diff, qtd: av.qtd, esperado: Math.round(esperado*100)/100 });
  });

  var oldP = document.getElementById('_cont-popup-diffs');
  if (oldP) oldP.remove();

  var turnoLabel = TURNOS[TURNO_IDX].label;
  var body;

  if (!diffs.length) {
    body = '<div style="display:flex;align-items:center;gap:10px;padding:16px;background:#f0fdf4;border-radius:10px">'
      + '<span style="font-size:28px">✅</span>'
      + '<div><div style="font-size:14px;font-weight:700;color:#166534">Sem diferenças!</div>'
      + '<div style="font-size:12px;color:#166534;margin-top:2px">Todos os artigos estão conforme o esperado.</div></div>'
      + '</div>';
  } else {
    var rows = diffs.map(function(d, di) {
      var col = d.diff > 0 ? '#1d4ed8' : '#dc2626';
      var bg  = d.diff > 0 ? '#eff6ff' : '#fef2f2';
      var sign = d.diff > 0 ? '+' : '';
      return '<div style="padding:10px 14px;background:'+bg+';border-radius:8px;margin-bottom:8px">'
        + '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">'
        + '<div>'
        + '<div style="font-size:13px;font-weight:600;color:var(--tx)">'+escHtml(d.nome)+'</div>'
        + '<div style="font-size:11px;color:var(--t3);margin-top:1px">Contado: <b>'+d.qtd+'</b> · Esperado: <b>'+d.esperado+'</b></div>'
        + '</div>'
        + '<span style="font-size:18px;font-weight:800;color:'+col+'">'+sign+d.diff+'</span>'
        + '</div>'
        + '<label style="font-size:10px;font-weight:700;color:'+col+';text-transform:uppercase;letter-spacing:.04em">Justificação *</label>'
        + '<textarea id="_pj-'+di+'" rows="2" placeholder="Explique a diferença de '+sign+d.diff+' un..." style="width:100%;margin-top:4px;padding:7px 10px;border:2px solid '+col+';border-radius:6px;font-family:inherit;font-size:12px;resize:none;outline:none;box-sizing:border-box;background:var(--w);color:var(--tx)"></textarea>'
        + '</div>';
    }).join('');
    body = '<div style="margin-bottom:12px;font-size:12px;color:var(--t3)">'
      + diffs.length+' artigo(s) com diferença no turno <b>'+turnoLabel+'</b> — justificação obrigatória:'
      + '</div>' + rows
      + '<div id="_pj-err" style="display:none;margin-top:6px;font-size:12px;color:#dc2626;font-weight:600">⚠ Preencha todas as justificações para continuar.</div>';
  }

  var popup = document.createElement('div');
  popup.id = '_cont-popup-diffs';
  popup.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:20px;font-family:var(--font-sans,Inter,system-ui,sans-serif)';
  popup.innerHTML = '<div style="background:var(--w);border-radius:16px;padding:24px;width:100%;max-width:460px;box-shadow:0 20px 60px rgba(0,0,0,.25);max-height:85vh;overflow-y:auto">'
    + '<div style="font-size:15px;font-weight:700;color:var(--tx);margin-bottom:16px">📋 Resumo da Contagem</div>'
    + body
    + '<button id="_cont-popup-ok" style="width:100%;margin-top:16px;padding:11px;background:var(--tx);color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit">'+(diffs.length?'Confirmar':'OK')+'</button>'
    + '</div>';

  document.body.appendChild(popup);

  function close() { popup.remove(); }

  document.getElementById('_cont-popup-ok').addEventListener('click', function() {
    if (!diffs.length) { close(); return; }
    // Validar justificações
    var tas = popup.querySelectorAll('textarea[id^="_pj-"]');
    var ok = true;
    tas.forEach(function(ta){ if (!ta.value.trim()){ ta.style.borderColor='#dc2626'; ok=false; } else { ta.style.borderColor=''; } });
    if (!ok) { var e=document.getElementById('_pj-err'); if(e) e.style.display='block'; return; }
    // Guardar justificações no entry
    tas.forEach(function(ta, i) {
      var artId = diffs[i].artId;
      if (entry[artId] && typeof entry[artId]==='object') entry[artId].__just__ = ta.value.trim();
    });
    // Persistir com justificações
    var d2 = window.CONT_DATA || {};
    if (d2[date] && d2[date][loja]) d2[date][loja][_contTurno] = entry;
    try { localStorage.setItem(CONT_DATA_KEY, JSON.stringify(d2)); } catch(e2) {}
    if (window.fbWriteInventoryCount) fbWriteInventoryCount(date, loja, _contTurno, entry).catch(function(){});
    close();
  });
  // Só fechar ao clicar fora se não houver diffs obrigatórias
  popup.addEventListener('click', function(e){ if (e.target === popup && !diffs.length) close(); });
}

// ══════════════════════════════════════════════════════════════════════════════
// ADMIN — ver dados submetidos
// ══════════════════════════════════════════════════════════════════════════════
window.contAdmDataRender = function() {
  var el    = document.getElementById('cont-adm-data-table');
  if (!el) return;
  var date  = (document.getElementById('cont-adm-date')  ||{}).value||'';
  var loja  = (document.getElementById('cont-adm-loja')  ||{}).value||'';
  var turno = (document.getElementById('cont-adm-turno') ||{}).value||'';

  var data = window.CONT_DATA || contDataLoad();
  var cfg  = window.CONT_CFG  || contCfgLoad();
  var artigos = cfg.artigos || [];
  var lojas = (window.ADMCFG && window.ADMCFG.lojas) || [];

  var rows = [];
  Object.keys(data).sort().reverse().forEach(function(d){
    if (date && d !== date) return;
    Object.keys(data[d]||{}).forEach(function(l){
      if (loja && l !== loja) return;
      var lojaInfo = lojas.find(function(x){ return x.c===l; });
      var lojaNome = lojaInfo ? lojaInfo.n : l;
      Object.keys(data[d][l]||{}).forEach(function(t){
        if (turno && t !== turno) return;
        var entry = data[d][l][t];
        if (!entry || typeof entry !== 'object') return;
        rows.push({d:d, l:l, lojaNome:lojaNome, t:t, entry:entry});
      });
    });
  });

  if (!rows.length) {
    el.innerHTML = '<div style="padding:24px;text-align:center;color:var(--t3);font-size:12px">Sem registos para os filtros seleccionados.</div>';
    return;
  }

  var turnoLabel = {manha:'🌅 Manhã 7h', tarde:'☀️ Tarde 14h', noite:'🌙 Noite 21h30'};
  var html = '';
  rows.forEach(function(r){
    var ts = r.entry.ts ? new Date(r.entry.ts).toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'}) : '';
    html += '<div style="border-bottom:1px solid var(--bd)">';
    html += '<div style="padding:8px 16px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;background:var(--s2)">'
          + '<span style="font-size:12px;font-weight:700;color:var(--tx)">'+r.l+' — '+escHtml(r.lojaNome)+'</span>'
          + '<span style="font-size:11px;color:var(--t2)">'+r.d+'</span>'
          + '<span style="font-size:11px;font-weight:600;color:var(--blue);background:var(--bbg);padding:2px 8px;border-radius:4px">'+(turnoLabel[r.t]||r.t)+'</span>'
          + (ts?'<span style="font-size:10px;color:var(--t3);margin-left:auto">'+ts+'</span>':'')
          + '</div>';
    html += '<table style="width:100%;border-collapse:collapse"><thead><tr style="background:var(--s2)">'
          + '<th style="padding:5px 12px;font-size:9px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:left">Artigo</th>'
          + '<th style="padding:5px 8px;font-size:9px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:center">Qtd</th>'
          + '<th style="padding:5px 8px;font-size:9px;font-weight:600;color:var(--blue);text-transform:uppercase;text-align:center">+Entrada</th>'
          + '<th style="padding:5px 8px;font-size:9px;font-weight:600;color:var(--red);text-transform:uppercase;text-align:center">−Quebra</th>'
          + '<th style="padding:5px 8px;font-size:9px;font-weight:600;color:var(--amber);text-transform:uppercase;text-align:center">−Venda</th>'
          + '</tr></thead><tbody>';
    var hasAny = false;
    artigos.forEach(function(a){
      var av = r.entry[a.id];
      if (!av) return;
      hasAny = true;
      var qtd = (av&&typeof av==='object') ? av.qtd     : av;
      var ent = (av&&typeof av==='object') ? av.entrada : null;
      var qbr = (av&&typeof av==='object') ? av.quebra  : null;
      var vnd = (av&&typeof av==='object') ? av.venda   : null;
      html += '<tr style="border-bottom:1px solid var(--bd)">'
            + '<td style="padding:5px 12px;font-size:11.5px;color:var(--tx)">'+escHtml(a.nome)
            + (a.sku?'<span style="font-size:9px;color:var(--t3);margin-left:5px">'+escHtml(a.sku)+'</span>':'')+'</td>'
            + '<td style="padding:5px 8px;text-align:center;font-size:12px;font-weight:700;color:var(--tx)">'+(qtd!=null?qtd:'—')+'</td>'
            + '<td style="padding:5px 8px;text-align:center;font-size:12px;color:var(--blue)">'+(ent!=null?'+'+ent:'—')+'</td>'
            + '<td style="padding:5px 8px;text-align:center;font-size:12px;color:var(--red)">'+(qbr!=null?'−'+qbr:'—')+'</td>'
            + '<td style="padding:5px 8px;text-align:center;font-size:12px;color:var(--amber)">'+(vnd!=null?'−'+vnd:'—')+'</td>'
            + '</tr>';
    });
    if (!hasAny) html += '<tr><td colspan="5" style="padding:8px 12px;font-size:11px;color:var(--t3)">Sem dados de artigos neste registo.</td></tr>';
    html += '</tbody></table>';
    if (r.entry.nota) {
      html += '<div style="padding:7px 14px;font-size:11px;color:var(--t2);border-top:1px solid var(--bd);background:var(--s2)">📝 '+escHtml(r.entry.nota)+'</div>';
    }
    html += '</div>';
  });
  el.innerHTML = '<div style="border:1px solid var(--bd);border-radius:8px;overflow:hidden">'+html+'</div>';
};

// ══════════════════════════════════════════════════════════════════════════════
// HOOK switchAdmTab
// ══════════════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════════════
// RELATÓRIO MASTER — diferenças por loja/dia
// ══════════════════════════════════════════════════════════════════════════════
function _mToday(){var n=new Date();return n.getFullYear()+'-'+String(n.getMonth()+1).padStart(2,'0')+'-'+String(n.getDate()).padStart(2,'0');}

window.contMasterModeChange = function() {
  var mode=(document.getElementById('cont-master-mode')||{}).value||'dia';
  var wrap=document.getElementById('cont-master-date-wrap'); if(!wrap) return;
  var today=_mToday(), s='font-size:11px;padding:5px 8px;border:1px solid var(--bd);border-radius:5px;background:var(--bg);color:var(--tx)';
  if(mode==='dia'){
    wrap.innerHTML='<input type="date" id="cont-master-date" value="'+today+'" onchange="contMasterRender()" style="'+s+'">';
  } else if(mode==='mes'){
    wrap.innerHTML='<input type="month" id="cont-master-mes" value="'+today.slice(0,7)+'" onchange="contMasterRender()" style="'+s+'">';
  } else if(mode==='ano'){
    var yr=today.slice(0,4);
    wrap.innerHTML='<select id="cont-master-ano" onchange="contMasterRender()" style="'+s+'">'
      +[yr,String(parseInt(yr)-1)].map(function(y){return'<option value="'+y+'"'+(y===yr?' selected':'')+'>'+y+'</option>';}).join('')+'</select>';
  } else { // tudo
    wrap.innerHTML='<span style="font-size:11px;color:var(--t3);padding:5px 0">Todos os registos</span>';
  }
  contMasterRender();
};

function _mDateOk(d){
  var mode=(document.getElementById('cont-master-mode')||{}).value||'dia';
  if(mode==='tudo') return true;
  if(mode==='dia'){var el=document.getElementById('cont-master-date');var v=el?el.value:'';return !v||d===v;}
  if(mode==='mes'){var el2=document.getElementById('cont-master-mes');var v2=el2?el2.value:'';return !v2||d.startsWith(v2);}
  var el3=document.getElementById('cont-master-ano');var v3=el3?el3.value:'';return !v3||d.startsWith(v3);
}

function _mCalcDiff(lojaData, artId) {
  var pQ=null,pV=null,tot=0,ok=false;
  TURNOS.forEach(function(t){
    var av=(lojaData[t.id]||{})[artId];
    if(!av||typeof av!=='object') return;
    var q=av.qtd!=null?av.qtd:null, e=av.entrada||0, b=av.quebra||0, v=av.venda!=null?av.venda:null;
    if(q!=null&&pQ!==null){var vp=(v!=null&&pV!=null)?(v-pV):(v!=null?v:0);tot+=q-(pQ+e-b-vp);ok=true;}
    if(q!=null)pQ=q; if(v!=null)pV=v;
  });
  return ok?tot:null;
}

window.contMasterRender = function() {
  var tbl=document.getElementById('cont-master-table');
  var t10=document.getElementById('cont-master-top10');
  if(!tbl) return;

  var data=window.CONT_DATA||contDataLoad();
  var cfg=window.CONT_CFG||contCfgLoad();
  var arts=(cfg.artigos||[]).filter(function(a){return a.ativo!==false;});
  var lojas=(typeof ADMCFG!=='undefined'&&ADMCFG&&ADMCFG.lojas)||[];

  // Populate artigo filter once
  var asSel=document.getElementById('cont-master-artigo');
  if(asSel&&asSel.options.length<=1) arts.forEach(function(a){var o=document.createElement('option');o.value=a.id;o.textContent=a.nome+(a.sku?' ('+a.sku+')':'');asSel.appendChild(o);});
  var fArt=(asSel&&asSel.value)||'';
  var artsF=fArt?arts.filter(function(a){return a.id===fArt;}):arts;

  // Re-ler dados frescos sempre
  data = window.CONT_DATA || contDataLoad();
  var allDatesInData = Object.keys(data);
  var dates=allDatesInData.filter(_mDateOk).sort();

  if(!artsF.length){
    tbl.innerHTML='<div style="padding:20px;text-align:center;color:var(--t3);font-size:12px">Nenhum artigo configurado para contagem.</div>';
    if(t10)t10.style.display='none'; return;
  }
  if(!dates.length){
    // Mostrar aviso útil com quantos dias têm dados
    var msg = allDatesInData.length>0
      ? 'Sem dados para o período seleccionado. Existem dados em '+allDatesInData.length+' dia(s) — tente seleccionar "Todos" ou outro período.'
      : 'Sem dados de contagem ainda. As lojas ainda não submeteram contagens.';
    tbl.innerHTML='<div style="padding:20px;text-align:center;color:var(--t3);font-size:12px">'+msg+'</div>';
    if(t10)t10.style.display='none'; return;
  }

  var lojaAbs={};
  var thS='padding:7px 8px;font-size:9px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:center;border-left:1px solid var(--bd);white-space:nowrap;background:var(--s2);border-bottom:1px solid var(--bd)';
  var thL='padding:7px 10px;font-size:9px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:left;background:var(--s2);border-bottom:1px solid var(--bd);white-space:nowrap';
  var tbody='';

  dates.forEach(function(d){
    lojas.forEach(function(lj){
      var ld=(data[d]||{})[lj.c]; if(!ld) return;
      var diffs=artsF.map(function(a){return _mCalcDiff(ld,a.id);});
      if(!diffs.some(function(v){return v!==null;})) return;
      var tot=diffs.reduce(function(s,v){return v!=null?s+v:s;},0);
      var abs=diffs.reduce(function(s,v){return v!=null?s+Math.abs(v):s;},0);
      if(!lojaAbs[lj.c])lojaAbs[lj.c]={n:lj.n,c:lj.c,abs:0,tot:0};
      lojaAbs[lj.c].abs+=abs; lojaAbs[lj.c].tot+=tot;
      var p=d.split('-'),dD=p[2]+'/'+p[1]+'/'+p[0];
      var rb=tot<0?'background:#fff5f5':tot>0?'background:#f0f7ff':'';
      tbody+='<tr style="border-bottom:1px solid var(--bd);'+rb+'">'
        +'<td style="padding:6px 10px;font-size:11px;font-weight:500;color:var(--tx);white-space:nowrap">'+dD+'</td>'
        +'<td style="padding:6px 10px;font-size:11px;color:var(--tx);white-space:nowrap"><span style="font-size:10px;color:var(--t3);margin-right:4px">'+lj.c+'</span>'+escHtml(lj.n)+'</td>';
      diffs.forEach(function(diff){
        if(diff===null) tbody+='<td style="padding:6px 8px;text-align:center;font-size:11px;color:var(--t4);border-left:1px solid var(--bd)">—</td>';
        else if(diff===0) tbody+='<td style="padding:6px 8px;text-align:center;font-size:12px;font-weight:700;color:var(--green);border-left:1px solid var(--bd)">0</td>';
        else{var c=diff>0?'var(--blue)':'var(--red)',b2=diff>0?'var(--bbg)':'var(--rbg)';
          tbody+='<td style="padding:4px 8px;text-align:center;border-left:1px solid var(--bd)"><span style="display:inline-block;font-size:11px;font-weight:700;color:'+c+';background:'+b2+';padding:1px 8px;border-radius:4px">'+(diff>0?'+':'')+diff+'</span></td>';}
      });
      var tc=tot===0?'var(--green)':tot>0?'var(--blue)':'var(--red)',tb2=tot===0?'var(--gbg)':tot>0?'var(--bbg)':'var(--rbg)';
      tbody+='<td style="padding:5px 10px;text-align:center;border-left:2px solid var(--bd2)"><span style="display:inline-block;font-size:12px;font-weight:900;color:'+tc+';background:'+tb2+';padding:2px 10px;border-radius:5px">'+(tot>0?'+':'')+tot+'</span></td></tr>';
    });
  });

  tbl.innerHTML = tbody
    ? '<table style="width:100%;border-collapse:collapse;min-width:500px"><thead><tr>'
      +'<th style="'+thL+'">Data</th><th style="'+thL+'">Loja</th>'
      +artsF.map(function(a){return'<th style="'+thS+'">'+escHtml(a.nome.split(' ').slice(0,3).join(' '))+'<div style="font-size:8px;font-weight:400">'+escHtml(a.sku||'')+'</div></th>';}).join('')
      +'<th style="padding:7px 10px;font-size:9px;font-weight:700;color:var(--tx);text-transform:uppercase;text-align:center;border-left:2px solid var(--bd2);background:var(--s3);border-bottom:1px solid var(--bd);white-space:nowrap">Total Δ</th>'
      +'</tr></thead><tbody>'+tbody+'</tbody></table>'
    : '<div style="padding:20px;text-align:center;color:var(--t3);font-size:12px">Sem registos para o período.</div>';

  // TOP 10
  var top=Object.values(lojaAbs).filter(function(l){return l.abs>0;}).sort(function(a,b){return b.abs-a.abs;}).slice(0,10);
  if(top.length&&t10){
    t10.style.display='block';
    t10.innerHTML='<div style="font-size:11px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">🏆 Top 10 — Lojas com mais diferenças</div>'
      +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px 32px">'
      +top.map(function(l,i){
        var pct=Math.round(l.abs/top[0].abs*100);
        var col=l.tot<0?'var(--red)':l.tot>0?'var(--blue)':'var(--green)';
        return'<div style="display:flex;align-items:center;gap:8px;padding:3px 0">'
          +'<div style="font-size:10px;font-weight:700;color:var(--t3);min-width:18px;text-align:right">'+(i+1)+'º</div>'
          +'<div style="font-size:11px;color:var(--tx);min-width:150px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+escHtml(l.c+' '+l.n)+'</div>'
          +'<div style="flex:1;height:8px;background:var(--s3);border-radius:4px;overflow:hidden"><div style="height:100%;width:'+pct+'%;background:'+col+';border-radius:4px"></div></div>'
          +'<div style="font-size:11px;font-weight:700;color:'+col+';min-width:44px;text-align:right">'+(l.tot>0?'+':'')+l.tot+'</div>'
          +'</div>';
      }).join('')+'</div>';
  } else if(t10) t10.style.display='none';
};

window.contMasterExcel = function() {
  var data=window.CONT_DATA||contDataLoad();
  var cfg=window.CONT_CFG||contCfgLoad();
  var arts=(cfg.artigos||[]).filter(function(a){return a.ativo!==false;});
  var lojas=(typeof ADMCFG!=='undefined'&&ADMCFG&&ADMCFG.lojas)||[];
  var fArt=(document.getElementById('cont-master-artigo')||{}).value||'';
  var artsF=fArt?arts.filter(function(a){return a.id===fArt;}):arts;
  var dates=Object.keys(data).filter(_mDateOk).sort();
  var rows=[['Data','Loja','Código'].concat(artsF.map(function(a){return a.nome+(a.sku?' ('+a.sku+')':'');})).concat(['Total Δ'])];
  dates.forEach(function(d){
    lojas.forEach(function(lj){
      var ld=(data[d]||{})[lj.c]; if(!ld) return;
      var diffs=artsF.map(function(a){return _mCalcDiff(ld,a.id);});
      if(!diffs.some(function(v){return v!==null;})) return;
      var tot=diffs.reduce(function(s,v){return v!=null?s+v:s;},0);
      var p=d.split('-');
      rows.push([p[2]+'/'+p[1]+'/'+p[0],lj.n,lj.c].concat(diffs.map(function(v){return v!=null?String(v):''})).concat([String(tot)]));
    });
  });
  var csv=rows.map(function(r){return r.map(function(c){return'"'+String(c).replace(/"/g,'""')+'"';}).join(',');}).join('\n');
  var a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob(['﻿'+csv],{type:'text/csv;charset=utf-8'}));
  a.download='contagens-master-'+_mToday()+'.csv'; a.click();
};
// ══════════════════════════════════════════════════════════════════════════════

var _origSwitchAdmTabCont = window.switchAdmTab;
window.switchAdmTab = function(t) {
  _origSwitchAdmTabCont(t);
  if (t === 'cont') {
    window.CONT_CFG  = contCfgLoad();
    window.CONT_DATA = contDataLoad();
    var _n = new Date();
    var _today = _n.getFullYear()+'-'+String(_n.getMonth()+1).padStart(2,'0')+'-'+String(_n.getDate()).padStart(2,'0');
    setTimeout(function(){
      // Definir datas
      var dadEl = document.getElementById('cont-adm-date');
      if (dadEl && !dadEl.value) dadEl.value = _today;
      var mstEl = document.getElementById('cont-master-date');
      if (mstEl && !mstEl.value) mstEl.value = _today;
      // Popular lojas
      var lojaEl = document.getElementById('cont-adm-loja');
      if (lojaEl && lojaEl.options.length <= 1) {
        var _ljs = (typeof ADMCFG!=='undefined' && ADMCFG && ADMCFG.lojas) ? ADMCFG.lojas : [];
        _ljs.forEach(function(l){ var o=document.createElement('option'); o.value=l.c; o.textContent=l.c+' — '+l.n; lojaEl.appendChild(o); });
      }
      window.CONT_CFG  = contCfgLoad();
      window.CONT_DATA = contDataLoad();
      contAdmRender();
      contAdmDataRender();
      contMasterRender();
    }, 80);
    // Re-renderizar após Firebase (dados podem chegar depois)
    setTimeout(function(){
      window.CONT_DATA = contDataLoad();
      try { contMasterRender(); } catch(e) {}
      try { contAdmDataRender(); } catch(e) {}
    }, 2500);
  }
};

// ── Helpers ───────────────────────────────────────────────────────────────────
function escHtml(s){ if(s==null) return ''; return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function escAttr(s){ if(s==null) return ''; return String(s).replace(/'/g,'&#39;').replace(/"/g,'&quot;'); }

function _contCfgSave(cfg) {
  window.CONT_CFG = cfg;
  try { localStorage.setItem(CONT_CFG_KEY, JSON.stringify(cfg)); } catch(e) {}
  if (window.fbWrite) fbWrite('arreiou_cont_cfg_v1', cfg);
}

function _contAdmMsg(m) {
  var el = document.getElementById('cont-adm-msg');
  if (!el) return;
  el.textContent = m;
  setTimeout(function(){ if(el) el.textContent=''; }, 3500);
}

function _contMsg(m, c){
  var el = document.getElementById('cont-save-msg');
  if (!el) return;
  el.textContent = m;
  el.style.color = c==='green'?'var(--green)':c==='amber'?'var(--amber)':'var(--red)';
}

function _contGetEntry(data, date, loja, turno) {
  try {
    // Tentar com hífens (formato correcto)
    var r = ((data[date]||{})[loja]||{})[turno] || null;
    if (r) return r;
    // Fallback: tentar com underscores (dados antigos do Firebase)
    var altDate = date.replace(/-/g,'_');
    r = ((data[altDate]||{})[loja]||{})[turno] || null;
    if (r) return r;
    // Último recurso: ler directamente do localStorage
    var ls = contDataLoad();
    return ((ls[date]||{})[loja]||{})[turno] || ((ls[altDate]||{})[loja]||{})[turno] || null;
  } catch(e){ return null; }
}


// ══════════════════════════════════════════════════════════════════════════════
// RELATÓRIO DE DIFERENÇAS
// ══════════════════════════════════════════════════════════════════════════════

// Inicializar filtros ao carregar a loja
function _contRelInit() {
  var modeEl = document.getElementById('cont-rel-mode');
  if (modeEl && !modeEl._inited) {
    modeEl._inited = true;
    contRelModeChange();
  } else {
    contRelRender();
  }
}

window.contRelModeChange = function() {
  var mode  = (document.getElementById('cont-rel-mode')||{}).value || 'dia';
  var wrap  = document.getElementById('cont-rel-date-wrap');
  if (!wrap) return;
  var today = _contToday();
  if (mode === 'dia') {
    wrap.innerHTML = '<input type="date" id="cont-rel-date" onchange="contRelRender()" value="'+today+'" style="font-size:11px;padding:5px 8px;border:1px solid var(--bd);border-radius:5px;background:var(--bg);color:var(--tx)">';
  } else if (mode === 'mes') {
    wrap.innerHTML = '<input type="month" id="cont-rel-mes" onchange="contRelRender()" value="'+today.slice(0,7)+'" style="font-size:11px;padding:5px 8px;border:1px solid var(--bd);border-radius:5px;background:var(--bg);color:var(--tx)">';
  } else {
    var yr = today.slice(0,4);
    wrap.innerHTML = '<select id="cont-rel-ano" onchange="contRelRender()" style="font-size:11px;padding:5px 8px;border:1px solid var(--bd);border-radius:5px;background:var(--bg);color:var(--tx)">'
      + [yr, String(parseInt(yr)-1)].map(function(y){ return '<option value="'+y+'"'+(y===yr?' selected':'')+'>'+y+'</option>'; }).join('')
      + '</select>';
  }
  contRelRender();
};

function _contToday() {
  var n = new Date();
  return n.getFullYear()+'-'+String(n.getMonth()+1).padStart(2,'0')+'-'+String(n.getDate()).padStart(2,'0');
}

function _contRelDateFilter(d) {
  var mode = (document.getElementById('cont-rel-mode')||{}).value || 'dia';
  if (mode === 'dia') {
    var v = (document.getElementById('cont-rel-date')||{}).value || '';
    return !v || d === v;
  } else if (mode === 'mes') {
    var v = (document.getElementById('cont-rel-mes')||{}).value || '';
    return !v || d.startsWith(v);
  } else {
    var v = (document.getElementById('cont-rel-ano')||{}).value || '';
    return !v || d.startsWith(v);
  }
}

// Calcular Δ para um artigo num turno
// vndAcum = vendas acumuladas desde manhã neste turno
// prevVndAcum = vendas acumuladas desde manhã no turno anterior
function _calcDiff(prevQtd, qtd, ent, qbr, vndTurno, _unused) {
  // vndTurno = vendas do turno (não acumuladas)
  if (prevQtd === null || qtd === null) return null;
  var esperado = prevQtd + (ent||0) - (qbr||0) - Math.max(0, vndTurno||0);
  return qtd - esperado;
}

window.contRelRender = function() {
  var el   = document.getElementById('cont-rel-body');
  if (!el) return;
  var loja = _contLojaActual || '';
  if (!loja) { el.innerHTML = '<div style="padding:20px;text-align:center;color:var(--t3);font-size:12px">Seleccione uma loja no menu lateral.</div>'; return; }

  var data    = window.CONT_DATA || contDataLoad();
  var cfg     = window.CONT_CFG  || contCfgLoad();
  var artigos = (cfg.artigos || []).filter(function(a){
    if (a.ativo === false) return false;
    if (!a.lojas || !a.lojas.length) return true;
    return a.lojas.indexOf(loja) >= 0;
  });
  if (!artigos.length) { el.innerHTML = '<div style="padding:20px;text-align:center;color:var(--t3);font-size:12px">Nenhum artigo configurado para esta loja.</div>'; return; }

  // Obter datas filtradas com dados para esta loja
  var allDates = Object.keys(data).filter(function(d){
    return _contRelDateFilter(d) && data[d][loja];
  }).sort();

  if (!allDates.length) {
    el.innerHTML = '<div style="padding:20px;text-align:center;color:var(--t3);font-size:12px">Sem registos para o período seleccionado.</div>';
    return;
  }

  // Construir estrutura: para cada artigo × data × turno → calcular Δ
  // Colunas: Artigo | SKU | para cada data: Manhã Δ | Tarde Δ | Noite Δ
  var thStyle = 'padding:7px 8px;font-size:9.5px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:center;border-left:1px solid var(--bd);white-space:nowrap;background:var(--s2);border-bottom:1px solid var(--bd)';
  var thLStyle = 'padding:7px 10px;font-size:9.5px;font-weight:600;color:var(--t3);text-transform:uppercase;text-align:left;background:var(--s2);border-bottom:1px solid var(--bd);white-space:nowrap';

  // Header: data columns
  var dateHeaders = allDates.map(function(d){
    var parts = d.split('-');
    var display = parts[2]+'/'+parts[1];
    return '<th colspan="3" style="'+thStyle+';background:var(--s2);border-left:2px solid var(--bd2)">'+display+'</th>';
  }).join('');

  var turnoHeaders = allDates.map(function(){
    return ['☀️','🌙','Σ'].map(function(t,ti){
      var s = ti===2 ? thStyle+';color:var(--tx);font-weight:700' : thStyle;
      return '<th style="'+s+'">'+t+'</th>';
    }).join('');
  }).join('') + '<th style="'+thStyle+';background:var(--asoft);color:var(--accent);font-weight:700;white-space:nowrap;border-left:2px solid var(--bd2)">Total</th>';

  var rows = artigos.map(function(a){
    var cells = '';
    var hasDiff = false;
    var grandTotal = 0;
    var grandHasData = false;

    allDates.forEach(function(d){
      var lojaData = (data[d]||{})[loja] || {};
      var prevQtd = null;
      var prevVndAcum = 0;
      var dateTurnoDeltas = [];

      TURNOS.forEach(function(t, ti){
        var entry = lojaData[t.id] || {};
        var av    = entry[a.id];
        var qtd = (av&&typeof av==='object') ? av.qtd     : null;
        var ent = (av&&typeof av==='object') ? (av.entrada||0) : 0;
        var qbr = (av&&typeof av==='object') ? (av.quebra||0)  : 0;
        var vndAcum = (av&&typeof av==='object') ? (av.venda||0) : 0;
        if (ti === 0) {
          if (qtd !== null) prevQtd = qtd;
          prevVndAcum = vndAcum;
          return;
        }

        var diff = (prevQtd !== null && qtd !== null)
          ? _calcDiff(prevQtd, qtd, ent, qbr, vndAcum, prevVndAcum)
          : null;

        dateTurnoDeltas.push({diff: diff, av: av});

        var bdrL = ti === 1 ? 'border-left:2px solid var(--bd2)' : 'border-left:1px solid var(--bd)';
        if (diff !== null) {
          hasDiff = true;
          var col = diff === 0 ? 'var(--green)' : diff > 0 ? 'var(--blue)' : 'var(--red)';
          var bg  = diff === 0 ? '' : diff > 0 ? 'background:var(--bbg)' : 'background:var(--rbg)';
          var sign = diff > 0 ? '+' : '';
          cells += '<td style="padding:5px 8px;text-align:center;font-size:12px;font-weight:700;color:'+col+';'+bg+';'+bdrL+'">'+sign+diff+'</td>';
        } else {
          cells += '<td style="padding:5px 8px;text-align:center;font-size:11px;color:var(--t4);'+bdrL+'">'+(av!=null?'✓':'—')+'</td>';
        }

        if (qtd !== null) prevQtd = qtd;
        if (av != null) prevVndAcum = vndAcum;
      });

      // Σ column for this date
      var dateSum = dateTurnoDeltas.reduce(function(s,x){ return s + (x.diff!=null?x.diff:0); }, 0);
      var dateSumHasData = dateTurnoDeltas.some(function(x){ return x.diff!=null; });
      if (dateSumHasData) {
        grandTotal += dateSum;
        grandHasData = true;
        var sc = dateSum === 0 ? 'var(--green)' : dateSum > 0 ? 'var(--blue)' : 'var(--red)';
        var sb = dateSum === 0 ? '' : dateSum > 0 ? 'background:var(--bbg)' : 'background:var(--rbg)';
        cells += '<td style="padding:5px 8px;text-align:center;font-size:12px;font-weight:700;color:'+sc+';'+sb+';border-left:1px solid var(--bd)">'+(dateSum>0?'+':'')+dateSum+'</td>';
      } else {
        cells += '<td style="padding:5px 8px;text-align:center;font-size:11px;color:var(--t4);border-left:1px solid var(--bd)">—</td>';
      }
    });

    // Grand total column
    if (grandHasData) {
      var gc = grandTotal === 0 ? 'var(--green)' : grandTotal > 0 ? 'var(--blue)' : 'var(--red)';
      var gb = grandTotal === 0 ? 'background:var(--asoft)' : grandTotal > 0 ? 'background:var(--bbg)' : 'background:var(--rbg)';
      cells += '<td style="padding:5px 10px;text-align:center;font-size:13px;font-weight:700;color:'+gc+';'+gb+';border-left:2px solid var(--bd2)">'+(grandTotal>0?'+':'')+grandTotal+'</td>';
    } else {
      cells += '<td style="padding:5px 10px;text-align:center;font-size:11px;color:var(--t4);background:var(--asoft);border-left:2px solid var(--bd2)">—</td>';
    }

    return { hasDiff: hasDiff, nome: a.nome, sku: a.sku||'', cells: cells };
  });

  var tableRows = rows.map(function(r){
    return '<tr style="border-bottom:1px solid var(--bd)">'
      + '<td style="padding:6px 10px;font-size:11.5px;font-weight:500;color:var(--tx);white-space:nowrap;max-width:180px;overflow:hidden;text-overflow:ellipsis">'+escHtml(r.nome)+'</td>'
      + '<td style="padding:6px 8px;font-size:10px;color:var(--t3);white-space:nowrap">'+escHtml(r.sku)+'</td>'
      + r.cells
      + '</tr>';
  }).join('');

  el.innerHTML = '<div style="overflow-x:auto;border:1px solid var(--bd);border-radius:10px;overflow:hidden" id="cont-rel-table-wrap">'
    + '<table id="cont-rel-table" style="width:100%;border-collapse:collapse;min-width:400px">'
    + '<thead>'
    + '<tr style="background:var(--s2)">'
    + '<th style="'+thLStyle+'">Artigo</th>'
    + '<th style="'+thLStyle+'">SKU</th>'
    + dateHeaders
    + '<th style="'+thStyle+';background:var(--asoft);color:var(--accent);font-weight:700;border-left:2px solid var(--bd2)">Total</th>'
    + '</tr>'
    + '<tr style="background:var(--s2)">'
    + '<th style="'+thLStyle+'"></th>'
    + '<th style="'+thLStyle+'"></th>'
    + turnoHeaders
    + '</tr>'
    + '</thead><tbody>'+tableRows+'</tbody></table></div>'
    + '<div style="margin-top:8px;font-size:10px;color:var(--t3);display:flex;gap:12px;flex-wrap:wrap">'
    + '<span><b style="color:var(--red)">−</b> stock inferior ao esperado</span>'
    + '<span><b style="color:var(--blue)">+</b> stock superior ao esperado</span>'
    + '<span><b style="color:var(--green)">0</b> sem diferença</span>'
    + '<span style="color:var(--t4)">✓ contagem feita sem referência anterior · — sem contagem</span>'
    + '</div>';
};

// ── Exportar Excel ────────────────────────────────────────────────────────────
window.contRelExcel = function() {
  var loja = _contLojaActual || '';
  var data    = window.CONT_DATA || contDataLoad();
  var cfg     = window.CONT_CFG  || contCfgLoad();
  var artigos = (cfg.artigos || []).filter(function(a){
    if (a.ativo === false) return false;
    if (!a.lojas || !a.lojas.length) return true;
    return a.lojas.indexOf(loja) >= 0;
  });

  var allDates = Object.keys(data).filter(function(d){
    return _contRelDateFilter(d) && data[d][loja];
  }).sort();

  if (!allDates.length || !artigos.length) { alert('Sem dados para exportar.'); return; }

  var lojaInfo = (typeof ADMCFG !== 'undefined' && ADMCFG && ADMCFG.lojas || []).find(function(l){ return l.c===loja; });
  var lojaNome = lojaInfo ? lojaInfo.n : loja;

  // Build CSV content
  var turnoNames = ['Tarde','Noite']; // Manhã é referência, sem Δ
  var header1 = ['Artigo','SKU'];
  var header2 = ['',''];
  allDates.forEach(function(d){
    var parts = d.split('-');
    var disp = parts[2]+'/'+parts[1]+'/'+parts[0];
    turnoNames.forEach(function(t){ header1.push(disp); header2.push(t+' Δ'); });
  });

  var csvRows = [header1, header2];
  artigos.forEach(function(a){
    var row = [a.nome, a.sku||''];
    allDates.forEach(function(d){
      var lojaData = (data[d]||{})[loja] || {};
      var prevQtd = null;
      var prevVndAcum = 0;
      TURNOS.forEach(function(t, ti){
        var entry = lojaData[t.id] || {};
        var av    = entry[a.id];
        var qtd = (av&&typeof av==='object') ? av.qtd     : null;
        var ent = (av&&typeof av==='object') ? (av.entrada||0) : 0;
        var qbr = (av&&typeof av==='object') ? (av.quebra||0)  : 0;
        var vndAcum = (av&&typeof av==='object') ? (av.venda||0) : 0;
        if (ti === 0) { if (qtd !== null) prevQtd = qtd; prevVndAcum = vndAcum; return; }
        var diff = (prevQtd !== null && qtd !== null) ? _calcDiff(prevQtd, qtd, ent, qbr, vndAcum, prevVndAcum) : null;
        row.push(diff !== null ? (diff > 0 ? '+'+diff : String(diff)) : (av != null ? '✓' : ''));
        if (qtd !== null) prevQtd = qtd;
        if (av != null) prevVndAcum = vndAcum;
      });
    });
    csvRows.push(row);
  });

  var csv = csvRows.map(function(r){ return r.map(function(c){ return '"'+String(c).replace(/"/g,'""')+'"'; }).join(','); }).join('\n');
  var blob = new Blob(['\uFEFF'+csv], {type:'text/csv;charset=utf-8'});
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href = url;
  a.download = 'contagens-diferencas-'+loja+'-'+_contToday()+'.csv';
  a.click();
  URL.revokeObjectURL(url);
};

// ── Chamar _contRelInit quando loja é carregada ───────────────────────────────

// Mobile nav
window.addEventListener('load', function(){
  var mn = document.getElementById('mobile-nav');
  if (!mn || document.getElementById('mnb-contagens')) return;
  var btn = document.createElement('div');
  btn.className = 'mnb'; btn.id = 'mnb-contagens';
  btn.innerHTML = '<svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg><span>Contagens</span>';
  btn.onclick = function(){ try{ switchViewProtected('contagens'); }catch(e){ switchView('contagens'); } };
  mn.appendChild(btn);
});

})();
// ══════════════════════════════════════════════════════════════════════════════
// FIM CONTAGENS DIÁRIAS
// ══════════════════════════════════════════════════════════════════════════════
