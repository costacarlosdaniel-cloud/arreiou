
/* PATCH DCG — Ranking/Tendência/Mapa de Calor robustos
   Corrige o caso em que a Vista Diária tem dados, mas as análises históricas ficam vazias
   por dependerem apenas de ADMCFG.lojas ou por não reconstruírem artigos a partir das contagens. */
(function(){
  function _dcgSafeEsc(v){ try { return escHtml(String(v==null?'':v)); } catch(e){ return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); } }
  function _dcgData(){ return window.CONT_DATA || (typeof contDataLoad==='function' ? contDataLoad() : {}) || {}; }
  function _dcgCfgArts(){
    var cfg = window.CONT_CFG || (typeof contCfgLoad==='function' ? contCfgLoad() : {}) || {};
    return (cfg.artigos || []).filter(function(a){ return a && a.ativo !== false; });
  }
  function _dcgTurnosSafe(){
    try { if (window.TURNOS && window.TURNOS.length) return window.TURNOS; } catch(e){}
    try { if (typeof TURNOS !== 'undefined' && TURNOS && TURNOS.length) return TURNOS; } catch(e){}
    return [{id:'manha',label:'Manhã'},{id:'tarde',label:'Tarde'},{id:'noite',label:'Noite'}];
  }
  function _dcgMetaKey(k){ return k==='__nota__'||k==='__ts__'||k==='__ts_edit__'||k==='ts'||k==='nota'; }
  function _dcgHasQtd(av){ return av && typeof av==='object' && av.qtd != null && av.qtd !== ''; }
  function _dcgGetDates(){
    var days = window._dcgPeriodDays || 7;
    var arr = [];
    for (var i=days-1;i>=0;i--) arr.push(typeof isoToday==='function' ? isoToday(-i) : new Date(Date.now()-i*86400000).toISOString().slice(0,10));
    return arr;
  }
  window._dcgDates = function(days){
    var old = window._dcgPeriodDays;
    if (days) window._dcgPeriodDays = days;
    var out = _dcgGetDates();
    if (days) window._dcgPeriodDays = old;
    return out;
  };
  window._dcgGetLojas = function(){
    var data = _dcgData();
    var datas = _dcgGetDates();
    var map = {};
    try { ((window.ADMCFG && window.ADMCFG.lojas) || []).forEach(function(l){ if(l && l.c) map[l.c] = {c:l.c,n:l.n||l.c,s:l.s||''}; }); } catch(e){}
    datas.forEach(function(d){
      var day = data[d] || {};
      Object.keys(day).forEach(function(c){
        if (!map[c]) map[c] = {c:c,n:(typeof _dcgNomeLoja==='function'?_dcgNomeLoja(c):c),s:''};
      });
    });
    // Fallback: se não houver dados nos últimos N dias, devolve ADMCFG; senão devolve as lojas com dados.
    return Object.keys(map).sort().map(function(c){ return map[c]; });
  };
  function _dcgArtigosFor(datas, lojas){
    var cfgArts = _dcgCfgArts();
    var byId = {};
    cfgArts.forEach(function(a){ if(a && a.id) byId[a.id] = Object.assign({}, a); });
    var data = _dcgData();
    var lojaSet = {};
    (lojas||[]).forEach(function(l){ lojaSet[l.c||l] = true; });
    datas.forEach(function(d){
      var day = data[d] || {};
      Object.keys(day).forEach(function(c){
        if (lojas && lojas.length && !lojaSet[c]) return;
        var ld = day[c] || {};
        Object.keys(ld).forEach(function(t){
          var entry = ld[t] || {};
          Object.keys(entry).forEach(function(id){
            if (_dcgMetaKey(id)) return;
            if (!byId[id]) byId[id] = {id:id,nome:id,sku:''};
          });
        });
      });
    });
    return Object.keys(byId).map(function(id){ return byId[id]; });
  }
  window._dcgGetArtigos = function(){ return _dcgArtigosFor(_dcgGetDates(), null); };
  window._dcgFillArtSelect = function(id){
    var sel=document.getElementById(id); if(!sel) return;
    var cur=sel.value || '';
    sel.innerHTML='<option value="">Todos</option>';
    _dcgGetArtigos().sort(function(a,b){ return String(a.nome||a.id).localeCompare(String(b.nome||b.id)); }).forEach(function(a){
      var o=document.createElement('option'); o.value=a.id; o.textContent=a.nome||a.id; sel.appendChild(o);
    });
    if(cur && Array.prototype.some.call(sel.options,function(o){return o.value===cur;})) sel.value=cur;
  };
  window._dcgFillLojaSelect = function(id){
    var sel=document.getElementById(id); if(!sel) return;
    var cur=sel.value || '';
    sel.innerHTML='<option value="">Todas</option>';
    _dcgGetLojas().forEach(function(l){ var o=document.createElement('option'); o.value=l.c; o.textContent=(l.c+' · '+(l.n||l.c)); sel.appendChild(o); });
    if(cur && Array.prototype.some.call(sel.options,function(o){return o.value===cur;})) sel.value=cur;
  };
  window.computeLojaData = function(lojaCode,datas,contData,artigos,turnos){
    contData = contData || _dcgData();
    turnos = turnos || _dcgTurnosSafe();
    artigos = artigos && artigos.length ? artigos : _dcgArtigosFor(datas, [{c:lojaCode}]);
    var res = {};
    artigos.forEach(function(a){ if(a && a.id) res[a.id]={nome:a.nome||a.id,sku:a.sku||'',diffs:[],sumNeg:0,sumPos:0,count:0}; });
    datas.forEach(function(date){
      var dayData = (contData[date] && contData[date][lojaCode]) || {};
      var prevQtd = {}, prevVenda = {};
      artigos.forEach(function(a){ prevQtd[a.id]=null; prevVenda[a.id]=0; });
      turnos.forEach(function(t,ti){
        var entry = dayData[t.id] || {};
        artigos.forEach(function(a){
          if(!a || !a.id || !res[a.id]) return;
          var av = entry[a.id];
          var qtd = _dcgHasQtd(av) ? Number(av.qtd) : null;
          var ent = av && typeof av==='object' ? Number(av.entrada||0) : 0;
          var qbr = av && typeof av==='object' ? Number(av.quebra||0) : 0;
          var vendaAcum = av && typeof av==='object' ? Number(av.venda||0) : 0;
          if (ti===0) { if(qtd!==null) prevQtd[a.id]=qtd; prevVenda[a.id]=vendaAcum; return; }
          if (qtd!==null && prevQtd[a.id]!==null) {
            var vendaTurno = Math.max(0, vendaAcum - (prevVenda[a.id]||0));
            var esperado = prevQtd[a.id] + ent - qbr - vendaTurno;
            var delta = qtd - esperado;
            if (Math.abs(delta) > 0.0001) {
              delta = Math.round(delta*100)/100;
              res[a.id].diffs.push({date:date,turno:t.id,delta:delta});
              res[a.id].count++;
              if(delta<0) res[a.id].sumNeg += delta; else res[a.id].sumPos += delta;
            }
          }
          if(qtd!==null) prevQtd[a.id]=qtd;
          if(av!=null) prevVenda[a.id]=vendaAcum;
        });
      });
    });
    return res;
  };
  function _dcgNoDataMsg(body, msg){
    var data=_dcgData();
    var available=Object.keys(data).sort().reverse().slice(0,7);
    body.innerHTML='<div style="padding:32px;text-align:center;color:var(--t3);font-size:12px">'+msg+(available.length?'<div style="margin-top:8px;font-size:11px">Datas com contagens: '+available.join(', ')+'</div>':'')+'</div>';
  }
  window.dcgRankingRender = function(){
    var body=document.getElementById('dcg-ranking-body'); if(!body) return;
    var datas=_dcgGetDates(), contData=_dcgData(), lojas=_dcgGetLojas();
    var artFil=(document.getElementById('dcg-rank-art')||{}).value||'';
    var artigos=_dcgArtigosFor(datas, lojas); if(artFil) artigos=artigos.filter(function(a){return a.id===artFil;});
    var rows=lojas.map(function(l){
      var res=computeLojaData(l.c,datas,contData,artigos,_dcgTurnosSafe());
      var sumNeg=0,sumPos=0,nDiff=0;
      Object.keys(res).forEach(function(k){ sumNeg+=res[k].sumNeg; sumPos+=res[k].sumPos; nDiff+=res[k].count; });
      return {c:l.c,n:l.n||l.c,sumNeg:sumNeg,sumPos:sumPos,nDiff:nDiff};
    }).filter(function(r){return r.nDiff>0;}).sort(function(a,b){return a.sumNeg-b.sumNeg || b.nDiff-a.nDiff;});
    if(!rows.length) return _dcgNoDataMsg(body,'Sem diferenças nos últimos '+(window._dcgPeriodDays||7)+' dias.');
    var maxNeg=Math.max(1,Math.max.apply(null,rows.map(function(r){return Math.abs(r.sumNeg);}))), tdH='padding:9px 12px;font-size:11px;font-weight:800;color:var(--t3);text-transform:uppercase;background:var(--s2);border-bottom:1px solid var(--bd);text-align:', td='padding:9px 12px;font-size:13px;border-bottom:1px solid var(--bd);';
    var html='<div style="overflow-x:auto;border:1px solid var(--bd);border-radius:10px"><table style="width:100%;border-collapse:collapse"><thead><tr><th style="'+tdH+'left">Loja</th><th style="'+tdH+'center">Δ Negativo</th><th style="'+tdH+'center">Barra</th><th style="'+tdH+'center">Δ Positivo</th><th style="'+tdH+'center">Nº Difs</th></tr></thead><tbody>';
    rows.forEach(function(r,i){ var negPct=Math.round(Math.abs(r.sumNeg)/maxNeg*100); html+='<tr style="background:'+(i%2?'var(--s2)':'var(--bg)')+'"><td style="'+td+'font-weight:600"><span style="font-family:monospace;font-size:11px;color:var(--t3)">'+_dcgSafeEsc(r.c)+'</span> '+_dcgSafeEsc(r.n)+'</td><td style="'+td+'text-align:center;color:var(--red);font-weight:800">'+Math.round(r.sumNeg)+'</td><td style="'+td+'text-align:center;min-width:160px"><div style="width:'+negPct+'%;min-width:3px;height:12px;background:var(--red);border-radius:3px"></div></td><td style="'+td+'text-align:center;color:var(--blue);font-weight:700">'+(r.sumPos>0?'+'+Math.round(r.sumPos):'—')+'</td><td style="'+td+'text-align:center;color:var(--t2);font-weight:700">'+r.nDiff+'</td></tr>'; });
    body.innerHTML=html+'</tbody></table></div>';
  };
  window.dcgTendenciaRender = function(){
    var body=document.getElementById('dcg-tendencia-body'); if(!body) return;
    var datas=_dcgGetDates(), contData=_dcgData(), lojas=_dcgGetLojas();
    var lojaFil=(document.getElementById('dcg-tend-loja')||{}).value||''; if(lojaFil) lojas=lojas.filter(function(l){return l.c===lojaFil;});
    var artFil=(document.getElementById('dcg-tend-art')||{}).value||''; var artigos=_dcgArtigosFor(datas, lojas); if(artFil) artigos=artigos.filter(function(a){return a.id===artFil;});
    var byDate={}; datas.forEach(function(d){byDate[d]={neg:0,pos:0,n:0};});
    lojas.forEach(function(l){ var res=computeLojaData(l.c,datas,contData,artigos,_dcgTurnosSafe()); Object.keys(res).forEach(function(k){res[k].diffs.forEach(function(df){ if(!byDate[df.date])return; if(df.delta<0)byDate[df.date].neg+=df.delta; else byDate[df.date].pos+=df.delta; byDate[df.date].n++; });}); });
    var any=datas.some(function(d){return byDate[d].n>0;}); if(!any) return _dcgNoDataMsg(body,'Sem dados de tendência para os últimos '+(window._dcgPeriodDays||7)+' dias.');
    var maxAbs=Math.max(1,Math.max.apply(null,datas.map(function(d){return Math.max(Math.abs(byDate[d].neg),byDate[d].pos);}))); var h=170, barW=Math.max(12,Math.min(38,Math.floor(700/datas.length)-4)), totalW=datas.length*(barW+8)+70;
    var bars=datas.map(function(d,i){ var x=55+i*(barW+8), neg=byDate[d].neg, pos=byDate[d].pos, hNeg=Math.round(Math.abs(neg)/maxAbs*h*.85), hPos=Math.round(pos/maxAbs*h*.85); return (hNeg?'<rect x="'+x+'" y="'+(h-hNeg)+'" width="'+barW+'" height="'+hNeg+'" fill="var(--red)" opacity=".85" rx="3"/>':'')+(hPos?'<rect x="'+x+'" y="'+(h-hNeg-hPos)+'" width="'+barW+'" height="'+hPos+'" fill="var(--blue)" opacity=".75" rx="3"/>':'')+'<text x="'+(x+barW/2)+'" y="'+(h+18)+'" text-anchor="middle" font-size="10" fill="var(--t3)">'+d.slice(5)+'</text>'+(neg?'<text x="'+(x+barW/2)+'" y="'+(h-hNeg-5)+'" text-anchor="middle" font-size="10" fill="var(--red)">'+Math.round(neg)+'</text>':''); }).join('');
    var totNeg=datas.reduce(function(s,d){return s+byDate[d].neg;},0), totPos=datas.reduce(function(s,d){return s+byDate[d].pos;},0);
    body.innerHTML='<div style="display:flex;gap:14px;margin-bottom:14px;flex-wrap:wrap"><div style="background:var(--rbg);border:1px solid var(--red);border-radius:8px;padding:10px 18px;text-align:center"><div style="font-size:22px;font-weight:800;color:var(--red)">'+Math.round(totNeg)+'</div><div style="font-size:11px;color:var(--t3);font-weight:700">Δ Total Negativo</div></div><div style="background:var(--bbg);border:1px solid var(--blue);border-radius:8px;padding:10px 18px;text-align:center"><div style="font-size:22px;font-weight:800;color:var(--blue)">+'+Math.round(totPos)+'</div><div style="font-size:11px;color:var(--t3);font-weight:700">Δ Total Positivo</div></div></div><div style="overflow-x:auto"><svg viewBox="0 0 '+totalW+' '+(h+34)+'" style="width:100%;max-width:'+totalW+'px;overflow:visible"><line x1="55" y1="0" x2="55" y2="'+h+'" stroke="var(--bd)"/><line x1="55" y1="'+h+'" x2="'+totalW+'" y2="'+h+'" stroke="var(--bd)"/>'+bars+'</svg></div>';
  };
  window.dcgCalorRender = window.dcgCaiorRender = function(){
    var body=document.getElementById('dcg-calor-body'); if(!body) return;
    var datas=_dcgGetDates(), contData=_dcgData(), lojas=_dcgGetLojas(), artigos=_dcgArtigosFor(datas, lojas), WD=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
    var heat={}; lojas.forEach(function(l){heat[l.c]=[0,1,2,3,4,5,6].map(function(){return {neg:0,count:0};});});
    lojas.forEach(function(l){ var res=computeLojaData(l.c,datas,contData,artigos,_dcgTurnosSafe()); Object.keys(res).forEach(function(k){res[k].diffs.forEach(function(df){ if(df.delta>=0)return; var dow=new Date(df.date+'T12:00:00').getDay(); heat[l.c][dow].neg+=df.delta; heat[l.c][dow].count++; });}); });
    var lojasComDados=lojas.filter(function(l){return heat[l.c] && heat[l.c].some(function(x){return x.count>0;});}); if(!lojasComDados.length) return _dcgNoDataMsg(body,'Sem dados para os últimos '+(window._dcgPeriodDays||7)+' dias.');
    var maxNeg=1; lojasComDados.forEach(function(l){heat[l.c].forEach(function(x){maxNeg=Math.max(maxNeg,Math.abs(x.neg));});});
    var tdH='padding:8px 12px;font-size:11px;font-weight:800;color:var(--t3);text-transform:uppercase;background:var(--s2);border-bottom:1px solid var(--bd);text-align:center;white-space:nowrap', tdC='padding:8px 10px;text-align:center;font-size:12px;border-bottom:1px solid var(--bd);border-right:1px solid var(--bd);font-weight:700';
    lojasComDados.sort(function(a,b){return heat[a.c].reduce(function(s,x){return s+x.neg;},0)-heat[b.c].reduce(function(s,x){return s+x.neg;},0);});
    var html='<div style="overflow-x:auto;border:1px solid var(--bd);border-radius:10px"><table style="width:100%;border-collapse:collapse"><thead><tr><th style="'+tdH+';text-align:left">Loja</th>'+WD.map(function(w){return '<th style="'+tdH+'">'+w+'</th>';}).join('')+'<th style="'+tdH+'">Total</th></tr></thead><tbody>';
    lojasComDados.forEach(function(l,i){ var total=heat[l.c].reduce(function(s,x){return s+x.neg;},0); html+='<tr style="background:'+(i%2?'var(--s2)':'var(--bg)')+'"><td style="padding:8px 12px;font-size:13px;border-bottom:1px solid var(--bd);font-weight:600;white-space:nowrap"><span style="font-family:monospace;font-size:11px;color:var(--t3)">'+_dcgSafeEsc(l.c)+'</span> '+_dcgSafeEsc(l.n||l.c)+'</td>'; heat[l.c].forEach(function(x){ var pct=x.neg<0?Math.min(1,Math.abs(x.neg)/maxNeg):0, alpha=(0.08+pct*.55).toFixed(2), bg=pct?'rgba(217,48,37,'+alpha+')':'transparent', col=pct>.55?'#fff':'var(--tx)'; html+='<td style="'+tdC+'background:'+bg+';color:'+col+'">'+(x.neg<0?Math.round(x.neg):'—')+'</td>'; }); html+='<td style="'+tdC+'color:var(--red);font-weight:800">'+(total<0?Math.round(total):'—')+'</td></tr>'; });
    body.innerHTML=html+'</tbody></table></div>';
  };
  var _oldDcgSwitch = window.dcgSwitch;
  window.dcgSwitch = function(tab){
    ['dia','ranking','tendencia','calor'].forEach(function(t){ var pane=document.getElementById('dcg-'+t), btn=document.getElementById('dcg-tab-'+t); if(pane)pane.style.display=t===tab?'':'none'; if(btn){btn.style.borderBottomColor=t===tab?'var(--accent)':'transparent'; btn.style.color=t===tab?'var(--accent)':'var(--t2)';} });
    if(tab==='dia' && typeof dcgDiaRender==='function') dcgDiaRender();
    if(tab==='ranking'){ _dcgFillArtSelect('dcg-rank-art'); dcgRankingRender(); }
    if(tab==='tendencia'){ _dcgFillArtSelect('dcg-tend-art'); _dcgFillLojaSelect('dcg-tend-loja'); dcgTendenciaRender(); }
    if(tab==='calor') dcgCalorRender();
  };
  var _oldDcgPeriod = window.dcgPeriod;
  window.dcgPeriod = function(days){
    window._dcgPeriodDays = days;
    try { ['p','tp','cp'].forEach(function(p){ if(typeof _dcgHlBtn==='function') _dcgHlBtn('dcg-'+p, days); }); } catch(e){}
    if((document.getElementById('dcg-ranking')||{}).style.display!=='none') dcgRankingRender();
    if((document.getElementById('dcg-tendencia')||{}).style.display!=='none') dcgTendenciaRender();
    if((document.getElementById('dcg-calor')||{}).style.display!=='none') dcgCalorRender();
  };
})();
