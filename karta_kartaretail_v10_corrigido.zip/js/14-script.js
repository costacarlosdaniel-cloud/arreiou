
// ══════════════════════════════════════════════════════════════════════════════
// MÓDULO: INVENTÁRIOS (Administração)
// ══════════════════════════════════════════════════════════════════════════════
(function(){

var _invData = [];      // dados brutos do sheet
var _invLoaded = false;
var _invLoading = false;
var _invSort = { col: 'vt', dir: 1 }; // 1=asc, -1=desc (default: pior primeiro = mais negativo)
var _invEvoChart = null;

// ── Carregar dados do Google Sheet ────────────────────────────────────────────
window.invAdmLoad = async function() {
  // Reset stuck state — nunca bloquear mais de 30s
  if (_invLoading && window._invLoadStart && (Date.now() - window._invLoadStart) < 30000) return;
  _invLoading = true;
  window._invLoadStart = Date.now();
  _invLoaded = false;
  var st = document.getElementById('inv-adm-status');
  var btn = document.getElementById('inv-sync-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ A carregar…'; }
  if (st) st.textContent = '⏳ A ligar ao Google Sheet…';

  // GID=1127908719 confirmado no URL (tab INVENTRIOLOJASARREIOU 1)
  var _ts = Date.now();
  var _invUrls = [
    { url: 'https://docs.google.com/spreadsheets/d/' + GS_ID + '/gviz/tq?tqx=out:csv&gid=1127908719&t=' + _ts, label: 'gviz/gid' },
    { url: 'https://docs.google.com/spreadsheets/d/' + GS_ID + '/export?format=csv&gid=1127908719&t=' + _ts, label: 'export/gid' },
    { url: 'https://docs.google.com/spreadsheets/d/' + GS_ID + '/gviz/tq?tqx=out:csv&sheet=' + encodeURIComponent('INVENTRIOLOJASARREIOU 1') + '&t=' + _ts, label: 'gviz/nome' }
  ];
  var text = null;
  var _usedSheet = '';
  try {
    if (st) st.textContent = '⏳ A carregar inventários…';
    for (var _ui = 0; _ui < _invUrls.length; _ui++) {
      var _entry = _invUrls[_ui];
      if (st) st.textContent = '⏳ A tentar ' + _entry.label + '…';
      try {
        var resp = await fetch(_entry.url);
        window._KARTA_DEBUG&&console.log('[invAdm]', _entry.label, '→ HTTP', resp.status, resp.redirected ? '(redirect)' : '');
        if (!resp.ok) continue;
        var _txt = await resp.text();
        window._KARTA_DEBUG&&console.log('[invAdm]', _entry.label, '→', _txt.length, 'bytes, início:', JSON.stringify(_txt.substring(0,150)));
        // Válido se começa com aspas ou letra (CSV) e não com < (HTML de login/erro)
        // Válido se CSV e contém colunas esperadas de inventário
        var _isCSV = _txt.length > 100 && !_txt.startsWith('<') && !_txt.startsWith('google.visualization') && !_txt.startsWith('<!');
        var _hasInvCols = _txt.includes('dim_Historico') || _txt.includes('v_Conhecida') || _txt.includes('IdCentro');
        var _isHeadcount = _txt.includes('File HC') || _txt.includes('Nº pessoal') || _txt.includes('HeadCount');
        if (_isCSV && _hasInvCols && !_isHeadcount) {
          text = _txt; _usedSheet = _entry.label; break;
        } else {
          window._KARTA_DEBUG&&console.warn('[invAdm]', _entry.label, '— isCSV:', _isCSV, 'hasInvCols:', _hasInvCols, 'isHeadcount:', _isHeadcount, 'início:', JSON.stringify(_txt.substring(0,80)));
          if (st) st.textContent = '⏳ ' + _entry.label + ' sem dados válidos, a tentar alternativa…';
        }
      } catch(fe) { window._KARTA_DEBUG&&console.warn('[invAdm] fetch error', _entry.label, fe.message); }
    }
    if (!text) {
      if (st) st.innerHTML = '❌ Sem acesso ao Google Sheet.<br><small>O ficheiro precisa de estar partilhado publicamente (ou publicado na web).<br>GID usado: 250890808</small>';
      _invLoading = false; return;
    }
    var rows = Papa ? Papa.parse(text, {skipEmptyLines:true}).data : csvParse(text);

    if (!rows.length) throw new Error('Sem dados — sheet encontrada mas CSV vazio');
    
    var hdr = rows[0].map(function(h){ return String(h).trim(); });
    function col(name) {
      var i = hdr.indexOf(name);
      return i >= 0 ? i : -1;
    }

    // Colunas confirmadas pela imagem do Google Sheet (INVENTRIOLOJASARREIOU 1):
    // A=dim_Historico[IdCentro], B=dim_Historico[Data], C=dCentros[Nome Centro],
    // D=dim_Historico[SalesManager], E=[v_Conhecida], F=[v_Desconhecida]
    var iCentro = col('dim_Historico[IdCentro]');
    var iData   = col('dim_Historico[Data]');
    var iLoja   = col('dCentros[Nome Centro]');
    var iSM     = col('dim_Historico[SalesManager]');
    var iVC     = col('[v_Conhecida]');
    var iVD     = col('[v_Desconhecida]');

    window._KARTA_DEBUG&&console.log('[invAdm] Headers reais:', hdr);
    window._KARTA_DEBUG&&console.log('[invAdm] Índices — centro:', iCentro, 'data:', iData, 'loja:', iLoja, 'sm:', iSM, 'vc:', iVC, 'vd:', iVD);

    // Fallback por keyword se alguma coluna não for encontrada exactamente
    if (iCentro < 0) iCentro = hdr.findIndex(function(h){ return h.toLowerCase().includes('idcentro'); });
    if (iLoja   < 0) iLoja   = hdr.findIndex(function(h){ return h.toLowerCase().includes('nome') && h.toLowerCase().includes('centro'); });
    if (iSM     < 0) iSM     = hdr.findIndex(function(h){ return h.toLowerCase().includes('salesmanager'); });
    if (iSM     < 0) iSM     = hdr.findIndex(function(h){ return h.toLowerCase().includes('sales') && h.toLowerCase().includes('manager'); });
    if (iSM     < 0) iSM     = hdr.findIndex(function(h){ return h.toLowerCase().includes('gv'); });
    if (iVC     < 0) iVC     = hdr.findIndex(function(h){ return h.toLowerCase().includes('conhecida') && !h.toLowerCase().includes('des'); });
    if (iVD     < 0) iVD     = hdr.findIndex(function(h){ return h.toLowerCase().includes('desconhecida'); });
    if (iData   < 0) iData   = hdr.findIndex(function(h){ return h.toLowerCase().includes('data'); });
    // Diagnóstico completo — mostra sheet, nº linhas, headers reais, e primeira linha de dados
    window._KARTA_DEBUG&&console.log('[invAdm] Sheet usada:', _usedSheet);
    window._KARTA_DEBUG&&console.log('[invAdm] Total linhas (incl header):', rows.length);
    window._KARTA_DEBUG&&console.log('[invAdm] Headers:', hdr);
    if (rows.length > 1) window._KARTA_DEBUG&&console.log('[invAdm] Primeira linha dados:', rows[1]);
    if (st) st.textContent = '⏳ Sheet: "' + _usedSheet + '" · ' + (rows.length-1) + ' linhas · cols: ' + hdr.slice(0,5).join(' | ');

    _invData = [];
    for (var i = 1; i < rows.length; i++) {
      var r = rows[i];
      var centro = iCentro >= 0 ? String(r[iCentro]||'').trim() : '';
      var loja   = iLoja   >= 0 ? String(r[iLoja]||'').trim()   : '';
      var sm     = iSM     >= 0 ? String(r[iSM]||'').trim()     : '';
      var rawVC  = iVC     >= 0 ? String(r[iVC]||'').replace(',','.') : '';
      var rawVD  = iVD     >= 0 ? String(r[iVD]||'').replace(',','.') : '';
      var rawDt  = iData   >= 0 ? String(r[iData]||'').trim()   : '';
      if (!centro && !loja) continue;
      var vc = parseFloat(rawVC);
      var vd = parseFloat(rawVD);
      if (isNaN(vc)) vc = 0;
      if (isNaN(vd)) vd = null;   // null = sem valor (célula vazia no sheet)
      // Parse date — try M/D/YYYY, DD/MM/YYYY, YYYY-MM-DD
      var dt = _invParseDate(rawDt);
      _invData.push({ centro:centro, loja:loja, sm:sm, vc:vc, vd:vd, vt:vc+(vd||0), dt:dt, dtRaw:rawDt });
    }

    // Se o campo SM veio vazio na sheet, tentar preencher via LOJA_SUPERVISORES ou SALES_DATA
    var _smMissing = _invData.filter(function(r){ return !r.sm; }).length;
    if (_smMissing > 0) {
      _invData.forEach(function(r) {
        if (!r.sm && r.centro) {
          // Tentar LOJA_SUPERVISORES (GS) — campo gv = Sales Manager / GV
          if (window.LOJA_SUPERVISORES && LOJA_SUPERVISORES[r.centro]) {
            r.sm = LOJA_SUPERVISORES[r.centro].gv || LOJA_SUPERVISORES[r.centro].sup || '';
          }
          if (!r.sm && window.SALES_DATA && SALES_DATA.loja_sup && SALES_DATA.loja_sup[r.centro]) {
            r.sm = SALES_DATA.loja_sup[r.centro];
          }
          // Fallback final: usar GV global (Carlos Daniel)
          if (!r.sm) r.sm = 'CARLOS DANIEL ALMEIDA COSTA';
        }
      });
    }

    if (_invData.length === 0) {
      // Zero registos — mostrar headers reais para diagnóstico
      var _hdrInfo = 'Headers reais (' + hdr.length + '): ' + hdr.join(' | ');
      window._KARTA_DEBUG&&console.warn('[invAdm] 0 registos. ' + _hdrInfo);
      if (st) st.innerHTML = '⚠️ 0 registos. Colunas encontradas: <b>centro=' + iCentro + ', loja=' + iLoja + ', sm=' + iSM + ', vc=' + iVC + ', vd=' + iVD + ', data=' + iData + '</b><br><small>' + hdr.slice(0,8).join(' | ') + '</small>';
    } else {
      if (st) st.textContent = '✓ ' + (_invData.length) + ' registos carregados';
      if (btn) { btn.disabled = false; btn.innerHTML = '🔄 Sincronizar'; }
    }
    _invLoaded = true;

    // ── Construir INV_HIST_LIVE[centro][YYYY-MM] = {vC, vD} ──────────────────
    // Cada linha da sheet tem uma data — agrega o último valor de cada mês por loja
    // Os valores podem ser positivos ou negativos; o valor real da quebra = abs(vC) + abs(vD)
    // A sheet tem múltiplas linhas por loja/mês (uma por inventário); usamos a SOMA mensal
    // pois cada linha é uma ocorrência de quebra, não um saldo mensal
    (function() {
      var _hlMap = {}; // {centro: {YYYY-MM: {vcSum, vdSum, n}}}
      for (var _hi = 0; _hi < _invData.length; _hi++) {
        var _hr = _invData[_hi];
        if (!_hr.centro || !_hr.dt) continue;
        var _hm = _hr.dt.getFullYear() + '-' + String(_hr.dt.getMonth()+1).padStart(2,'0');
        if (!_hlMap[_hr.centro]) _hlMap[_hr.centro] = {};
        if (!_hlMap[_hr.centro][_hm]) _hlMap[_hr.centro][_hm] = {vcSum:0, vdSum:0, n:0};
        var _hEntry = _hlMap[_hr.centro][_hm];
        _hEntry.vcSum += (_hr.vc || 0);
        _hEntry.vdSum += (_hr.vd != null ? _hr.vd : 0);
        _hEntry.n++;
      }
      window.INV_HIST_LIVE = {};
      var _hCentros = Object.keys(_hlMap);
      for (var _hci = 0; _hci < _hCentros.length; _hci++) {
        var _hc = _hCentros[_hci];
        window.INV_HIST_LIVE[_hc] = {};
        var _hMeses = Object.keys(_hlMap[_hc]);
        for (var _hmi = 0; _hmi < _hMeses.length; _hmi++) {
          var _hmes = _hMeses[_hmi];
          var _he = _hlMap[_hc][_hmes];
          // Usar MÉDIA dos valores do mês (cada linha = um inventário realizado)
          // Valores são em decimal (ex: -0.006 = 0.6% de quebra)
          // Guardar como valor absoluto decimal (positivo)
          window.INV_HIST_LIVE[_hc][_hmes] = {
            vC: _he.vcSum / _he.n,
            vD: _he.vdSum / _he.n,
            n: _he.n
          };
        }
      }
      window._KARTA_DEBUG&&console.log('[invAdm] INV_HIST_LIVE construído:', Object.keys(window.INV_HIST_LIVE).length, 'lojas');
    })();
    // ─────────────────────────────────────────────────────────────────────────

    _invPopulateFilters();
    // Filtros por defeito: SM=CARLOS COSTA, Ano=2026, Mês=actual
    (function(){
      var _now = new Date();
      var _mesActual = String(_now.getMonth() + 1);
      var smEl  = document.getElementById('inv-f-sm');
      var anoEl = document.getElementById('inv-f-ano');
      var mesEl = document.getElementById('inv-f-mes');
      if (smEl)  { for(var i=0;i<smEl.options.length;i++){ if(smEl.options[i].value.toUpperCase().indexOf('CARLOS DANIEL')>=0){ smEl.value=smEl.options[i].value; break; } } }
      if (anoEl) { for(var i=0;i<anoEl.options.length;i++){ if(anoEl.options[i].value==='2026'){ anoEl.value='2026'; break; } } }
      if (mesEl) mesEl.value = _mesActual;
    })();
    invAdmRender();
  } catch(e) {
    if (st) st.textContent = '❌ Erro: ' + e.message;
    console.error('[invAdm]', e);
    if (btn) { btn.disabled = false; btn.innerHTML = '🔄 Sincronizar'; }
  }
  _invLoading = false;
};

function _invParseDate(s) {
  if (!s) return null;
  var m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) {
    var p1=+m[1], p2=+m[2], yr=+m[3];
    // Auto-detect: if p2 > 12 it must be DD/MM (p1=month, p2=day)
    // if p1 > 12 it must be MM/DD (p1=month, p2=day) — M/D/YYYY (US format from Google Sheets)
    // Google Sheets exports dates as M/D/YYYY
    if (p1 > 12) {
      // DD/MM/YYYY — day is first
      return new Date(yr, p2-1, p1);
    } else {
      // M/D/YYYY — month is first (Google Sheets default)
      return new Date(yr, p1-1, p2);
    }
  }
  // YYYY-MM-DD
  m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return new Date(+m[1], +m[2]-1, +m[3]);
  return new Date(s);
}

function _invFmt(v) {
  if (v == null || isNaN(v)) return '—';
  return (v * 100).toFixed(2) + '%';
}
function _invFmtDate(dt) {
  if (!dt || isNaN(dt.getTime())) return '—';
  return dt.toLocaleDateString('pt-PT');
}
// Limites: vc=-0.20%, vd=-0.80%, vt=-1.00%
var _INV_LIM = { vc: -0.002, vd: -0.008, vt: -0.010 };
function _invColor(v, tipo) {
  var lim = _INV_LIM[tipo] || -0.005;
  if (v >= lim * 0.4) return 'var(--green)';
  if (v >= lim * 0.8) return 'var(--amber)';
  return 'var(--red)';
}
function _invBadge(v, tipo) {
  var lim = _INV_LIM[tipo] || -0.005;
  var col = v >= lim*0.4 ? '#1a7040' : v >= lim*0.8 ? '#8a6000' : '#b83232';
  var bg  = v >= lim*0.4 ? '#e8f5e9' : v >= lim*0.8 ? '#fff8e1' : '#fdecea';
  return '<span style="background:'+bg+';color:'+col+';border-radius:4px;padding:1px 6px;font-size:10px;font-weight:700">' + _invFmt(v) + '</span>';
}

// ── Popula filtros ────────────────────────────────────────────────────────────
function _invPopulateFilters() {
  // Filtrar apenas lojas activas no mês do filtro
  var _fMes = (document.getElementById('inv-f-ano')&&document.getElementById('inv-f-mes'))
    ? ((document.getElementById('inv-f-ano').value||new Date().getFullYear())+'-'+String(document.getElementById('inv-f-mes').value||new Date().getMonth()+1).padStart(2,'0'))
    : null;
  var _activeData = _invData.filter(function(r){
    return !r.centro || (typeof isLojaActiva !== 'function') || isLojaActiva(r.centro, _fMes);
  });
  var sms    = [...new Set(_activeData.map(r=>r.sm))].filter(Boolean).sort();
  var centros= [...new Set(_activeData.map(r=>r.centro))].filter(Boolean).sort();
  var lojas  = [...new Set(_activeData.map(r=>r.loja))].filter(Boolean).sort();
  var anos   = [...new Set(_invData.map(r=>r.dt&&r.dt.getFullYear()).filter(Boolean))].sort();

  function fill(id, vals, label, defaultMatch) {
    var el = document.getElementById(id); if (!el) return;
    var cur = el.value;
    if (!cur && defaultMatch) {
      var found = vals.find(function(v){ return v.toUpperCase().indexOf(defaultMatch.toUpperCase()) >= 0; });
      if (found) cur = found;
    }
    el.innerHTML = '<option value="">'+label+'</option>';
    vals.forEach(function(v){ el.innerHTML += '<option value="'+v+'"'+(v==cur?' selected':'')+'>'+v+'</option>'; });
    if (cur) el.value = cur;
  }
  fill('inv-f-sm', sms, 'Todos', 'CARLOS DANIEL');
  fill('inv-f-centro', centros, 'Todos');
  fill('inv-f-loja', lojas, 'Todas');
  fill('inv-f-ano', anos, 'Todos');
}

// ── Filtrar dados ─────────────────────────────────────────────────────────────
function _invFiltered() {
  var fSM    = (document.getElementById('inv-f-sm')||{}).value    || '';
  var fCentro= (document.getElementById('inv-f-centro')||{}).value || '';
  var fLoja  = (document.getElementById('inv-f-loja')||{}).value   || '';
  var fAno   = (document.getElementById('inv-f-ano')||{}).value    || '';
  var fMes   = (document.getElementById('inv-f-mes')||{}).value    || '';
  var _fMesStr = (fAno && fMes) ? (fAno + '-' + String(fMes).padStart(2,'0')) : null;
  return _invData.filter(function(r){
    // Excluir lojas inactivas no mês filtrado
    if (r.centro && typeof isLojaActiva === 'function' && !isLojaActiva(r.centro, _fMesStr)) return false;
    if (fSM     && r.sm     !== fSM)     return false;
    if (fCentro && r.centro !== fCentro) return false;
    if (fLoja   && r.loja   !== fLoja)   return false;
    if (fAno    && r.dt && r.dt.getFullYear() !== +fAno) return false;
    if (fMes    && r.dt && (r.dt.getMonth()+1) !== +fMes) return false;
    return true;
  });
}

// ── Render principal ──────────────────────────────────────────────────────────
window.invAdmRender = function() {
  if (!_invLoaded) return;
  var data = _invFiltered();
  _invRenderCards(data);
  _invRenderUlt10(data);
  _invRenderPiores(data);
  invAdmRenderEvo();
  invAdmRenderTable();
};

// ── Cards resumo ──────────────────────────────────────────────────────────────
function _invRenderCards(data) {
  var el = document.getElementById('inv-adm-cards'); if (!el) return;
  if (!data.length) { el.innerHTML = ''; return; }
  var totalLojas = new Set(data.map(r=>r.centro)).size;
  var totalInv   = data.length;
  var _dataVD    = data.filter(function(r){ return r.vd !== null; });
  var mediaVD    = _dataVD.length ? _dataVD.reduce(function(a,r){return a+r.vd;},0) / _dataVD.length : null;
  var mediaVC    = data.reduce(function(a,r){return a+r.vc;},0) / data.length;
  var mediaVT    = data.reduce(function(a,r){return a+r.vt;},0) / data.length;
  var crit       = new Set(data.filter(function(r){return r.vt<_INV_LIM.vt;}).map(function(r){return r.centro;})).size;

  function card(label, val, sub, colClass) {
    var bg = colClass==='red'?'var(--rbg)':colClass==='amber'?'var(--abg)':colClass==='green'?'var(--gbg)':'var(--s2)';
    var tc = colClass==='red'?'var(--red)':colClass==='amber'?'var(--amber)':colClass==='green'?'var(--green)':'var(--tx)';
    return '<div style="background:'+bg+';border-radius:8px;padding:12px 16px;min-width:130px">'
      +'<div style="font-size:10px;color:var(--t3);font-weight:600;text-transform:uppercase;margin-bottom:4px">'+label+'</div>'
      +'<div style="font-size:20px;font-weight:700;color:'+tc+'">'+val+'</div>'
      +'<div style="font-size:10px;color:var(--t3);margin-top:2px">'+sub+'</div>'
      +'</div>';
  }
  el.innerHTML =
    card('Lojas', totalLojas, 'com inventário') +
    card('Inventários', totalInv, 'registos') +
    card('Méd. Q.Total', _invFmt(mediaVT), 'por inventário', mediaVT<_INV_LIM.vt*0.4?'red':mediaVT<_INV_LIM.vt*0.8?'amber':'green') +
    (mediaVD !== null ? card('Méd. Q.Desc.', _invFmt(mediaVD), 'por inventário', mediaVD<_INV_LIM.vd*0.4?'red':mediaVD<_INV_LIM.vd*0.8?'amber':'green') : card('Méd. Q.Desc.', '—', 'sem dados')) +
    card('Méd. Q.Conh.', _invFmt(mediaVC), 'por inventário') +
    card('Críticas', crit, 'lojas > -1%', crit>0?'red':'green');
}

// ── Últimos 10 inventários ────────────────────────────────────────────────────
function _invRenderUlt10(data) {
  var el = document.getElementById('inv-adm-ult10'); if (!el) return;
  var sorted = data.slice().sort(function(a,b){
    var da = a.dt&&!isNaN(a.dt)?a.dt.getTime():0;
    var db = b.dt&&!isNaN(b.dt)?b.dt.getTime():0;
    return db - da;
  }).slice(0, 10);
  if (!sorted.length) { el.innerHTML = '<div style="color:var(--t3);font-size:12px;padding:8px">Sem dados</div>'; return; }
  el.innerHTML = sorted.map(function(r){
    return '<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--bd)">'
      +'<div style="flex:1;min-width:0">'
        +'<div style="font-weight:600;color:var(--tx);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+r.centro+' · '+r.loja.replace('Arreiou ','')+'</div>'
        +'<div style="font-size:10px;color:var(--t3)">'+r.sm+' · '+_invFmtDate(r.dt)+'</div>'
      +'</div>'
      +'<div style="text-align:right;flex-shrink:0;display:flex;flex-direction:column;gap:3px;align-items:flex-end">'
        +'<div>'+_invBadge(r.vt,'vt')+'</div>'
        +'<div style="display:flex;align-items:center;gap:4px;opacity:0.65">'
          +'<span style="font-size:9px;color:var(--t3)">C</span><span style="font-size:10px;color:var(--t2)">'+_invFmt(r.vc)+'</span>'
          +(r.vd !== null ? ' <span style="font-size:9px;color:var(--t3);margin-left:2px">D</span><span style="font-size:10px;color:var(--t2)">'+_invFmt(r.vd)+'</span>' : '')
        +'</div>'
      +'</div>'
    +'</div>';
  }).join('');
}

// ── Top 10 piores lojas ───────────────────────────────────────────────────────
function _invRenderPiores(data) {
  var el = document.getElementById('inv-adm-piores'); if (!el) return;
  // Agrupa por centro — média da quebra total
  var map = {};
  data.forEach(function(r){
    if (!map[r.centro]) map[r.centro] = {centro:r.centro, loja:r.loja, sm:r.sm, vtSum:0, vcSum:0, vdSum:0, n:0, nVD:0};
    map[r.centro].vtSum += r.vt;
    map[r.centro].vcSum += r.vc;
    if (r.vd !== null) { map[r.centro].vdSum += r.vd; map[r.centro].nVD++; }
    map[r.centro].n++;
    map[r.centro].loja = r.loja;
    map[r.centro].sm   = r.sm;
  });
  var arr = Object.values(map).map(function(m){
    return { centro:m.centro, loja:m.loja, sm:m.sm,
      vtMedia: m.n ? m.vtSum/m.n : 0,
      vcMedia: m.n ? m.vcSum/m.n : 0,
      vdMedia: m.nVD ? m.vdSum/m.nVD : null,
      n: m.n };
  });
  arr.sort(function(a,b){ return a.vtMedia - b.vtMedia; }); // pior primeiro
  var top10 = arr.slice(0, 10);
  var maxAbs = top10.length ? Math.abs(top10[0].vtMedia) : 1;
  if (!top10.length) { el.innerHTML = '<div style="color:var(--t3);font-size:12px;padding:8px">Sem dados</div>'; return; }
  el.innerHTML = top10.map(function(r, idx){
    var pct = maxAbs > 0 ? Math.abs(r.vtMedia)/maxAbs*100 : 0;
    var barCol = r.vtMedia < _INV_LIM.vt ? '#b83232' : r.vtMedia < _INV_LIM.vt*0.5 ? '#8a6000' : '#1a7040';
    return '<div style="padding:7px 0;border-bottom:1px solid var(--bd)">'
      +'<div style="display:flex;align-items:center;gap:8px">'
        +'<div style="font-size:10px;color:var(--t3);min-width:18px;font-weight:700">'+(idx+1)+'</div>'
        +'<div style="flex:1;min-width:0">'
          +'<div style="font-size:11px;font-weight:600;color:var(--tx);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+r.centro+' · '+r.loja.replace(/Arreiou\s*/,'').substring(0,22)+'</div>'
          +'<div style="background:#eee;border-radius:3px;height:4px;margin-top:4px;overflow:hidden"><div style="background:'+barCol+';height:100%;width:'+pct.toFixed(1)+'%;transition:width .3s"></div></div>'
        +'</div>'
        +'<div style="text-align:right;flex-shrink:0;min-width:52px">'+_invBadge(r.vtMedia,'vt')+'</div>'
      +'</div>'
      +'<div style="display:flex;gap:6px;margin-top:4px;padding-left:26px">'
        +'<span style="font-size:9px;color:var(--t3)">C</span>'+_invBadge(r.vcMedia,'vc')
        +(r.vdMedia !== null ? ' <span style="font-size:9px;color:var(--t3);margin-left:4px">D</span>'+_invBadge(r.vdMedia,'vd') : '')
      +'</div>'
    +'</div>';
  }).join('');
}

// ── Evolução mensal (Chart.js) ────────────────────────────────────────────────
window.invAdmRenderEvo = function() {
  var data = _invFiltered();
  var tipo = (document.getElementById('inv-adm-evo-tipo')||{}).value || 'total';
  // Agrupa por mês
  // Calcular months a partir de todos os dados (sem filtro de tipo)
  var _allMonths = {};
  data.forEach(function(r){ if (r.dt && !isNaN(r.dt)) { var ym=r.dt.getFullYear()+'-'+String(r.dt.getMonth()+1).padStart(2,'0'); _allMonths[ym]=1; } });
  var months = Object.keys(_allMonths).sort();
  var labels = months.map(function(m){
    var parts = m.split('-');
    var names = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
    return (names[+parts[1]-1]||parts[1])+' '+parts[0].slice(2);
  });

  var ctx = document.getElementById('inv-adm-evo-chart');
  if (!ctx) return;
  if (_invEvoChart) { try{_invEvoChart.destroy();}catch(e){} _invEvoChart=null; }
  if (!window.Chart || !months.length) return;

  // Calcular os 3 datasets independentemente (total, conhecida, desconhecida)
  function _calcDataset(tipo2) {
    var bm = {};
    data.forEach(function(r){
      if (!r.dt || isNaN(r.dt)) return;
      if (tipo2 === 'desconhecida' && r.vd === null) return;
      var ym = r.dt.getFullYear()+'-'+String(r.dt.getMonth()+1).padStart(2,'0');
      if (!bm[ym]) bm[ym] = {sum:0, n:0};
      bm[ym].sum += tipo2==='conhecida' ? r.vc : tipo2==='desconhecida' ? r.vd : r.vt;
      bm[ym].n++;
    });
    return months.map(function(m){ return bm[m] && bm[m].n ? +(bm[m].sum/bm[m].n*100).toFixed(3) : null; });
  }
  var valsVT = _calcDataset('total');
  var valsVC = _calcDataset('conhecida');
  var valsVD = _calcDataset('desconhecida');

  // Linhas de limite
  var limVT = (_INV_LIM.vt * 100);
  var limVC = (_INV_LIM.vc * 100);
  var limVD = (_INV_LIM.vd * 100);

  _invEvoChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Q. Total (%)',
          data: valsVT,
          borderColor: '#5030a0',
          backgroundColor: 'rgba(80,48,160,0.08)',
          borderWidth: 2,
          pointRadius: 4,
          pointBackgroundColor: valsVT.map(function(v){ return v===null?'transparent':v<limVT?'#b83232':v<limVT*0.5?'#8a6000':'#1a7040'; }),
          tension: 0.3,
          fill: false,
          spanGaps: true
        },
        {
          label: 'Q. Conhecida (%)',
          data: valsVC,
          borderColor: '#1a7040',
          backgroundColor: 'rgba(26,112,64,0.06)',
          borderWidth: 2,
          pointRadius: 4,
          pointBackgroundColor: valsVC.map(function(v){ return v===null?'transparent':v<limVC?'#b83232':v<limVC*0.5?'#8a6000':'#1a7040'; }),
          tension: 0.3,
          fill: false,
          spanGaps: true
        },
        {
          label: 'Q. Desconhecida (%)',
          data: valsVD,
          borderColor: '#b83232',
          backgroundColor: 'rgba(184,50,50,0.06)',
          borderWidth: 2,
          pointRadius: 4,
          pointBackgroundColor: valsVD.map(function(v){ return v===null?'transparent':v<limVD?'#b83232':v<limVD*0.5?'#8a6000':'#1a7040'; }),
          tension: 0.3,
          fill: false,
          spanGaps: true
        }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: true, position: 'top', labels: { font:{size:11}, boxWidth:14, padding:16 } },
        tooltip: { callbacks: { label: function(c){ return c.dataset.label+': '+(c.parsed.y!=null?c.parsed.y.toFixed(3)+'%':'—'); } } },
        annotation: {}
      },
      scales: {
        y: {
          ticks: { callback: function(v){ return v+'%'; } },
          grid: { color: 'var(--bd)' }
        },
        x: { grid: { display: false } }
      }
    }
  });
};

// ── Tabela master ─────────────────────────────────────────────────────────────
window.invAdmSort = function(col) {
  if (_invSort.col === col) {
    _invSort.dir *= -1;
  } else {
    _invSort.col = col;
    _invSort.dir = col==='ni' ? -1 : 1; // ni: mais inventários primeiro por defeito
  }
  invAdmRenderTable();
};

window.invAdmRenderTable = function() {
  var data   = _invFiltered();
  var search = ((document.getElementById('inv-adm-search')||{}).value||'').toLowerCase();

  // Agrupa por centro (mostra última data, soma inventários)
  var map = {};
  data.forEach(function(r){
    var k = r.centro;
    if (!map[k]) map[k] = {centro:k, loja:r.loja, sm:r.sm, vcSum:0, vdSum:0, vtSum:0, n:0, nVD:0, lastDt:null};
    var m = map[k];
    m.vcSum += r.vc;
    if (r.vd !== null) { m.vdSum += r.vd; m.nVD++; }
    m.vtSum += r.vt; m.n++;
    if (!m.lastDt || (r.dt && r.dt > m.lastDt)) m.lastDt = r.dt;
    m.loja = r.loja; m.sm = r.sm;
  });
  var rows = Object.values(map).map(function(m){
    return { centro:m.centro, loja:m.loja, sm:m.sm,
      vc: m.n?m.vcSum/m.n:0,
      vd: m.nVD ? m.vdSum/m.nVD : null,
      vt: m.n?m.vtSum/m.n:0,
      ni: m.n, data: m.lastDt };
  });

  // Search
  if (search) rows = rows.filter(function(r){
    return r.centro.toLowerCase().includes(search) ||
           r.loja.toLowerCase().includes(search)   ||
           r.sm.toLowerCase().includes(search);
  });

  // Sort
  var sc = _invSort.col, sd = _invSort.dir;
  rows.sort(function(a,b){
    var va, vb;
    if (sc==='centro') { va=a.centro; vb=b.centro; return sd*(va<vb?-1:va>vb?1:0); }
    if (sc==='loja')   { va=a.loja;   vb=b.loja;   return sd*(va<vb?-1:va>vb?1:0); }
    if (sc==='sm')     { va=a.sm;     vb=b.sm;     return sd*(va<vb?-1:va>vb?1:0); }
    if (sc==='data')   { va=a.data?a.data.getTime():0; vb=b.data?b.data.getTime():0; return sd*(va-vb); }
    if (sc==='vc')  return sd*(a.vc-b.vc);
    if (sc==='vd')  return sd*(a.vd-b.vd);
    if (sc==='vt')  return sd*(a.vt-b.vt);
    if (sc==='ni')  return sd*(a.ni-b.ni);
    return 0;
  });

  // Sort indicators
  ['centro','loja','sm','data','vd','vc','vt','ni'].forEach(function(c){
    var el = document.getElementById('inv-s-'+c); if (!el) return;
    el.textContent = _invSort.col===c ? (_invSort.dir===1?'▲':'▼') : '';
  });

  var tbody = document.getElementById('inv-adm-tbody'); if (!tbody) return;
  var ct    = document.getElementById('inv-adm-table-ct');
  if (ct) ct.textContent = rows.length + ' lojas';

  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="8" style="padding:20px;text-align:center;color:var(--t3)">Sem dados</td></tr>';
    return;
  }
  tbody.innerHTML = rows.map(function(r, i){
    var bg = i%2===0 ? '' : 'background:var(--s2)';
    return '<tr style="'+bg+'">'
      +'<td style="padding:7px 10px;font-family:monospace;font-size:11px;color:var(--t3)">'+r.centro+'</td>'
      +'<td style="padding:7px 10px;font-weight:500;color:var(--tx)">'+r.loja.replace(/^Arreiou\s*/,'').substring(0,28)+'</td>'
      +'<td style="padding:7px 10px;color:var(--t2);font-size:11px">'+r.sm+'</td>'
      +'<td style="padding:7px 10px;color:var(--t2);font-size:11px;white-space:nowrap">'+_invFmtDate(r.data)+'</td>'
      +'<td style="padding:7px 10px;text-align:right">'+(r.vd !== null ? _invBadge(r.vd,'vd') : '<span style="color:var(--t4)">—</span>')+'</td>'
      +'<td style="padding:7px 10px;text-align:right">'+_invBadge(r.vc,'vc')+'</td>'
      +'<td style="padding:7px 10px;text-align:right">'+_invBadge(r.vt,'vt')+'</td>'
      +'<td style="padding:7px 10px;text-align:right;font-weight:600;color:var(--tx)">'+r.ni+'</td>'
    +'</tr>';
  }).join('');
};

// ── Reset filtros ─────────────────────────────────────────────────────────────
window.invAdmResetFilters = function() {
  ['inv-f-sm','inv-f-centro','inv-f-loja','inv-f-ano','inv-f-mes'].forEach(function(id){
    var el = document.getElementById(id); if (el) el.value = '';
  });
  var s = document.getElementById('inv-adm-search'); if (s) s.value = '';
  invAdmRender();
};

// ── Inicializar quando o tab é aberto ─────────────────────────────────────────
var _origSwitchAdmTabInv = switchAdmTab;
switchAdmTab = function(t) {
  _origSwitchAdmTabInv(t);
  if (t === 'inventarios') {
    if (!_invLoaded && !_invLoading) invAdmLoad();
    else if (_invLoaded) invAdmRender();
    // Trigger evo chart (canvas needs to be visible)
    setTimeout(invAdmRenderEvo, 150);
  }
  if (t === 'hist') {
    // Re-render with latest Firebase data
    setTimeout(function(){ try { histRender(); } catch(e){} }, 50);
  }
  if (t === 'cobertura') {
    var el = document.getElementById('as-cobertura');
    if (el && el.getAttribute('data-cob-loaded') === '0') {
      el.setAttribute('data-cob-loaded', '1');
      _cobLoadSheet();
    }
  }
};

})();
