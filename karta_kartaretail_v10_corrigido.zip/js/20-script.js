
/* PATCH KARTA — Vendas: dados completos e comparativo por datas
   Corrige falhas causadas por filtros month(A) do Google Visualization e por dados mensais/dia não injectados. */
(function(){
  if (window.__KARTA_VENDAS_PATCH_V3) return;
  window.__KARTA_VENDAS_PATCH_V3 = true;

  function _num(v){
    if (v == null || v === '') return null;
    if (typeof numAny === 'function') return numAny(v);
    if (typeof v === 'number') return isNaN(v) ? null : v;
    var s = String(v).trim().replace(/\u00a0/g,'').replace(/\s+/g,'');
    if (!s) return null;
    var hasComma = s.indexOf(',') >= 0, hasDot = s.indexOf('.') >= 0;
    if (hasComma && hasDot) s = s.replace(/\./g,'').replace(',', '.');
    else if (hasComma) s = s.replace(',', '.');
    else if (hasDot && /^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g,'');
    var n = Number(s); return isNaN(n) ? null : n;
  }
  function _ym(d){ return String(d||'').slice(0,7); }
  function _pad(n){ return String(n).padStart(2,'0'); }
  function _fmtDate(d){ return d.getFullYear()+'-'+_pad(d.getMonth()+1)+'-'+_pad(d.getDate()); }
  function _monthRangeFromFilters(){
    var y = (document.getElementById('vnd-f-year')||{}).value || String(new Date().getFullYear());
    var m = (document.getElementById('vnd-f-month')||{}).value || 'ALL';
    if (y === 'ALL') y = String(new Date().getFullYear());
    var start, end;
    if (m === 'ALL') { start = new Date(+y,0,1); end = new Date(+y,11,31); }
    else { start = new Date(+y,+m-1,1); end = new Date(+y,+m,0); }
    return {start:_fmtDate(start), end:_fmtDate(end)};
  }
  function _dateRangeFromComparativo(){
    var a1=(document.getElementById('vnd-cp-a1')||{}).value, a2=(document.getElementById('vnd-cp-a2')||{}).value;
    var b1=(document.getElementById('vnd-cp-b1')||{}).value, b2=(document.getElementById('vnd-cp-b2')||{}).value;
    var dates=[a1,a2,b1,b2].filter(Boolean).sort();
    if(dates.length) return {start:dates[0], end:dates[dates.length-1]};
    return _monthRangeFromFilters();
  }
  function _hasDailyInRange(start,end){
    var db = window.DB || {};
    return Object.keys(db).some(function(c){
      return ((db[c]||{}).r||[]).some(function(r){ return r.d && r.d>=start && r.d<=end && (r.vs!=null || r.cl!=null || r.tk!=null); });
    });
  }
  function _rebuildSalesFromDB(){
    if(!window.SALES_DATA) window.SALES_DATA = {lm:{},wd:{},net_monthly:[],net_wd:[],lojas:[],categorias:[],top20:[],months:[],loja_name:{},loja_sup:{}};
    var SD=window.SALES_DATA;
    if(!SD.lm) SD.lm={}; if(!SD.wd) SD.wd={};
    var acc={}, wdAcc={};
    Object.keys(window.DB||{}).forEach(function(c){
      var rows=((window.DB[c]||{}).r||[]);
      rows.forEach(function(r){
        if(!r.d) return; var m=_ym(r.d); if(!m) return;
        if(!acc[c]) acc[c]={}; if(!acc[c][m]) acc[c][m]={vt:0,vs_n:0,cl:0,cl_n:0,tk:0,tk_n:0,ru:0,ru_n:0,vp:0,vp_n:0,n:0};
        var a=acc[c][m];
        if(r.vs!=null){ a.vt += Number(r.vs)||0; a.vs_n++; a.n++; }
        if(r.cl!=null){ a.cl += Number(r.cl)||0; a.cl_n++; }
        if(r.tk!=null){ a.tk += Number(r.tk)||0; a.tk_n++; }
        if(r.ru!=null){ a.ru += Number(r.ru)||0; a.ru_n++; }
        if(r.vp!=null){ a.vp += Number(r.vp)||0; a.vp_n++; }
        var dt=new Date(r.d+'T00:00:00'); var wd=dt.getDay();
        if(!wdAcc[c]) wdAcc[c]={}; if(!wdAcc[c][m]) wdAcc[c][m]={}; if(!wdAcc[c][m][wd]) wdAcc[c][m][wd]={vs:[],cl:[],tk:[],ru:[],vp:[]};
        var w=wdAcc[c][m][wd];
        if(r.vs!=null) w.vs.push(Number(r.vs)||0); if(r.cl!=null) w.cl.push(Number(r.cl)||0); if(r.tk!=null) w.tk.push(Number(r.tk)||0); if(r.ru!=null) w.ru.push(Number(r.ru)||0); if(r.vp!=null) w.vp.push(Number(r.vp)||0);
      });
    });
    Object.keys(acc).forEach(function(c){
      if(!SD.lm[c]) SD.lm[c]={};
      Object.keys(acc[c]).forEach(function(m){ var a=acc[c][m];
        SD.lm[c][m]=Object.assign(SD.lm[c][m]||{}, {
          vt:Math.round(a.vt), vs:a.vs_n?Math.round(a.vt/a.vs_n):null, cl:a.cl_n?Math.round(a.cl/a.cl_n):null,
          tk:a.tk_n?Math.round(a.tk/a.tk_n):null, ru:a.ru_n?Math.round(a.ru/a.ru_n*100)/100:null,
          vp:a.vp_n?Math.round(a.vp/a.vp_n):null, n:a.vs_n||a.n||0
        });
      });
    });
    function avg(ar){return ar&&ar.length?ar.reduce(function(s,v){return s+v;},0)/ar.length:null;}
    Object.keys(wdAcc).forEach(function(c){ SD.wd[c]=SD.wd[c]||{}; Object.keys(wdAcc[c]).forEach(function(m){ SD.wd[c][m]=SD.wd[c][m]||{}; Object.keys(wdAcc[c][m]).forEach(function(wd){ var x=wdAcc[c][m][wd]; SD.wd[c][m][wd]={vs:avg(x.vs),cl:avg(x.cl),tk:avg(x.tk),ru:avg(x.ru),vp:avg(x.vp),n:x.vs.length}; }); }); });
    var nm={}; Object.keys(SD.lm).forEach(function(c){ Object.keys(SD.lm[c]).forEach(function(m){ var d=SD.lm[c][m]; if(!nm[m]) nm[m]={m:m,vt:0,vsN:0,cl:0,clN:0,tk:0,tkN:0,ru:0,ruN:0,vp:0,vpN:0}; var x=nm[m]; if(d.vt) x.vt+=d.vt; if(d.vs!=null&&d.n){x.vsN+=d.n;} if(d.cl!=null){x.cl+=d.cl;x.clN++;} if(d.tk!=null){x.tk+=d.tk;x.tkN++;} if(d.ru!=null){x.ru+=d.ru;x.ruN++;} if(d.vp!=null){x.vp+=d.vp;x.vpN++;} }); });
    SD.net_monthly=Object.keys(nm).sort().map(function(m){ var x=nm[m]; return {m:m,vt:Math.round(x.vt),vs:x.vsN?Math.round(x.vt/x.vsN):null,cl:x.clN?Math.round(x.cl/x.clN):null,tk:x.tkN?Math.round(x.tk/x.tkN):null,ru:x.ruN?x.ru/x.ruN:null,vp:x.vpN?Math.round(x.vp/x.vpN):null,n:x.vsN}; });
    // net_wd recompute
    var agg=[0,1,2,3,4,5,6].map(function(){return {vs:[],cl:[],tk:[],ru:[],vp:[]};});
    Object.keys(SD.wd).forEach(function(c){ Object.keys(SD.wd[c]).forEach(function(m){ Object.keys(SD.wd[c][m]).forEach(function(wd){ var d=SD.wd[c][m][wd], a=agg[+wd]; ['vs','cl','tk','ru','vp'].forEach(function(k){ if(d[k]!=null) a[k].push(d[k]); }); }); }); });
    var WD=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
    SD.net_wd=agg.map(function(a,i){return {wd:WD[i],vs:avg(a.vs),cl:avg(a.cl),tk:avg(a.tk),ru:avg(a.ru),vp:avg(a.vp),n:a.vs.length};});
  }
  async function _fetchDaily(start,end){
    if(!window.GS_ID || typeof fetchCSV!=='function') return 0;
    // Usa datas literais em vez de month(A), porque month(A) no Google Visualization é zero-based.
    var q = "select A, B, H, I, J where A >= date '"+start+"' and A <= date '"+end+"' label A 'date', B 'centro', H 'vs', I 'tk', J 'cl'";
    var rows = (typeof salesFetchCSV==='function') ? await salesFetchCSV('&tq='+encodeURIComponent(q)) : await fetchCSV('https://docs.google.com/spreadsheets/d/'+window.GS_ID+'/gviz/tq?tqx=out:csv&sheet=SalesKPIsStore&tq='+encodeURIComponent(q)+'&t='+Date.now());
    var h=rows[0]||[]; var id=fi(h,'date'), ic=fi(h,'centro'), iv=fi(h,'vs'), it=fi(h,'tk'), il=fi(h,'cl');
    if(id<0)id=0; if(ic<0)ic=1; if(iv<0)iv=2; if(it<0)it=3; if(il<0)il=4;
    var n=0;
    for(var i=1;i<rows.length;i++){
      var r=rows[i], ds=(typeof pd==='function'?pd(r[id]):String(r[id]||'').slice(0,10)); if(!ds) continue;
      var c=String(r[ic]||'').trim(); if(!c) continue;
      var vv=_num(r[iv]), tv=_num(r[it]), cv=_num(r[il]);
      if(typeof upsRow==='function') upsRow(c,ds,{vs:vv!=null?Math.round(vv):null,tk:tv!=null?Math.round(tv):null,cl:cv!=null?Math.round(cv):null});
      n++;
    }
    _rebuildSalesFromDB();
    return n;
  }
  async function _ensureVendasData(){
    if(window.__vendasPatchLoading) return window.__vendasPatchLoading;
    window.__vendasPatchLoading=(async function(){
      try{
        var r1=_monthRangeFromFilters(); var r2=_dateRangeFromComparativo();
        var start = r1.start < r2.start ? r1.start : r2.start;
        var end   = r1.end   > r2.end   ? r1.end   : r2.end;
        if(!_hasDailyInRange(start,end)) await _fetchDaily(start,end);
        else _rebuildSalesFromDB();
      }catch(e){ console.warn('[Karta vendas patch]',e); }
      finally{ window.__vendasPatchLoading=null; }
    })();
    return window.__vendasPatchLoading;
  }

  var _origRenderAll = window.vendasRenderAll;
  window.vendasRenderAll = async function(){
    await _ensureVendasData();
    try { if(typeof vendasCards==='function') vendasCards(); } catch(e){ console.error('vendasCards:',e); }
    try { if(typeof vendasMonRender==='function') vendasMonRender(); } catch(e){ console.error('vendasMon:',e); }
    try { if(typeof vendasWdRender==='function') vendasWdRender(); } catch(e){ console.error('vendasWd:',e); }
    try { if(typeof vendasRankRender==='function') vendasRankRender(); } catch(e){ console.error('vendasRank:',e); }
    try { if(typeof vendasComparativoRender==='function') vendasComparativoRender(); } catch(e){ console.error('vendasCmp:',e); }
    try { if(typeof vendasCatRender==='function') vendasCatRender(); } catch(e){ console.error('vendasCat:',e); }
    try { if(typeof vendasSkuRender==='function') vendasSkuRender(); } catch(e){ console.error('vendasSku:',e); }
  };
  window.vendasForceSync = async function(){ var r=_dateRangeFromComparativo(); await _fetchDaily(r.start,r.end); window.vendasRenderAll(); };

  // Corrige também o sync global, sem substituir toda a função: depois do sync, refaz os agregados a partir de DB.
  var _oldGsSyncAll = window.gsSyncAll;
  if (typeof _oldGsSyncAll === 'function') {
    window.gsSyncAll = async function(){ var out=await _oldGsSyncAll.apply(this, arguments); try{ _rebuildSalesFromDB(); if((window._lastAnalise==='vendas')&&window.vendasRenderAll) window.vendasRenderAll(); }catch(e){} return out; };
  }
})();
