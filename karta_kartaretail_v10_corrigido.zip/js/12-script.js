
// ── Fade indicators para stabs ────────────────────────────────────────────────
(function(){
  function wrapStabs(stabs) {
    if (!stabs || stabs.dataset.wrapped || (stabs.parentElement && stabs.parentElement.classList.contains('stabs-wrap'))) return;
    stabs.dataset.wrapped = '1';
    var wrap = document.createElement('div');
    wrap.className = 'stabs-wrap';
    // Para tnav: copiar posicionamento fixo para o wrapper
    if (stabs.classList.contains('tnav')) {
      wrap.style.cssText = 'position:fixed;top:var(--HH);left:0;right:0;z-index:290;height:var(--TH)';
      stabs.style.position = 'static';
      stabs.style.top = '';
      stabs.style.left = '';
      stabs.style.right = '';
      stabs.style.zIndex = '';
      stabs.style.height = '100%';
    }
    stabs.parentNode.insertBefore(wrap, stabs);
    // Botão esquerda
    var btnL = document.createElement('button');
    btnL.className = 'stabs-arr'; btnL.innerHTML = '&#8249;'; btnL.title = 'Deslizar esquerda';
    btnL.onclick = function(){ stabs.scrollBy({left:-180,behavior:'smooth'}); };
    wrap.appendChild(btnL);
    wrap.appendChild(stabs);
    // Botão direita
    var btnR = document.createElement('button');
    btnR.className = 'stabs-arr'; btnR.innerHTML = '&#8250;'; btnR.title = 'Deslizar direita';
    btnR.onclick = function(){ stabs.scrollBy({left:180,behavior:'smooth'}); };
    wrap.appendChild(btnR);
    updateFade(stabs, wrap);
    stabs.addEventListener('scroll', function(){
      updateFade(stabs, wrap);
      if(btnL) btnL.disabled = stabs.scrollLeft <= 2;
      if(btnR) btnR.disabled = stabs.scrollLeft >= stabs.scrollWidth - stabs.clientWidth - 2;
    });
    // Estado inicial dos botões
    setTimeout(function(){
      if(btnL) btnL.disabled = stabs.scrollLeft <= 2;
      if(btnR) btnR.disabled = stabs.scrollLeft >= stabs.scrollWidth - stabs.clientWidth - 2;
    }, 100);
    // ResizeObserver para actualizar quando o conteúdo muda
    if (window.ResizeObserver) {
      new ResizeObserver(function(){ updateFade(stabs, wrap); }).observe(stabs);
    }
  }

  function updateFade(stabs, wrap) {
    var atStart = stabs.scrollLeft <= 2;
    var atEnd   = stabs.scrollLeft >= stabs.scrollWidth - stabs.clientWidth - 2;
    wrap.classList.toggle('at-start', atStart);
    wrap.classList.toggle('at-end',   atEnd);
  }

  function initFades() {
    document.querySelectorAll('.stabs').forEach(function(stabs) {
      wrapStabs(stabs);
    });
    // Wrap the main tnav too
    var tnav = document.querySelector('.tnav');
    if (tnav && !tnav.parentElement.classList.contains('stabs-wrap')) {
      wrapStabs(tnav);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFades);
  } else {
    initFades();
  }
  // Também correr após um delay para apanhar stabs geradas dinamicamente
  setTimeout(initFades, 500);
  setTimeout(initFades, 2000);
})();
