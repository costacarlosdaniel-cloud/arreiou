
import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.11.0/firebase-app.js';
import { initializeAppCheck, ReCaptchaV3Provider } from 'https://www.gstatic.com/firebasejs/12.11.0/firebase-app-check.js';
import { getStorage, ref as storageRef, uploadString, getDownloadURL } from 'https://www.gstatic.com/firebasejs/12.11.0/firebase-storage.js';
import {
  getFirestore, collection, doc, getDoc, setDoc, deleteDoc,
  query as fsQuery, orderBy, where, startAt as fsStartAt, endAt as fsEndAt,
  getDocs, onSnapshot, writeBatch, documentId, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/12.11.0/firebase-firestore.js';

// ── FIREBASE CONFIG ─────────────────────────────────────────────────────────

const firebaseConfig = {
  apiKey:            "AIzaSyC7-An5P7YxjoW5olyrzt68Skbr3PXXclc",
  authDomain:        "kartaretail.firebaseapp.com",
  projectId:         "kartaretail",
  storageBucket:     "kartaretail.firebasestorage.app",
  messagingSenderId: "1094139752969",
  appId:             "1:1094139752969:web:f054d974e86326ac6afed8"
};

const app = initializeApp(firebaseConfig);
window._KARTA_DEBUG&&console.log('[Karta] build objetivos-sales-ratio-pao-v1');

// ── PROTEÇÃO ANTI-BOTS (Firebase App Check) ───────────────────────────────
// Para ativar a sério: Firebase Console > App Check > Web app > reCAPTCHA v3/Enterprise
// Depois coloca aqui a site key. Sem isto, o código continua a funcionar normalmente.
const KARTA_APPCHECK_SITE_KEY = ''; // App Check desactivado
try {
  if (KARTA_APPCHECK_SITE_KEY && KARTA_APPCHECK_SITE_KEY.length > 20) {
    self.FIREBASE_APPCHECK_DEBUG_TOKEN = false;
    initializeAppCheck(app, {
      provider: new ReCaptchaV3Provider(KARTA_APPCHECK_SITE_KEY),
      isTokenAutoRefreshEnabled: true
    });
    window._KARTA_DEBUG&&console.log('[AppCheck] activo');
  } else {
    window._KARTA_DEBUG&&console.warn('[AppCheck] inactivo — colocar site key para proteger contra bots');
  }
} catch(e) { window._KARTA_DEBUG&&console.warn('[AppCheck] erro:', e); }

const db  = getFirestore(app);
const storage = getStorage(app);
window._fbDb = db;
window._fbStorage = storage;
window._KARTA_DEBUG = false; // set true in devtools to enable verbose logging
// ── Captura global de erros de promises não tratadas ────────────────────────
window.addEventListener('unhandledrejection', function(e) {
  if (window._KARTA_DEBUG) {
    console.error('[Karta] Promise não tratada:', e.reason);
  }
  // Erros de rede Firebase são expectáveis em modo offline — não mostrar ao utilizador
  var msg = e.reason && (e.reason.message || String(e.reason));
  if (msg && (msg.indexOf('offline') >= 0 || msg.indexOf('network') >= 0 || msg.indexOf('Failed to fetch') >= 0)) return;
  // Erros de quota de localStorage também são silenciosos
  if (msg && msg.indexOf('QuotaExceeded') >= 0) return;
  if (window._KARTA_DEBUG) {
    var st = document.getElementById('upst');
    if (st) { st.textContent = '⚠ Erro interno'; st.className = 'upst err'; setTimeout(function(){ st.textContent=''; st.className='upst'; }, 5000); }
  }
});



// ── LOW COST MODE ─────────────────────────────────────────────────────────
// Objectivo: quase zero leituras repetidas e muito menos escritas.
const KARTA_LOW_COST_MODE = true;
const APPDATA_CACHE_TTL   = 24 * 60 * 60 * 1000; // 24 horas — menos leituras em appData
const QUERY_CACHE_TTL     = 12 * 60 * 60 * 1000; // 12 horas — menos leituras em queries KPI
const WRITE_DEBOUNCE_MS   = 3000;                // agrupa edições rápidas (era 8s)
// LOW COST extremo: listeners realtime desligados por defeito.
// Para activar temporariamente no browser: localStorage.setItem('karta_realtime','1') e recarregar.
const KARTA_REALTIME_MODE = localStorage.getItem('karta_realtime') === '1';


// ── FIRESTORE COMPAT LAYER ──────────────────────────────────────────────────
// Mantém os nomes antigos (ref/set/get/onValue) para o resto do HTML continuar a funcionar.
// Estrutura nova:
//   entries/{A030_2026-04-18}             => { value, key, loja, data, mes }
//   appData/{adm_obj|escalas|sup_data...} => { value }
const APPDATA_COL = 'appData';
const ENTRIES_COL = 'entries';
const SUP_REVIEWS_COL = 'supervisor_reviews'; // Roteiro/Avaliação Supervisor separado dos KPIs
const FIXED_ASSETS_COL = 'fixed_assets';          // Imobilizados por loja
const CASH_CLOSURES_COL = 'cash_closures';        // Fechos de caixa por loja
const INVENTORY_COUNTS_COL = 'inventory_counts';  // Contagens por data/loja/turno
const STORE_SCHEDULES_COL = 'store_schedules';    // Escalas por loja
const STORE_DOCUMENTS_COL = 'store_documents';    // Documentos por loja
const _safeDocId = (id) => String(id || '').replace(/[\/]/g, '_');
const _clone = (v) => { try { return JSON.parse(JSON.stringify(v)); } catch(e) { return v; } };
const _getPath = (o, parts) => parts.reduce((a,k)=>a && a[k] !== undefined ? a[k] : undefined, o);
function _setPath(o, parts, val){
  let cur=o;
  for(let i=0;i<parts.length-1;i++){ const k=parts[i]; if(!cur[k] || typeof cur[k] !== 'object') cur[k]={}; cur=cur[k]; }
  if(val === null || val === undefined) delete cur[parts[parts.length-1]]; else cur[parts[parts.length-1]]=val;
}
const getDatabase = () => db;
const ref = (_db, path='') => String(path || '');
async function _appGet(path){
  const id = _safeDocId(path);
  const ck = 'karta_cache_app_' + id, tk = ck + '_ts';
  if (KARTA_LOW_COST_MODE) {
    try {
      const ts = +(localStorage.getItem(tk) || 0);
      if (ts && (Date.now() - ts) < APPDATA_CACHE_TTL) {
        const cached = localStorage.getItem(ck);
        if (cached !== null) return JSON.parse(cached);
      }
    } catch(e) {}
  }
  const snap = await getDoc(doc(db, APPDATA_COL, id));
  const val = snap.exists() ? snap.data().value : null;
  try { localStorage.setItem(ck, JSON.stringify(val)); localStorage.setItem(tk, String(Date.now())); } catch(e) {}
  return val;
}
async function _appSet(path, val){
  const id = _safeDocId(path);
  try {
    localStorage.setItem('karta_cache_app_' + id, JSON.stringify(val));
    localStorage.setItem('karta_cache_app_' + id + '_ts', String(Date.now()));
  } catch(e) {}
  const d = doc(db, APPDATA_COL, id);
  if(val === null || val === undefined) return deleteDoc(d);
  return setDoc(d, { value: val, updatedAt: serverTimestamp() }, { merge: false });
}
async function _treeGet(path){
  const parts = String(path || '').split('/').filter(Boolean);
  if(!parts.length) return null;
  const root = parts[0];
  if(root === ENTRIES_COL && parts[1]){
    const snap = await getDoc(doc(db, ENTRIES_COL, _safeDocId(parts[1])));
    return snap.exists() ? snap.data().value : null;
  }
  const rootVal = await _appGet(root);
  return parts.length === 1 ? rootVal : (_getPath(rootVal || {}, parts.slice(1)) ?? null);
}
async function _treeSet(path, val){
  const parts = String(path || '').split('/').filter(Boolean);
  if(!parts.length) return;
  const root = parts[0];
  if(root === ENTRIES_COL && parts[1]){
    const k = parts[1], d = doc(db, ENTRIES_COL, _safeDocId(k));
    if(val === null || val === undefined) return deleteDoc(d);
    return setDoc(d, {
      value: val, key: k,
      loja: k.split('_').slice(0,-1).join('_'),
      data: k.split('_').pop(),
      mes: (k.split('_').pop() || '').substring(0,7),
      updatedAt: serverTimestamp()
    }, { merge: true });
  }
  if(parts.length === 1) return _appSet(root, val);
  const rootVal = (await _appGet(root)) || {};
  const next = _clone(rootVal) || {};
  _setPath(next, parts.slice(1), val);
  return _appSet(root, next);
}
async function set(path, val){ return _treeSet(path, val); }
async function update(path, val){
  if(!path){
    for(const [k,v] of Object.entries(val || {})){
      if(k === ENTRIES_COL && v && typeof v === 'object'){
        let batch = writeBatch(db), n = 0;
        for(const [ek,ev] of Object.entries(v)){
          batch.set(doc(db, ENTRIES_COL, _safeDocId(ek)), {
            value: ev, key: ek,
            loja: ek.split('_').slice(0,-1).join('_'),
            data: ek.split('_').pop(),
            mes: (ek.split('_').pop() || '').substring(0,7),
            updatedAt: serverTimestamp()
          }, { merge:true });
          if(++n % 450 === 0){ await batch.commit(); batch = writeBatch(db); }
        }
        if(n % 450 !== 0) await batch.commit();
      } else await _appSet(k, v);
    }
    return;
  }
  const cur = (await _treeGet(path)) || {};
  return _treeSet(path, Object.assign({}, cur, val || {}));
}
function orderByKey(){ return {type:'orderByKey'}; }
function startAt(v){ return {type:'startAt', value:v}; }
function endAt(v){ return {type:'endAt', value:v}; }
function query(path, _order, st, en){ return {__query:true, path, start:st && st.value, end:en && en.value}; }
async function get(x){
  if(x && x.__query){
    const cacheKey = 'karta_cache_query_' + _safeDocId((x.start || '') + '__' + (x.end || ''));
    if (KARTA_LOW_COST_MODE) {
      try {
        const ts = +(localStorage.getItem(cacheKey + '_ts') || 0);
        const cached = localStorage.getItem(cacheKey);
        if (cached && ts && (Date.now() - ts) < QUERY_CACHE_TTL) {
          const outCached = JSON.parse(cached);
          return { val: () => outCached };
        }
      } catch(e) {}
    }
    const q = fsQuery(collection(db, ENTRIES_COL), where(documentId(), '>=', x.start), where(documentId(), '<=', x.end), orderBy(documentId()));
    const snap = await getDocs(q);
    const out = {};
    snap.forEach(d => { const data = d.data(); out[data.key || d.id] = data.value || {}; });
    try { localStorage.setItem(cacheKey, JSON.stringify(out)); localStorage.setItem(cacheKey + '_ts', String(Date.now())); } catch(e) {}
    return { val: () => out };
  }
  const val = await _treeGet(x);
  return { val: () => val };
}
// LOW COST: compat onValue sem realtime. Faz apenas 1 leitura (getDoc) e devolve o valor.
// Evita milhões de leituras causadas por onSnapshot em appData.
function onValue(path, cb){
  const parts = String(path || '').split('/').filter(Boolean);
  const top = parts[0];
  let cancelled = false;
  (async function(){
    try {
      const rootVal = top ? await _appGet(top) : null;
      if(!cancelled) cb({ val: () => parts.length <= 1 ? rootVal : (_getPath(rootVal || {}, parts.slice(1)) ?? null) });
    } catch(err) { window._KARTA_DEBUG&&console.warn('[Firestore] one-shot read error:', path, err); }
  })();
  return function(){ cancelled = true; };
}
function off(unsub){ try { if(typeof unsub === 'function') unsub(); } catch(e){} }

// ── Supervisor Reviews separados ─────────────────────────────────────────────
// Guardamos cada avaliação em supervisor_reviews/{mes__supervisor__data_loja}
// e reconstruímos SUP_DATA em memória/localStorage para manter relatórios existentes.
function _supReviewDocId(mes, supName, saveKey) {
  return _safeDocId(String(mes || '') + '__' + String(supName || '') + '__' + String(saveKey || ''));
}
function _supReviewDateFromKey(saveKey) {
  var m = String(saveKey || '').match(/^\d{4}-\d{2}-\d{2}/);
  return m ? m[0] : '';
}
function _supReviewMesesRelevantes() {
  var now = new Date();
  var cur = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
  var prevDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  var prev = prevDate.getFullYear() + '-' + String(prevDate.getMonth() + 1).padStart(2, '0');
  return [prev, cur];
}
async function fbLoadSupervisorReviews(meses) {
  meses = meses && meses.length ? meses : _supReviewMesesRelevantes();
  var out = {};
  for (const mes of meses) {
    try {
      var q = fsQuery(
        collection(db, SUP_REVIEWS_COL),
        orderBy(documentId()),
        fsStartAt(mes + '__'),
        fsEndAt(mes + '__\uf8ff')
      );
      var snap = await getDocs(q);
      snap.forEach(function(d) {
        var data = d.data() || {};
        var v = data.value || {};
        var m = data.mes || mes;
        var sup = data.sup || '';
        var key = data.key || '';
        if (!m || !sup || !key) return;
        // Restaurar campos __ que foram convertidos por _firestoreSafeValue ao gravar
        var keyMapReverse = { 'final': '__final__', 'draft': '__draft__', 'centro': '__centro__', 'ts': '__ts__', 'comment': '__comment__', 'rating': '__rating__' };
        var restored = {};
        Object.keys(v).forEach(function(k) {
          if (keyMapReverse[k]) restored[keyMapReverse[k]] = v[k];
          else restored[k] = v[k];
        });
        // Garantir __centro__ a partir do campo loja de topo se necessário
        if (!restored.__centro__ && data.loja) restored.__centro__ = data.loja;
        if (!out[m]) out[m] = {};
        if (!out[m][sup]) out[m][sup] = {};
        out[m][sup][key] = restored;
      });
    } catch(e) {
      window._KARTA_DEBUG&&console.warn('[FB] erro ao carregar supervisor_reviews:', mes, e);
    }
  }
  return out;
}
function _mergeSupData(base, extra) {
  base = (base && typeof base === 'object' && !Array.isArray(base)) ? base : {};
  extra = (extra && typeof extra === 'object' && !Array.isArray(extra)) ? extra : {};
  Object.keys(extra).forEach(function(mes) {
    if (!base[mes] || typeof base[mes] !== 'object') base[mes] = {};
    Object.keys(extra[mes] || {}).forEach(function(sup) {
      if (!base[mes][sup] || typeof base[mes][sup] !== 'object') base[mes][sup] = {};
      Object.keys(extra[mes][sup] || {}).forEach(function(k) {
        var incoming = extra[mes][sup][k];
        var current = base[mes][sup][k];
        if (!current || (incoming && incoming.ts && (!current.ts || incoming.ts >= current.ts))) {
          base[mes][sup][k] = incoming;
        }
      });
    });
  });
  return base;
}
async function fbRefreshSupervisorReviews() {
  // LOW COST: cache de 12h — evita re-ler em cada arranque
  var _ck = 'karta_sup_reviews_ts';
  var _ttl = 12 * 60 * 60 * 1000;
  var _ts = +(localStorage.getItem(_ck) || 0);
  if ((Date.now() - _ts) < _ttl && localStorage.getItem('karta_sup_reviews_cache')) {
    try {
      var _cached = JSON.parse(localStorage.getItem('karta_sup_reviews_cache') || 'null');
      if (_cached) {
        window._SUP_REVIEWS_DATA = _cached;
        window._KARTA_DEBUG&&console.log('[FB] supervisor_reviews: usando cache local (< 2h)');
        return _cached;
      }
    } catch(e) {}
  }
  var reviews = await fbLoadSupervisorReviews();
  var cur = {};
  try { cur = JSON.parse(localStorage.getItem('arreiou_sup_data_v1') || '{}'); } catch(e) {}
  var merged = _mergeSupData(cur, reviews);
  try { localStorage.setItem('arreiou_sup_data_v1', JSON.stringify(merged)); } catch(e) {}
  // Guardar em cache para evitar re-leituras
  try { localStorage.setItem('karta_sup_reviews_cache', JSON.stringify(merged)); localStorage.setItem('karta_sup_reviews_ts', String(Date.now())); } catch(e) {}
  try { window.SUP_DATA = merged; SUP_DATA = merged; } catch(e) { window.SUP_DATA = merged; }
  try { if (document.getElementById('sup-hist-body')) supHistRender(); } catch(e) {}
  try { if (document.getElementById('sup-recent-list')) supRecentRender(); } catch(e) {}
  try {
    var _rdSec=document.getElementById('as-adm-rotdia');
    if(_rdSec && _rdSec.classList.contains('on')) rotDiaRender();
  } catch(e) {}
  return merged;
}


// ── Módulos separados em coleções próprias ───────────────────────────────────
// Evita guardar tudo em appData como documentos gigantes.
async function fbLoadMapCollection(colName) {
  // LOW COST: cache em localStorage por 24h — evita re-ler colecções inteiras a cada arranque
  var _ck  = 'karta_mapcol_' + colName;
  var _tsk = _ck + '_ts';
  var _ttl = 24 * 60 * 60 * 1000; // 24 horas
  try {
    var _ts  = +(localStorage.getItem(_tsk) || 0);
    var _hit = JSON.parse(localStorage.getItem(_ck) || 'null');
    if (_hit && (Date.now() - _ts) < _ttl) return _hit;
  } catch(e) {}
  const snap = await getDocs(collection(db, colName));
  const out = {};
  snap.forEach(function(d) {
    const data = d.data() || {};
    var val = data.value !== undefined ? data.value : data;
    out[data.key || d.id] = _fbDesanitizeKeys(val);
  });
  try { localStorage.setItem(_ck, JSON.stringify(out)); localStorage.setItem(_tsk, String(Date.now())); } catch(e) {}
  return out;
}
// Firestore rejeita campos que começam e terminam com '__'
// Sanitizar antes de escrever, desanitizar ao ler
function _fbSanitizeKeys(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return obj;
  var out = {};
  Object.keys(obj).forEach(function(k) {
    var sk = /^__.*__$/.test(k) ? '_x_' + k.slice(2, -2) + '_x_' : k;
    var v = obj[k];
    out[sk] = (v && typeof v === 'object' && !Array.isArray(v)) ? _fbSanitizeKeys(v) : v;
  });
  return out;
}
function _fbDesanitizeKeys(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return obj;
  var out = {};
  Object.keys(obj).forEach(function(k) {
    var dk = /^_x_.*_x_$/.test(k) ? '__' + k.slice(3, -3) + '__' : k;
    var v = obj[k];
    out[dk] = (v && typeof v === 'object' && !Array.isArray(v)) ? _fbDesanitizeKeys(v) : v;
  });
  return out;
}
async function fbWriteModuleDoc(colName, id, val, extra) {
  const d = doc(db, colName, _safeDocId(id));
  if (val === null || val === undefined) return deleteDoc(d);
  return setDoc(d, Object.assign({
    value: _fbSanitizeKeys(val),
    key: id,
    updatedAt: serverTimestamp()
  }, extra || {}), { merge: true });
}
async function fbWriteFixedAssetStore(code, val) {
  try { localStorage.removeItem('karta_mapcol_' + FIXED_ASSETS_COL); localStorage.removeItem('karta_mapcol_' + FIXED_ASSETS_COL + '_ts'); } catch(e) {}
  return fbWriteModuleDoc(FIXED_ASSETS_COL, code, val || {}, { loja: code });
}
async function fbLoadFixedAssets() { return fbLoadMapCollection(FIXED_ASSETS_COL); }

async function fbWriteCashStore(code, val) {
  try { localStorage.removeItem('karta_mapcol_' + CASH_CLOSURES_COL); localStorage.removeItem('karta_mapcol_' + CASH_CLOSURES_COL + '_ts'); } catch(e) {}
  return fbWriteModuleDoc(CASH_CLOSURES_COL, code, val || [], { loja: code });
}
async function fbLoadCashClosures() { return fbLoadMapCollection(CASH_CLOSURES_COL); }

async function fbWriteStoreSchedule(code, val) {
  try { localStorage.removeItem('karta_mapcol_' + STORE_SCHEDULES_COL); localStorage.removeItem('karta_mapcol_' + STORE_SCHEDULES_COL + '_ts'); } catch(e) {}
  return fbWriteModuleDoc(STORE_SCHEDULES_COL, code, val || {}, { loja: code });
}
async function fbLoadStoreSchedules() { return fbLoadMapCollection(STORE_SCHEDULES_COL); }

async function fbWriteStoreDocuments(code, val) {
  try { localStorage.removeItem('karta_mapcol_' + STORE_DOCUMENTS_COL); localStorage.removeItem('karta_mapcol_' + STORE_DOCUMENTS_COL + '_ts'); } catch(e) {}
  return fbWriteModuleDoc(STORE_DOCUMENTS_COL, code, val || {}, { loja: code });
}
async function fbLoadStoreDocuments() { return fbLoadMapCollection(STORE_DOCUMENTS_COL); }

function _inventoryCountDocId(date, loja, turno) {
  return _safeDocId(String(date || '') + '__' + String(loja || '') + '__' + String(turno || ''));
}
async function fbWriteInventoryCount(date, loja, turno, entry) {
  var id = _inventoryCountDocId(date, loja, turno);
  return fbWriteModuleDoc(INVENTORY_COUNTS_COL, id, entry || {}, {
    data: date,
    loja: loja,
    turno: turno,
    mes: String(date || '').substring(0, 7)
  });
}
// ── Migração única: appData/cont_data → inventory_counts ─────────────────────
async function fbMigrateContData() {
  var migKey = 'karta_cont_migrated_v1';
  if (localStorage.getItem(migKey)) return; // já migrado
  try {
    // Ler dados legados do appData/cont_data
    var legacyVal = await _appGet('cont_data');
    if (!legacyVal || typeof legacyVal !== 'object' || !Object.keys(legacyVal).length) {
      localStorage.setItem(migKey, '1');
      return;
    }
    window._KARTA_DEBUG&&console.log('[CONT] A migrar cont_data para inventory_counts...');
    var count = 0;
    for (var dateKey of Object.keys(legacyVal)) {
      var normDate = /^\d{4}_\d{2}_\d{2}$/.test(dateKey) ? dateKey.replace(/_/g,'-') : dateKey;
      var lojas = legacyVal[dateKey] || {};
      for (var loja of Object.keys(lojas)) {
        var turnos = lojas[loja] || {};
        for (var turno of Object.keys(turnos)) {
          var entry = turnos[turno];
          if (entry && typeof entry === 'object') {
            try {
              await fbWriteInventoryCount(normDate, loja, turno, entry);
              count++;
            } catch(e) { window._KARTA_DEBUG&&console.warn('[CONT] migrate error:', normDate, loja, turno, e); }
          }
        }
      }
    }
    localStorage.setItem(migKey, '1');
    window._KARTA_DEBUG&&console.log('[CONT] Migração concluída:', count, 'entradas');
  } catch(e) {
    window._KARTA_DEBUG&&console.warn('[CONT] fbMigrateContData error:', e);
  }
}
window.fbMigrateContData = fbMigrateContData;

async function fbLoadInventoryCounts() {
  const snap = await getDocs(collection(db, INVENTORY_COUNTS_COL));
  const out = {};
  snap.forEach(function(d) {
    const data = d.data() || {};
    const date = data.data || '';
    const loja = data.loja || '';
    const turno = data.turno || '';
    if (!date || !loja || !turno) return;
    if (!out[date]) out[date] = {};
    if (!out[date][loja]) out[date][loja] = {};
    out[date][loja][turno] = _fbDesanitizeKeys(data.value || {});
  });
  return out;
}
function _mergeNestedByTs(target, incoming) {
  target = target || {};
  incoming = incoming || {};
  Object.keys(incoming).forEach(function(d) {
    if (!target[d]) target[d] = {};
    Object.keys(incoming[d] || {}).forEach(function(l) {
      if (!target[d][l]) target[d][l] = {};
      Object.keys(incoming[d][l] || {}).forEach(function(t) {
        var inc = incoming[d][l][t], cur = target[d][l][t];
        target[d][l][t] = (!cur || (inc && inc.ts && (!cur.ts || inc.ts >= cur.ts))) ? inc : cur;
      });
    });
  });
  return target;
}

window._fbRef     = (path) => String(path || '');
window._fbSet     = (dbRef, val) => set(dbRef, val);
window._fbGet     = (dbRef) => get(dbRef);
window._fbOnValue = (dbRef, cb) => onValue(dbRef, cb);

// ── helpers ──────────────────────────────────────────────────────────────────
const fbRef  = (path) => ref(db, path);
const fbSet  = (path, val) => set(fbRef(path), val);
const fbUpd  = (path, val) => update(fbRef(path), val);
const fbGet  = (path) => get(fbRef(path)).then(s => s.val());
const _fbReadCache = {}; // path -> {ts,val}
const FB_CACHE_TTL = 60 * 60 * 1000; // 60 minutos em modo ultra económico
const fbOn   = (path, cb) => {
  // LOW COST: em Firestore não manter listeners realtime por defeito.
  // Usa cache em memória; se expirar, faz apenas 1 leitura.
  const cache = _fbReadCache[path];
  if (cache && (Date.now() - cache.ts) < FB_CACHE_TTL) {
    setTimeout(function(){ try { cb(cache.val); } catch(e){} }, 0);
    return function(){};
  }
  const r = fbRef(path);
  const unsub = onValue(r, function(s){
    const val = s.val();
    _fbReadCache[path] = { ts: Date.now(), val: val };
    try { cb(val); } catch(e){}
  });
  if (_fbListeners) _fbListeners[path] = unsub;
  return unsub;
};
const fbOff  = (r) => off(r);

// ── KEY MAP: localStorage key → Firebase path ────────────────────────────────
// arrv6            → /entries        (KPI diário por loja/data)
// arreiou_adm_obj_v1 → /adm_obj
// arreiou_escala_v2  → /escalas
// arreiou_sm_form_v1 → /sm_form
// arreiou_sm_cfg_v1  → /sm_cfg
// arreiou_sup_cfg_v1 → /sup_cfg
// arreiou_sup_data_v1→ /sup_data
// arreiou_gerente_v2 → /gerentes
// arreiou_lojaescala_v1 → /lojaescala

const FB_KEY_MAP = {
  'arrv6':                  'entries',
  'arreiou_adm_obj_v1':     'adm_obj',
  'arreiou_escala_v2':      'escalas',
  'arreiou_sm_form_v1':     'sm_form',
  'arreiou_sm_cfg_v1':      'sm_cfg',
  'arreiou_sup_cfg_v1':     'sup_cfg',
  'arreiou_sup_data_v1':    'sup_data',
  'arreiou_sup_draft_v1':   'sup_draft',
  'arreiou_sup_drafts_v2':  'sup_drafts',
  'arreiou_gerente_v2':     'gerentes',
  'arreiou_lojaescala_v1':  'lojaescala',
  'arreiou_frase_kpi_v1':   'frase_kpi',
  'arreiou_tab_cfg_v1':     'tab_cfg',
  'arreiou_excel_pin':      'excel_pin',
  'arreiou_imob_cfg_v1':    'imob_cfg',
  'arreiou_imob_data_v1':   'imob_data',
  'arreiou_caixa_v1':       'caixa',
  'arreiou_limpeza_v1':     'limpeza',
  'arreiou_lembretes_v1':   'lembretes',
  'arreiou_docs_cfg_v1':    'docs_cfg',
  'arreiou_docs_data_v1':   'docs_data',
  'arreiou_lojas_cfg_v1':   'lojas_cfg',
  'arreiou_cont_cfg_v1':    'cont_cfg',
  'arreiou_cont_data_v1':   'cont_data',
};

// ── Persistent listeners registry (to avoid double-subscribe) ───────────────
const _fbListeners = {};

// ── Migration: on first load push localStorage → Firebase (once) ────────────
async function fbMigrateOnce() {
  // LOW COST: migração automática desativada.
  // Motivo: cada browser/dispositivo podia voltar a escrever centenas de milhares de docs.
  localStorage.setItem('arreiou_firestore_migrated_v1', '1');
  return;
}


// ── Unified read: Firebase first, localStorage fallback ─────────────────────
async function fbRead(lsKey) {
  const fbPath = FB_KEY_MAP[lsKey];
  if (!fbPath) return JSON.parse(localStorage.getItem(lsKey) || 'null');
  try {
    const val = await fbGet(fbPath);
    if (val !== null && val !== undefined) return val;
  } catch(e) {}
  try { return JSON.parse(localStorage.getItem(lsKey) || 'null'); } catch(e) { return null; }
}

// ── Unified write: Firebase + localStorage ───────────────────────────────────
const _appWriteTimers = {};
const _appWritePending = {};
async function _fbWriteNow(lsKey, val) {
  const fbPath = FB_KEY_MAP[lsKey];
  if (!fbPath) return true;
  try { await fbSet(fbPath, val); return true; }
  catch(e) {
    window._KARTA_DEBUG&&console.warn('[FB] Write error for', fbPath, e);
    const st = document.getElementById('fb-sync-status');
    if (st) { st.textContent = '⚠ Erro ao gravar no servidor'; st.style.color = 'var(--red)'; setTimeout(()=>{st.textContent='';},8000); }
    return false;
  }
}
async function fbWrite(lsKey, val) {
  const fbPath = FB_KEY_MAP[lsKey];
  try { localStorage.setItem(lsKey, JSON.stringify(val)); } catch(e) {}
  if (!fbPath) return true;
  // Rascunhos do roteiro ficam locais para evitar erros com fotos grandes/base64.
  if (['arreiou_sup_draft_v1','arreiou_sup_drafts_v2'].indexOf(lsKey) >= 0) {
    window._KARTA_DEBUG&&console.warn('[LOW COST] rascunho de roteiro guardado apenas localmente.');
    return true;
  }
  // Nunca gravar árvores inteiras de módulos operacionais; usar coleções separadas/granulares.
  if (['arreiou_imob_data_v1','arreiou_caixa_v1','arreiou_cont_data_v1','arreiou_lojaescala_v1','arreiou_docs_data_v1'].indexOf(lsKey) >= 0) {
    window._KARTA_DEBUG&&console.warn('[LOW COST] gravação completa de '+lsKey+' bloqueada; usar coleção separada.');
    return true;
  }
  // Nunca gravar a árvore inteira de entries em modo normal; usar fbWriteEntry.
  if (lsKey === 'arrv6' && val && typeof val === 'object' && Object.keys(val).length > 50) {
    window._KARTA_DEBUG&&console.warn('[LOW COST] gravação completa de arrv6 bloqueada; usar gravação granular.');
    return true;
  }
  if (!KARTA_LOW_COST_MODE) return _fbWriteNow(lsKey, val);
  _appWritePending[lsKey] = val;
  clearTimeout(_appWriteTimers[lsKey]);
  _appWriteTimers[lsKey] = setTimeout(function(){
    var v = _appWritePending[lsKey]; delete _appWritePending[lsKey];
    _fbWriteNow(lsKey, v);
  }, WRITE_DEBOUNCE_MS);
  return true;
}

// ── Granular entry write (single loja/date key) ───────────────────────────────
// Instead of writing the whole entries object each time, write a single key
const _entryWriteQueue = {};
const _entryWriteHash  = {};
let _entryWriteTimer   = null;
function _hashVal(v){ try { return JSON.stringify(v || null); } catch(e) { return String(v); } }
async function _flushEntryWrites(){
  clearTimeout(_entryWriteTimer); _entryWriteTimer = null;
  const items = Object.entries(_entryWriteQueue);
  Object.keys(_entryWriteQueue).forEach(k => delete _entryWriteQueue[k]);
  if(!items.length) return;
  try {
    let batch = writeBatch(db), n = 0;
    for (const [compositeKey, val] of items) {
      const id = _safeDocId(compositeKey.replace(/[.#$\[\]]/g, '_'));
      const h = _hashVal(val);
      if (_entryWriteHash[compositeKey] === h) continue;
      _entryWriteHash[compositeKey] = h;
      if (val === null || (typeof val === 'object' && Object.keys(val).length === 0)) {
        batch.delete(doc(db, ENTRIES_COL, id));
      } else {
        batch.set(doc(db, ENTRIES_COL, id), {
          value: val, key: compositeKey,
          loja: compositeKey.split('_').slice(0,-1).join('_'),
          data: compositeKey.split('_').pop(),
          mes: (compositeKey.split('_').pop() || '').substring(0,7),
          updatedAt: serverTimestamp()
        }, { merge: true });
      }
      if(++n % 450 === 0){ await batch.commit(); batch = writeBatch(db); }
    }
    if(n % 450 !== 0) await batch.commit();
    // Invalidar caches de query para as lojas/anos afectados pelas escritas
    try {
      var _affectedKeys = new Set();
      items.forEach(function(_item){ var _k=_item[0]; var _parts=_k.split('_'); var _dt=_parts[_parts.length-1]; var _loja=_parts.slice(0,-1).join('_'); var _yr=_dt?_dt.slice(0,4):''; if(_loja&&_yr) _affectedKeys.add(_loja+'|'+_yr); });
      _affectedKeys.forEach(function(_ak){ var _sp=_ak.split('|'); var _l=_sp[0],_y=_sp[1];
        var _ck='fs_entries_'+_l+'_'+_y; localStorage.removeItem(_ck); localStorage.removeItem(_ck+'_ts');
        var _qck='karta_cache_query_'+_l+'_'+_y+'-01-01__'+_l+'_'+_y+'-12-31'; localStorage.removeItem(_qck); localStorage.removeItem(_qck+'_ts');
      });
      // Limpar cache de meses afectados
      var _affectedMes = new Set();
      items.forEach(function(_item){ var _k=_item[0]; var _parts=_k.split('_'); var _dt=_parts[_parts.length-1]; if(_dt&&_dt.length>=7)_affectedMes.add(_dt.substring(0,7)); });
      _affectedMes.forEach(function(_m){ localStorage.removeItem('karta_em_'+_m); localStorage.removeItem('karta_em_'+_m+'_ts'); });
    } catch(_ce) {}
    const st = document.getElementById('fb-sync-status');
    if (st) { st.textContent = '✓ sincronizado'; st.style.color = 'var(--green)'; setTimeout(()=>{st.textContent='';},2500); }
  } catch(e) { window._KARTA_DEBUG&&console.warn('[FB] Entry batch write error:', e); }
}
async function fbWriteEntry(compositeKey, val) {
  try {
    const all = JSON.parse(localStorage.getItem('arrv6') || '{}');
    if (val === null) delete all[compositeKey]; else all[compositeKey] = val;
    localStorage.setItem('arrv6', JSON.stringify(all));
  } catch(e) {}
  if (!KARTA_LOW_COST_MODE) { _entryWriteQueue[compositeKey] = val; return _flushEntryWrites(); }
  _entryWriteQueue[compositeKey] = val;
  clearTimeout(_entryWriteTimer);
  _entryWriteTimer = setTimeout(_flushEntryWrites, WRITE_DEBOUNCE_MS);
  const st = document.getElementById('fb-sync-status');
  if (st) { st.textContent = 'a guardar…'; st.style.color = 'var(--t3)'; }
  return true;
}
window.addEventListener('beforeunload', function(){ try { if(Object.keys(_entryWriteQueue).length) _flushEntryWrites(); } catch(e){} });

// ── Entrada KPI optimizada ──────────────────────────────────────────────────
// ── Listener em tempo real para entries do mês actual ────────────────────────
// Usa onSnapshot apenas no mês corrente — actualizações chegam instantaneamente
// sem re-ler a colecção inteira. Custo: 1 leitura/doc alterado (não por polling).
var _entriesLiveMes = null;
var _entriesLiveUnsub = null;

function fbStartEntriesLive(mes) {
  if (KARTA_LOW_COST_MODE && !KARTA_REALTIME_MODE) { window._KARTA_DEBUG&&console.log('[FB] entries realtime desligado'); return; }
  if (_entriesLiveMes === mes && _entriesLiveUnsub) return; // já activo para este mês
  if (_entriesLiveUnsub) { try { _entriesLiveUnsub(); } catch(e){} }
  _entriesLiveMes = mes;
  try {
    // Listener para os últimos 3 dias — usa campo 'data' para filtrar por data
    var _d = new Date(); _d.setDate(_d.getDate() - 2);
    var _liveStart = _d.toISOString().split('T')[0]; // YYYY-MM-DD
    var liveQ = fsQuery(
      collection(db, ENTRIES_COL),
      where('data', '>=', _liveStart)
    );
    _entriesLiveUnsub = onSnapshot(liveQ, function(snap) {
      snap.docChanges().forEach(function(change) {
        if (change.type === 'removed') return;
        var d = change.doc;
        var dd = d.data();
        var k = dd.key || d.id;
        if (!window.entries || typeof window.entries !== 'object') return;
        window.entries[k] = dd.value || {};
        // Invalidar cache de disco para este mês e loja/ano
        try {
          localStorage.removeItem('karta_em_' + mes);
          localStorage.removeItem('karta_em_' + mes + '_ts');
          var _loja = k.split('_').slice(0,-1).join('_');
          var _yr   = (dd.data || k.split('_').pop() || '').substring(0,4);
          if (_loja && _yr) {
            localStorage.removeItem('fs_entries_' + _loja + '_' + _yr);
            localStorage.removeItem('fs_entries_' + _loja + '_' + _yr + '_ts');
          }
        } catch(e) {}
      });
      // Re-renderizar se o Diário de Lojas estiver visível
      try {
        if (typeof diarioLojasRender === 'function' && document.getElementById('dl-date')) {
          diarioLojasRender();
        }
      } catch(e) {}
      // Re-renderizar KPI Diário se a loja activa for afectada
      try {
        if (window.AS && typeof window.renderTable === 'function') {
          var _affected = false;
          snap.docChanges().forEach(function(c) {
            var _k = c.doc.data().key || c.doc.id;
            if (_k && _k.startsWith(window.AS + '_')) _affected = true;
          });
          if (_affected) window.renderTable();
        }
      } catch(e) {}
    }, function(err) {
      window._KARTA_DEBUG&&console.warn('[FB] entries live listener error:', err);
    });
    window._KARTA_DEBUG&&console.log('[FB] entries live listener activo para:', mes);
  } catch(e) { window._KARTA_DEBUG&&console.warn('[FB] fbStartEntriesLive error:', e); }
}
window.fbStartEntriesLive = fbStartEntriesLive;

// ── Listener em tempo real para Fecho de Caixa ────────────────────────────────
var _cashLiveUnsub = null;
var _cashLiveStartedAt = 0;
function fbStartCashLive() {
  if (KARTA_LOW_COST_MODE && !KARTA_REALTIME_MODE) { window._KARTA_DEBUG&&console.log('[FB] cash realtime desligado'); return; }
  if (_cashLiveUnsub) return; // já activo
  // LOW COST: só arrancar o listener se passaram mais de 30 min desde o último arranque
  // (evita re-subscrever em reloads rápidos)
  var _now = Date.now();
  var _lastCash = +(localStorage.getItem('_karta_cash_live_ts') || 0);
  if ((_now - _lastCash) < 30 * 60 * 1000 && localStorage.getItem('arreiou_caixa_v1')) {
    window._KARTA_DEBUG&&console.log('[FB] cash_closures: usando cache local (< 30min)');
    return;
  }
  try {
    localStorage.setItem('_karta_cash_live_ts', String(_now));
    _cashLiveUnsub = onSnapshot(collection(db, CASH_CLOSURES_COL), function(snap) {
      var updated = [];
      snap.docChanges().forEach(function(change) {
        if (change.type === 'removed') return;
        var d = change.doc;
        var dd = d.data();
        var code = dd.loja || d.id;
        try {
          var caixa = JSON.parse(localStorage.getItem('arreiou_caixa_v1') || '{}');
          var val = dd.value || dd.data || [];
          if (!Array.isArray(val)) val = Object.values(val);
          val.forEach(function(r){ if(r && typeof r.id === 'string') r.id = Number(r.id); });
          caixa[code] = val;
          localStorage.setItem('arreiou_caixa_v1', JSON.stringify(caixa));
          // Invalidar cache da colecção
          localStorage.removeItem('karta_mapcol_' + CASH_CLOSURES_COL);
          localStorage.removeItem('karta_mapcol_' + CASH_CLOSURES_COL + '_ts');
          updated.push(code);
        } catch(e) {}
      });
      updated.forEach(function(code) {
        try { if (window._caixaLoja === code && typeof caixaRenderHistory === 'function') caixaRenderHistory(code); } catch(e) {}
      });
      if (updated.length) {
        try { if (typeof caixaRenderAnaliseAna === 'function') caixaRenderAnaliseAna(); } catch(e) {}
      }
    }, function(err) { window._KARTA_DEBUG&&console.warn('[FB] cash live listener error:', err); });
    window._KARTA_DEBUG&&console.log('[FB] cash_closures live listener activo');
  } catch(e) { window._KARTA_DEBUG&&console.warn('[FB] fbStartCashLive error:', e); }
}
window.fbStartCashLive = fbStartCashLive;

// ── Listener em tempo real para Contagens Diárias ─────────────────────────────
// Os dados estão em Firestore > inventory_counts (gravados por fbWriteInventoryCount)
var _invLiveUnsub = null;
function fbStartInventoryLive() {
  if (KARTA_LOW_COST_MODE && !KARTA_REALTIME_MODE) { window._KARTA_DEBUG&&console.log('[FB] contagens realtime desligado'); return; }
  if (_invLiveUnsub) return; // já activo
  try {
    // Limitar aos últimos 7 dias por documentId (formato: YYYY-MM-DD__LOJA__turno)
    // Não requer índice — usa ordenação natural por ID
    var _d7 = new Date(); _d7.setDate(_d7.getDate() - 1);
    var _invStart = _d7.toISOString().split('T')[0]; // YYYY-MM-DD — ontem e hoje
    var _invQ = fsQuery(
      collection(db, INVENTORY_COUNTS_COL),
      where(documentId(), '>=', _invStart),
      orderBy(documentId())
    );
    _invLiveUnsub = onSnapshot(_invQ, function(snap) {
      if (!window.CONT_DATA || typeof window.CONT_DATA !== 'object') window.CONT_DATA = {};
      snap.docChanges().forEach(function(change) {
        if (change.type === 'removed') return;
        var dd = change.doc.data() || {};
        var date = dd.data || '', loja = dd.loja || '', turno = dd.turno || '';
        if (!date || !loja || !turno) return;
        if (!window.CONT_DATA[date]) window.CONT_DATA[date] = {};
        if (!window.CONT_DATA[date][loja]) window.CONT_DATA[date][loja] = {};
        window.CONT_DATA[date][loja][turno] = _fbDesanitizeKeys(dd.value || {});
        window._KARTA_DEBUG&&console.log('[CONT] live update:', change.type, date, loja, turno);
      });
      // Guardar também no localStorage para persistência entre sessões
      try { localStorage.setItem('arreiou_cont_data_v1', JSON.stringify(window.CONT_DATA)); } catch(e) {}
      // Re-renderizar apenas se secção visível e loja seleccionada
      try {
        var _contEl = document.getElementById('sh-contagens');
        if (_contEl && _contEl.classList.contains('on') && window._contLojaActual) {
          if (typeof contagensRender === 'function') contagensRender();
        }
      } catch(e) {}
      try {
        var _dcfEl = document.getElementById('as-difcontagens');
        if (_dcfEl && _dcfEl.classList.contains('on')) {
          if (typeof _dcfRenderCore === 'function') _dcfRenderCore();
          // Também actualizar Vista Diária do DCG se estiver activa
          var _dcgDia = document.getElementById('dcg-dia');
          if (_dcgDia && _dcgDia.style.display !== 'none' && typeof dcgDiaRender === 'function') dcgDiaRender();
        }
      } catch(e) {}
    }, function(err) { window._KARTA_DEBUG&&console.warn('[FB] inventory_counts listener error:', err); });
    window._KARTA_DEBUG&&console.log('[FB] inventory_counts live listener activo (Firestore)');
  } catch(e) { window._KARTA_DEBUG&&console.warn('[FB] fbStartInventoryLive error:', e); }
}
window.fbStartInventoryLive = fbStartInventoryLive;

// Leitura manual de inventory_counts — chamada pelo botão "↻ Sync Contagens"
window.fbSyncContagens = async function(dias) {
  dias = dias || 30;
  var btn = document.getElementById('dcf-sync-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ A carregar…'; }
  try {
    var _dN = new Date(); _dN.setDate(_dN.getDate() - (dias - 1));
    var _start = _dN.toISOString().split('T')[0];
    var _snap = await getDocs(fsQuery(
      collection(db, INVENTORY_COUNTS_COL),
      where(documentId(), '>=', _start),
      orderBy(documentId())
    ));
    if (!window.CONT_DATA || typeof window.CONT_DATA !== 'object') window.CONT_DATA = {};
    _snap.forEach(function(d) {
      var dd = d.data() || {};
      var date = dd.data || '', loja = dd.loja || '', turno = dd.turno || '';
      if (!date || !loja || !turno) return;
      if (!window.CONT_DATA[date]) window.CONT_DATA[date] = {};
      if (!window.CONT_DATA[date][loja]) window.CONT_DATA[date][loja] = {};
      window.CONT_DATA[date][loja][turno] = _fbDesanitizeKeys(dd.value || {});
    });
    try { localStorage.setItem('arreiou_cont_data_v1', JSON.stringify(window.CONT_DATA)); } catch(e) {}
    if (btn) { btn.disabled = false; btn.textContent = '↻ Sync (' + _snap.size + ' docs)'; }
    // Re-renderizar
    try { if (typeof _dcfRenderCore === 'function') _dcfRenderCore(); } catch(e) {}
    window._KARTA_DEBUG && console.log('[CONT] sync manual: ' + _snap.size + ' docs (' + dias + 'd)');
  } catch(e) {
    if (btn) { btn.disabled = false; btn.textContent = '↻ Sync Contagens'; }
    window._KARTA_DEBUG && console.warn('[CONT] sync manual error:', e.message);
    try { _showToast && _showToast('✗ Erro ao sincronizar contagens: ' + e.message, '#b83232'); } catch(ex) {}
  }
};


// Agora: carrega apenas mês actual + mês anterior, uma vez no arranque.
// Isto reduz drasticamente os GB de download no Firebase.
function _entryMesesRelevantes() {
  var now = new Date();
  var cur = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
  var prevDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  var prev = prevDate.getFullYear() + '-' + String(prevDate.getMonth() + 1).padStart(2, '0');
  return [prev, cur];
}

function _aplicarEntriesNoDB(merged) {
  try {
    Object.keys(merged || {}).forEach(function(k) {
      var parts = k.split('_'); if(parts.length < 2) return;
      var dt = parts[parts.length-1];
      if(!/^\d{4}-\d{2}-\d{2}$/.test(dt)) return;
      var c = parts.slice(0,-1).join('_');
      var ent = merged[k]; if(!ent) return;
      if(ent.vp==null && !ent.h1 && !ent.hu) return;
      if(!window.DB || !window.DB[c]) return;
      var r = window.DB[c].r.find(function(x){return x.d===dt;});
      if(!r){ r={d:dt,vs:null,ru:null,cl:null,tk:null,vp:null,h1:'',hu:'',hl:null,hp:null}; window.DB[c].r.push(r); }
      if(ent.vp!=null)  r.vp = ent.vp;
      if(ent.h1)        r.h1 = ent.h1;
      if(ent.hu)        r.hu = ent.hu;
    });
  } catch(_eE){}
}

async function fbLoadEntriesMonth(mes) {
  var _cacheKey = 'karta_em_' + mes;
  var _cacheTsKey = _cacheKey + '_ts';
  var _isCurMes = (mes === (new Date().toISOString().substring(0,7)));
  // Mês actual: cache 12h; mês passado: cache 14 dias.
  // Como o realtime está desligado por defeito, a app usa cache e só relê em cache miss.
  var _ttl = _isCurMes ? 12*60*60*1000 : 14*24*60*60*1000;
  // 1. Tentar cache localStorage
  try {
    var _ts = +(localStorage.getItem(_cacheTsKey) || 0);
    var _cached = localStorage.getItem(_cacheKey);
    if (_cached && (Date.now() - _ts) < _ttl) {
      var _fromCache = JSON.parse(_cached);
      // Merge com dados do listener (últimos 3 dias, mais recentes)
      if (window.entries) Object.keys(window.entries).forEach(function(k) {
        var _dt = (k.split('_').pop() || '').substring(0,7);
        if (_dt === mes) _fromCache[k] = window.entries[k];
      });
      return _fromCache;
    }
  } catch(e) {}
  // 2. Cache miss → getDocs por campo 'mes' (mais fiável que documentId() range)
  var _out = {};
  try {
    var _q = fsQuery(collection(db, ENTRIES_COL), where('mes', '==', mes));
    var _snap = await getDocs(_q);
    _snap.forEach(function(d) { var _dd = d.data(); _out[_dd.key || d.id] = _dd.value || {}; });
    try { localStorage.setItem(_cacheKey, JSON.stringify(_out)); localStorage.setItem(_cacheTsKey, String(Date.now())); } catch(e) {}
    window._KARTA_DEBUG&&console.log('[FB] fbLoadEntriesMonth getDocs:', mes, Object.keys(_out).length, 'docs');
  } catch(_e) {
    window._KARTA_DEBUG&&console.warn('[FB] fbLoadEntriesMonth error:', _e);
    // Importante para reduzir leituras: não fazer fallback para a colecção inteira.
    // Se existir cache antiga, usa-a mesmo expirada; caso contrário devolve vazio.
    try {
      var _stale = localStorage.getItem(_cacheKey);
      if (_stale) return JSON.parse(_stale);
    } catch(_e2) {}
  }
  return _out;
}

async function fbLoadEntriesForStoreYear(loja, ano) {
  if(!loja || !ano) return {};
  var cacheKey = 'fs_entries_' + loja + '_' + ano;
  var cacheTsKey = cacheKey + '_ts';
  var ttl = QUERY_CACHE_TTL;
  var now = Date.now();
  try {
    var ts = +(localStorage.getItem(cacheTsKey) || 0);
    var cached = JSON.parse(localStorage.getItem(cacheKey) || 'null');
    if(cached && (now - ts) < ttl) {
      // Aplicar cache ao objecto partilhado window.entries (mesmo que 'entries' local)
      if (!window.entries || typeof window.entries !== 'object') window.entries = {};
      Object.keys(cached || {}).forEach(function(k){ window.entries[k] = cached[k]; });
      if (window.AS === loja) { try { window.renderTable(); } catch(_e) {} }
      return cached;
    }
  } catch(e) {}

  // Se o listener do mês actual já tem dados desta loja, usar esses (sem ir ao Firestore)
  var _fsData = {};
  var _lojaPrefix = loja + '_' + ano + '-';
  var _mesCur = new Date().toISOString().substring(0, 7);
  var _isCurrentYear = (String(ano) === String(new Date().getFullYear()));
  if (_isCurrentYear && window.entries && typeof window.entries === 'object') {
    Object.keys(window.entries).forEach(function(k) {
      if (k.startsWith(_lojaPrefix)) _fsData[k] = window.entries[k];
    });
  }
  // Só vai ao Firestore se não tiver dados do listener (ano anterior ou listener ainda não correu)
  if (!Object.keys(_fsData).length) {
    try {
      var _q = fsQuery(
        collection(db, ENTRIES_COL),
        where(documentId(), '>=', loja + '_' + ano + '-01-01'),
        where(documentId(), '<=', loja + '_' + ano + '-12-31'),
        orderBy(documentId())
      );
      var _snap = await getDocs(_q);
      _snap.forEach(function(d) {
        var _dd = d.data();
        _fsData[_dd.key || d.id] = _dd.value || {};
      });
    } catch(_qe) { window._KARTA_DEBUG&&console.warn('[FB] fbLoadEntriesForStoreYear query error:', _qe); }
  }
  var data = _fsData;
  try {
    // Limpar cache de nível 1 (get() customizado) antes de guardar dados frescos
    var _qStart=loja+'_'+ano+'-01-01',_qEnd=loja+'_'+ano+'-12-31';
    var _qck='karta_cache_query_'+_qStart+'__'+_qEnd;
    localStorage.removeItem(_qck); localStorage.removeItem(_qck+'_ts');
    localStorage.setItem(cacheKey, JSON.stringify(data));
    localStorage.setItem(cacheTsKey, String(now));
  } catch(e) {}

  // Merge nos dados vindos do Firestore directamente no objecto partilhado window.entries
  // (que é o mesmo que a variável 'entries' do script de renderização)
  if (!window.entries || typeof window.entries !== 'object') window.entries = {};
  Object.keys(data || {}).forEach(function(k){ window.entries[k] = data[k]; });
  try { localStorage.setItem('arrv6', JSON.stringify(window.entries)); } catch(e) {}
  _aplicarEntriesNoDB(window.entries);
  if (window.AS === loja) { try { window.renderTable(); } catch(e) {} }
  window._KARTA_DEBUG&&console.log('[Firestore LOW COST] entries carregadas:', loja, ano, Object.keys(data).length, 'docs');
  return data;
}

async function fbListenEntries() {
  // LOW COST: não carregar todos os entries no arranque.
  // Os dados KPI são carregados apenas quando uma loja/ano é selecionada.
  if (_fbListeners['entries_loaded_once']) return;
  _fbListeners['entries_loaded_once'] = true;
  try {
    var current = JSON.parse(localStorage.getItem('arrv6') || '{}');
    // Merge no objecto partilhado em vez de substituir (preserva a referência)
    if (!window.entries || typeof window.entries !== 'object') window.entries = {};
    Object.keys(current).forEach(function(k){ window.entries[k] = current[k]; });
    _aplicarEntriesNoDB(window.entries);
  } catch(e) {}
}


// ── Real-time listeners for other data ───────────────────────────────────────
function fbListenAll() {
  // ADM data — carregamento unico
  fbGet('adm_obj').then(function(val) {
    if (!val) return;
    window.ADM_DATA = val;
    try { localStorage.setItem('arreiou_adm_obj_v1', JSON.stringify(val)); } catch(e) {}
  }).catch(function(){});
  // Escalas (templates) — one-shot com cache de 12h
  (function() {
    var _ck = 'arreiou_escala_v2', _tsk = '_karta_escala_ts', _ttl = 12*60*60*1000;
    var _ts = +(localStorage.getItem(_tsk)||0);
    var _hit = localStorage.getItem(_ck);
    if (_hit && (Date.now()-_ts) < _ttl) {
      try { window._escalaMemStore = JSON.parse(_hit); if(window._escalaInited){try{window.escalaRefreshNav();}catch(e){}} } catch(e) {}
      return;
    }
    fbGet('escalas').then(function(val) {
      if (!val) return;
      window._escalaMemStore = val;
      try { localStorage.setItem(_ck, JSON.stringify(val)); localStorage.setItem(_tsk, String(Date.now())); } catch(e) {}
      if (window._escalaInited) { try { window.escalaRefreshNav(); } catch(e) {} }
    }).catch(function(){});
  })();
  // SM form data
  fbOn('sm_form', function(val) {
    if (!val) return;
    // Normalize keys that may have been saved with full name like "A238 — Rua da Coreia"
    var norm = {};
    Object.keys(val).forEach(function(mes){
      norm[mes] = {};
      var lojas = val[mes];
      if(!lojas || typeof lojas !== 'object'){ norm[mes] = lojas; return; }
      Object.keys(lojas).forEach(function(centroKey){
        var code = centroKey;
        if(centroKey.indexOf(' ') !== -1){
          var candidate = centroKey.split(' ')[0].split('—')[0].trim().toUpperCase();
          if(candidate.length >= 4) code = candidate;
        }
        if(!norm[mes][code]) norm[mes][code] = {};
        Object.assign(norm[mes][code], lojas[centroKey]);
      });
    });
    window.FORM_DATA = norm;
    // Keep local FORM_DATA var in sync if it exists
    try {
      Object.keys(norm).forEach(function(k){ FORM_DATA[k] = norm[k]; });
      Object.keys(FORM_DATA).forEach(function(k){ if(!(k in norm)) delete FORM_DATA[k]; });
    } catch(e) {}
    try { localStorage.setItem('arreiou_sm_form_v1', JSON.stringify(norm)); } catch(e) {}
    // Refresh hist tab if open
    try { if(document.getElementById('hist-body')) { FORM_DATA = norm; window.FORM_DATA = norm; histRender(); } } catch(e) {}
    // Refresh KPI table if a store is open
    if (window.AS) { try { window.renderTable(); } catch(e) {} }
  });
  // SM form config — carregamento unico
  fbGet('sm_cfg').then(function(val) {
    if (!val) return;
    try { localStorage.setItem('arreiou_sm_cfg_v1', JSON.stringify(val)); } catch(e) {}
  }).catch(function(){});
  // Sup config
  fbOn('sup_cfg', function(val) {
    if (!val) {
      // Nó vazio no Firebase — tentar fazer upload a partir do localStorage
      try {
        var stored = JSON.parse(localStorage.getItem('arreiou_sup_cfg_v1') || '{\"questions\":[]}');
        if (stored.questions && stored.questions.length && window.fbWrite) {
          fbWrite('arreiou_sup_cfg_v1', stored);
        }
      } catch(e) {}
      return;
    }
    try { localStorage.setItem('arreiou_sup_cfg_v1', JSON.stringify(val)); } catch(e) {}
    // Update in-memory variable safely
    try {
      if (typeof SUP_CFG !== 'undefined') {
        if (!SUP_CFG) SUP_CFG = {};
        SUP_CFG.questions = (val.questions) ? val.questions : (SUP_CFG.questions || []);
      } else {
        window.SUP_CFG = { questions: val.questions || [] };
      }
      // Re-render config list if admin tab is open (debounced)
      if (typeof supCfgRender === 'function') {
        if (window._supCfgDebounce) clearTimeout(window._supCfgDebounce);
        window._supCfgDebounce = setTimeout(function() {
          try { supCfgRender(); } catch(e) {}
        }, 400);
      }
      // Re-render form questions if form is visible
      if (typeof supFormBuildQuestions === 'function') {
        var shell = document.getElementById('sh-sup');
        if (shell && (shell.classList.contains('on') || shell.style.display !== 'none')) {
          try {
            // If a centro is already selected, re-trigger full form rebuild
            var _centroNow = (document.getElementById('sup-form-centro') || {}).value || '';
            if (_centroNow && typeof supFormOnCentro === 'function') {
              supFormOnCentro();
            } else {
              supFormBuildQuestions();
            }
          } catch(e) {}
        }
      }
    } catch(e) {}
  });
  // Sup data
  fbOn('sup_data', function(val) {
    if (!val) return;
    // Sanitizar: Firebase pode devolver null em sub-chaves vazias — substituir por {}
    try {
      if (typeof val === 'object') {
        Object.keys(val).forEach(function(mes) {
          if (!val[mes] || typeof val[mes] !== 'object') { val[mes] = {}; return; }
          Object.keys(val[mes]).forEach(function(sup) {
            if (!val[mes][sup] || typeof val[mes][sup] !== 'object') val[mes][sup] = {};
          });
        });
      }
    } catch(e) {}
    // Fazer MERGE com dados locais em vez de substituir
    // Protege contra Firebase sobrescrever dados recentes gravados localmente
    try {
      var localRaw = localStorage.getItem('arreiou_sup_data_v1');
      var local = localRaw ? JSON.parse(localRaw) : {};
      if (local && typeof local === 'object') {
        Object.keys(local).forEach(function(mes) {
          if (!val[mes] || typeof val[mes] !== 'object') val[mes] = {};
          Object.keys(local[mes] || {}).forEach(function(sup) {
            if (!val[mes][sup] || typeof val[mes][sup] !== 'object') val[mes][sup] = {};
            // Para cada entrada, manter a mais recente (__ts__)
            Object.keys(local[mes][sup] || {}).forEach(function(dt) {
              var localEntry = local[mes][sup][dt];
              var fbEntry = val[mes][sup][dt];
              if (!fbEntry || (localEntry && localEntry.ts && (!fbEntry.ts || localEntry.ts > fbEntry.ts))) {
                val[mes][sup][dt] = localEntry;
              }
            });
          });
        });
      }
    } catch(e) {}
    try { localStorage.setItem('arreiou_sup_data_v1', JSON.stringify(val)); } catch(e) {}
    // Update in-memory variable — always set on window regardless of declaration state
    try { window.SUP_DATA = val; SUP_DATA = val; } catch(e) { try { window.SUP_DATA = val; } catch(e2) {} }
    // Re-render history if tab is open (debounced to prevent flickering)
    if (window._supHistDebounce) clearTimeout(window._supHistDebounce);
    window._supHistDebounce = setTimeout(function() {
      try { if(document.getElementById('sup-hist-body')) supHistRender(); } catch(e) {}
      // supRecentRender handled in debounced block above
    }, 400);
    // Re-render tabs that are currently visible
    try {
      var _rdSec=document.getElementById('as-adm-rotdia');
      if(_rdSec && _rdSec.classList.contains('on')) rotDiaRender();
      else if(document.getElementById('rotdia-body') && document.getElementById('rotdia-body').textContent.indexOf('A carregar') !== -1) rotDiaRender();
    } catch(e) {}
    try { if(document.getElementById('sup-recent-list')) supRecentRender(); } catch(e) {}
    try {
      var _repSec=document.getElementById('as-adm-rep');
      var _repBody=document.getElementById('rep-body');
      // Check if rep is visible either in adm shell or in analises viewport
      var _repVisible = (_repSec && _repSec.offsetParent !== null) ||
                        (_repBody && _repBody.textContent.indexOf('A carregar') !== -1);
      if(_repVisible){
        if(window._repRenderDebounce) clearTimeout(window._repRenderDebounce);
        window._repRenderDebounce=setTimeout(function(){try{repRender._waiting=false;repRender();}catch(e){}},300);
      }
    } catch(e) {}
  });
  // Roteiro/Avaliação Supervisor — coleção nova separada de entries/appData
  fbRefreshSupervisorReviews().catch(function(e){ window._KARTA_DEBUG&&console.warn('[FB] refresh supervisor_reviews error:', e); });
  // Gerentes — one-shot com cache de 2h
  (function() {
    var _ck = 'arreiou_gerente_v2', _tsk = '_karta_gerente_ts', _ttl = 2*60*60*1000;
    var _ts = +(localStorage.getItem(_tsk)||0);
    var _hit = localStorage.getItem(_ck);
    if (_hit && (Date.now()-_ts) < _ttl) {
      try {
        var _v = JSON.parse(_hit);
        if (typeof GERENTE_DATA !== 'undefined') { Object.keys(_v).forEach(function(k){ GERENTE_DATA[k]=_v[k]; }); } else { window.GERENTE_DATA = _v; }
      } catch(e) {}
      return;
    }
    fbGet('gerentes').then(function(val) {
      if (!val) return;
      try { localStorage.setItem(_ck, JSON.stringify(val)); localStorage.setItem(_tsk, String(Date.now())); } catch(e) {}
      if (typeof GERENTE_DATA !== 'undefined') {
        Object.keys(val).forEach(function(k){ GERENTE_DATA[k] = val[k]; });
        Object.keys(GERENTE_DATA).forEach(function(k){ if(!(k in val)) delete GERENTE_DATA[k]; });
      } else { window.GERENTE_DATA = val; }
      try { var sh=document.getElementById('sh-gerrank'); if(sh&&sh.classList.contains('on')) renderGerRanking(); } catch(e) {}
    }).catch(function(){});
  })();
  // Lembretes — carregamento unico
  fbGet('lembretes').then(function(val) {
    if (!val) return;
    var list = Array.isArray(val) ? val : Object.values(val);
    try { localStorage.setItem('arreiou_lembretes_v1', JSON.stringify(list)); } catch(e) {}
    try { if (typeof lembretesRender === 'function' && document.getElementById('lembretes-list')) lembretesRender(); } catch(e) {}
  }).catch(function(){});
  // Escalas por loja — coleção separada store_schedules + fallback legacy
  fbLoadStoreSchedules().then(function(val) {
    if (val && Object.keys(val).length) {
      window._lojaEscalaStore = val;
      try { localStorage.setItem('arreiou_lojaescala_v1', JSON.stringify(val)); } catch(e) {}
      return;
    }
    return fbGet('lojaescala').then(function(oldVal) {
      if (!oldVal) return;
      window._lojaEscalaStore = oldVal;
      try { localStorage.setItem('arreiou_lojaescala_v1', JSON.stringify(oldVal)); } catch(e) {}
    });
  }).catch(function(){});
  // Frases KPI — carregamento unico (nao precisa de tempo real)
  fbGet('frase_kpi').then(function(val) {
    if (!val || !Array.isArray(val)) return;
    try { localStorage.setItem('arreiou_frase_kpi_v1', JSON.stringify(val)); } catch(e) {}
    try { if (document.getElementById('frase-list')) fraseAdmRender(); } catch(e) {}
  }).catch(function(){});
  // Tab config — carregamento unico (nao muda em tempo real)
  fbGet('tab_cfg').then(function(val) {
    if (!val || typeof val !== 'object') return;
    window._TAB_CFG_LIVE = val;
    try { localStorage.setItem('arreiou_tab_cfg_v1', JSON.stringify(val)); } catch(e) {}
    try { tabCfgApply(); } catch(e) {}
    try { tabCfgPatchNav(); } catch(e) {}
  }).catch(function(){});
  // Excel / admin PIN — carregamento unico
  fbGet('excel_pin').then(function(val) {
    if (val === null || val === undefined) return;
    try { localStorage.setItem('arreiou_excel_pin', String(val)); } catch(e) {}
  }).catch(function(){});
  // Imobilizados config — carregamento unico
  fbGet('imob_cfg').then(function(val) {
    if (!val) return;
    try { localStorage.setItem('arreiou_imob_cfg_v1', JSON.stringify(val)); } catch(e) {}
  }).catch(function(){});
  // Imobilizados — coleção separada fixed_assets + fallback legacy
  fbLoadFixedAssets().then(function(val) {
    if (val && Object.keys(val).length) {
      try { localStorage.setItem('arreiou_imob_data_v1', JSON.stringify(val)); } catch(e) {}
      try { if (window._imobLoja && typeof imobRenderMain === 'function') imobRenderMain(window._imobLoja); } catch(e) {}
      return;
    }
    return fbGet('imob_data').then(function(oldVal) {
      if (!oldVal) return;
      try { localStorage.setItem('arreiou_imob_data_v1', JSON.stringify(oldVal)); } catch(e) {}
      try { if (window._imobLoja && typeof imobRenderMain === 'function') imobRenderMain(window._imobLoja); } catch(e) {}
    });
  }).catch(function(){});
  // Fecho de Caixa — gerido pelo listener fbStartCashLive() (arrancado no boot)
  // Fallback legacy: se cache local vazia, tenta ler do Realtime DB antigo
  try {
    var _caixaLocal = JSON.parse(localStorage.getItem('arreiou_caixa_v1') || '{}');
    if (!Object.keys(_caixaLocal).length) {
      fbGet('caixa').then(function(val) {
        if (!val) return;
        Object.keys(val).forEach(function(code){
          if(val[code] && !Array.isArray(val[code])) val[code] = Object.values(val[code]);
          if(Array.isArray(val[code])) val[code].forEach(function(r){ if(r && typeof r.id === 'string') r.id = Number(r.id); });
        });
        try { localStorage.setItem('arreiou_caixa_v1', JSON.stringify(val)); } catch(e) {}
      }).catch(function(){});
    }
  } catch(e) {}
  // Contagens Diarias — config (carregamento unico, nao muda em tempo real)
  fbGet('cont_cfg').then(function(val) {
    if (!val) return;
    window.CONT_CFG = val;
    try { localStorage.setItem('arreiou_cont_cfg_v1', JSON.stringify(val)); } catch(e) {}
    try { if(typeof contAdmRender==='function') contAdmRender(); } catch(e) {}
  }).catch(function(){});
  // Contagens Diárias — carregamento do localStorage no boot.
  // Para sincronizar com Firestore usar o botão ↻ na tab Dif. Contagens (window.dcfSyncFirestore)
  try {
    var _contLocal = JSON.parse(localStorage.getItem('arreiou_cont_data_v1') || '{}');
    if (!window.CONT_DATA) window.CONT_DATA = Object.keys(_contLocal).length ? _contLocal : {};
  } catch(e) { if (!window.CONT_DATA) window.CONT_DATA = {}; }
  if (KARTA_REALTIME_MODE) fbStartInventoryLive();
  try {
    if(document.getElementById('as-adm-cont')&&document.getElementById('as-adm-cont').classList.contains('on')) {
      if(typeof contAdmDataRender==='function') contAdmDataRender();
      if(typeof contMasterRender==='function') contMasterRender();
    }
  } catch(e) {}
  // Documentos por loja — coleção separada store_documents + fallback legacy
  fbLoadStoreDocuments().then(function(val) {
    if (val && Object.keys(val).length) {
      try { localStorage.setItem('arreiou_docs_data_v1', JSON.stringify(val)); } catch(e) {}
      return;
    }
    return fbGet('docs_data').then(function(oldVal) {
      if (!oldVal) return;
      try { localStorage.setItem('arreiou_docs_data_v1', JSON.stringify(oldVal)); } catch(e) {}
    });
  }).catch(function(){});
  // Escala de Limpeza — carregamento unico
  fbGet('limpeza').then(function(val) {
    if (!val) return;
    var list = Array.isArray(val) ? val : Object.values(val);
    try { localStorage.setItem('arreiou_limpeza_v1', JSON.stringify(list)); } catch(e) {}
    try { if (typeof limpezaAdminRender === 'function' && document.getElementById('limpeza-admin-list')) limpezaAdminRender(); } catch(e) {}
  }).catch(function(){});
}


// ── Upload de imagens do Roteiro para Firebase Storage ───────────────────────
// Firestore tem limite de tamanho por documento. Fotos em base64 dentro do doc
// causam erro de sincronização. Por isso, antes de gravar a avaliação,
// enviamos imagens para Storage e guardamos apenas o URL no Firestore.
function _isDataImage(v) {
  return typeof v === 'string' && /^data:image\/(png|jpe?g|webp|gif);base64,/i.test(v);
}
function _imageExtFromDataUrl(v) {
  var m = String(v || '').match(/^data:image\/([^;]+);base64,/i);
  var ext = (m && m[1] ? m[1].toLowerCase() : 'jpg').replace('jpeg','jpg');
  return ['jpg','png','webp','gif'].indexOf(ext) >= 0 ? ext : 'jpg';
}
async function _uploadDataImageAndGetUrl(dataUrl, storagePath) {
  const r = storageRef(storage, storagePath);
  await uploadString(r, dataUrl, 'data_url');
  return getDownloadURL(r);
}
async function _replaceDataImagesWithUrls(obj, basePath, seen) {
  seen = seen || new WeakSet();
  if (_isDataImage(obj)) {
    var ext = _imageExtFromDataUrl(obj);
    return await _uploadDataImageAndGetUrl(obj, basePath + '.' + ext);
  }
  if (!obj || typeof obj !== 'object') return obj;
  if (seen.has(obj)) return obj;
  seen.add(obj);
  if (Array.isArray(obj)) {
    var arr = [];
    for (let i = 0; i < obj.length; i++) {
      arr[i] = await _replaceDataImagesWithUrls(obj[i], basePath + '/' + i, seen);
    }
    return arr;
  }
  var out = {};
  for (const k of Object.keys(obj)) {
    out[k] = await _replaceDataImagesWithUrls(obj[k], basePath + '/' + _safeDocId(k), seen);
  }
  return out;
}

async function _replaceDataImagesWithUrlsSafe(obj, basePath, seen) {
  // Igual ao uploader normal, mas se o Storage falhar não bloqueia a avaliação.
  // Grava a avaliação sem a imagem e inclui erro técnico para diagnóstico.
  seen = seen || new WeakSet();
  if (_isDataImage(obj)) {
    try {
      var ext = _imageExtFromDataUrl(obj);
      return await _uploadDataImageAndGetUrl(obj, basePath + '.' + ext);
    } catch(e) {
      return {
        __photo_upload_failed__: true,
        code: (e && e.code) ? e.code : '',
        message: (e && e.message) ? String(e.message).slice(0, 180) : 'upload failed',
        size: String(obj || '').length
      };
    }
  }
  if (!obj || typeof obj !== 'object') return obj;
  if (seen.has(obj)) return obj;
  seen.add(obj);
  if (Array.isArray(obj)) {
    var arr = [];
    for (let i = 0; i < obj.length; i++) {
      arr[i] = await _replaceDataImagesWithUrlsSafe(obj[i], basePath + '/' + i, seen);
    }
    return arr;
  }
  var out = {};
  for (const k of Object.keys(obj)) {
    out[k] = await _replaceDataImagesWithUrlsSafe(obj[k], basePath + '/' + _safeDocId(k), seen);
  }
  return out;
}

function _stripDataImagesForFirestore(obj, seen) {
  // Modo emergência: não envia fotos para Firestore/Storage.
  // Evita falhas por regras/Storage/tamanho de documento. As fotos continuam no rascunho local.
  seen = seen || new WeakSet();
  if (_isDataImage(obj)) {
    return {
      __photo_local_only__: true,
      note: 'Foto guardada apenas localmente neste dispositivo; não sincronizada.',
      size: String(obj || '').length
    };
  }
  if (!obj || typeof obj !== 'object') return obj;
  if (seen.has(obj)) return null;
  seen.add(obj);
  if (Array.isArray(obj)) return obj.map(function(v){ return _stripDataImagesForFirestore(v, seen); });
  var out = {};
  Object.keys(obj).forEach(function(k){
    out[k] = _stripDataImagesForFirestore(obj[k], seen);
  });
  return out;
}


function _firestoreSafeValue(obj, seen) {
  // Firestore não aceita campos com nomes do tipo __campo__.
  // Convertemos chaves internas para nomes normais antes de gravar.
  var keyMap = {
    '__final__': 'final',
    '__draft__': 'draft',
    '__centro__': 'centro',
    '__ts__': 'ts',
    '__comment__': 'comment',
    '__rating__': 'rating',
    '__photo_local_only__': 'photo_local_only',
    '__photo_upload_failed__': 'photo_upload_failed'
  };
  seen = seen || new WeakSet();
  if (!obj || typeof obj !== 'object') return obj;
  if (seen.has(obj)) return null;
  seen.add(obj);
  if (Array.isArray(obj)) return obj.map(function(v){ return _firestoreSafeValue(v, seen); });
  var out = {};
  Object.keys(obj).forEach(function(k){
    var nk = keyMap[k] || String(k).replace(/^__+/, '').replace(/__+$/, '') || 'field';
    out[nk] = _firestoreSafeValue(obj[k], seen);
  });
  return out;
}

// ── Granular supervisor review write ─────────────────────────────────────────
// Guarda o roteiro/avaliação numa coleção própria:
//   supervisor_reviews/{mes__supervisor__data_loja}
// Isto separa o roteiro dos KPIs diários em entries e evita misturar dados.
async function fbWriteSupEntry(mes, supName, saveKey, val) {
  // Invalidar cache de supervisor reviews ao gravar
  try { localStorage.removeItem('karta_sup_reviews_cache'); localStorage.removeItem('karta_sup_reviews_ts'); } catch(e) {}
  var docId = _supReviewDocId(mes, supName, saveKey);
  try {
    var d = doc(db, SUP_REVIEWS_COL, docId);
    var cleanVal = val;

    if (val === null || val === undefined) {
      await deleteDoc(d);
    } else {
      // Enviar fotos para Storage e guardar URLs no Firestore.
      // Se uma foto falhar, a avaliação não bloqueia: guarda um marcador de erro dessa foto.
      cleanVal = await _replaceDataImagesWithUrlsSafe(
        val,
        'supervisor_reviews/' + _safeDocId(mes) + '/' + _safeDocId(supName) + '/' + _safeDocId(saveKey)
      );
      var fsVal = _firestoreSafeValue(cleanVal);

      await setDoc(d, {
        value: fsVal,
        mes: mes,
        sup: supName,
        key: saveKey,
        data: _supReviewDateFromKey(saveKey),
        loja: (cleanVal && cleanVal.__centro__) ? cleanVal.__centro__ : (fsVal && fsVal.centro ? fsVal.centro : ''),
        final: (cleanVal && cleanVal.__final__ != null) ? cleanVal.__final__ : (fsVal && fsVal.final != null ? fsVal.final : null),
        isDraft: !!((cleanVal && cleanVal.__draft__) || (fsVal && fsVal.draft)),
        updatedAt: serverTimestamp()
      }, { merge: true });
    }

    // Compatibilidade local: mantém SUP_DATA para relatórios/ranking já existentes
    try {
      var cur = JSON.parse(localStorage.getItem('arreiou_sup_data_v1') || '{}');
      if (!cur[mes]) cur[mes] = {};
      if (!cur[mes][supName]) cur[mes][supName] = {};
      if (val === null || val === undefined) delete cur[mes][supName][saveKey];
      else cur[mes][supName][saveKey] = cleanVal;
      localStorage.setItem('arreiou_sup_data_v1', JSON.stringify(cur));
      window.SUP_DATA = cur; try { SUP_DATA = cur; } catch(e) {}
    } catch(e) {}

    return true;
  } catch(e) {
    window._KARTA_DEBUG&&console.warn('[FB] supervisor_reviews write error:', docId, e);
    try { window._lastSupSyncError = (e && e.code ? e.code : '') + ' ' + (e && e.message ? String(e.message).slice(0,120) : ''); } catch(_ee) {}
    try {
      var st = document.getElementById('fb-sync-status');
      if (st) { st.textContent = '⚠ Erro ao sincronizar roteiro: ' + (e && e.code ? e.code : ''); st.style.color = 'var(--red)'; }
    } catch(_e) {}
    return false;
  }
}

// ── Expose to window ─────────────────────────────────────────────────────────
window.fbWrite         = fbWrite;
window.fbRead          = fbRead;
window.fbGet           = fbGet;
window.fbWriteEntry    = fbWriteEntry;
window.fbWriteSupEntry = fbWriteSupEntry;
window.fbRefreshSupervisorReviews = fbRefreshSupervisorReviews;
window.fbWriteFixedAssetStore = fbWriteFixedAssetStore;
window.fbWriteCashStore = fbWriteCashStore;
window.fbLoadCashClosures = fbLoadCashClosures;
window.fbRefreshCashClosures = async function(){
  try {
    localStorage.removeItem('karta_mapcol_' + CASH_CLOSURES_COL);
    localStorage.removeItem('karta_mapcol_' + CASH_CLOSURES_COL + '_ts');
  } catch(e) {}
  return fbLoadCashClosures();
};
window.fbLoadInventoryCounts = fbLoadInventoryCounts;
window.fbWriteInventoryCount = fbWriteInventoryCount;
window.fbWriteStoreSchedule = fbWriteStoreSchedule;
window.fbWriteStoreDocuments = fbWriteStoreDocuments;
window.fbListenEntries = fbListenEntries;
window.fbLoadEntriesForStoreYear = fbLoadEntriesForStoreYear;
window.fbLoadEntriesMonth      = fbLoadEntriesMonth;
window.fbOn         = fbOn;
window.fbSet        = fbSet;
window.backupExport     = backupExport;
window.backupMsg        = function(m,c){ if(window._backupMsg) window._backupMsg(m,c); };
window.backupImport     = backupImport;
window._mod_backupExport = backupExport;
window._mod_backupImport = backupImport;

// ── Cache bust — limpa caches ao mudar de versão do deploy ───────────────────
(function() {
  // Versão ligada ao app-version do meta tag — muda automaticamente com cada deploy
  var _metaVer = (document.querySelector('meta[name="app-version"]') || {}).content || '8';
  var KARTA_CACHE_VER = 'v' + _metaVer;
  var stored = localStorage.getItem('karta_cache_ver');
  if (stored !== KARTA_CACHE_VER) {
    // Limpar TODOS os caches de dados: entries, colecções, supervisor, escalas, gerentes
    var toRemove = [];
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (!k) continue;
      if (
        k.startsWith('karta_cache_query_') ||
        k.startsWith('fs_entries_') ||
        k.startsWith('karta_em_') ||
        k.startsWith('karta_mapcol_') ||       // fixed_assets, cash_closures, store_schedules, store_documents
        k.startsWith('karta_sup_reviews') ||   // supervisor reviews cache
        k === '_karta_escala_ts' ||            // escalas TTL
        k === '_karta_gerente_ts' ||           // gerentes TTL
        k === '_karta_cash_live_ts' ||         // cash live listener TTL
        k.endsWith('_ts')
      ) {
        toRemove.push(k);
      }
    }
    toRemove.forEach(function(k) { localStorage.removeItem(k); });
    localStorage.setItem('karta_cache_ver', KARTA_CACHE_VER);
    window._KARTA_DEBUG&&console.log('[Karta] Cache limpa (deploy ' + KARTA_CACHE_VER + '), ' + toRemove.length + ' entradas removidas');
    console.log('[Karta] Novo deploy detectado — cache limpo (' + toRemove.length + ' entradas)');
  }
})();

// ── Boot sequence ─────────────────────────────────────────────────────────────
window.addEventListener('load', async function() {
  try {
    await fbMigrateOnce();
    fbListenEntries();
    fbListenAll();
    // Listeners em tempo real desligados por defeito para reduzir leituras Firebase.
    // Activação manual de emergência: localStorage.setItem('karta_realtime','1') e recarregar.
    if (KARTA_REALTIME_MODE) {
      var _LISTENER_DELAY = 10 * 60 * 1000; // 10 minutos
      var _listenersTimer = setTimeout(function() {
        if (document.hidden) {
          window._KARTA_DEBUG&&console.log('[FB] Tab escondido — listeners adiados');
          var _onVis = function() {
            if (!document.hidden) {
              document.removeEventListener('visibilitychange', _onVis);
              fbStartCashLive();
              fbStartInventoryLive();
              var _mesCur = new Date().toISOString().substring(0, 7);
              fbStartEntriesLive(_mesCur);
              window._KARTA_DEBUG&&console.log('[FB] Listeners activados ao ficar visível');
            }
          };
          document.addEventListener('visibilitychange', _onVis);
          return;
        }
        fbStartCashLive();
        fbStartInventoryLive();
        var _mesCur = new Date().toISOString().substring(0, 7);
        fbStartEntriesLive(_mesCur);
        window._KARTA_DEBUG&&console.log('[FB] Listeners em tempo real activados');
      }, _LISTENER_DELAY);
      window.addEventListener('beforeunload', function() { clearTimeout(_listenersTimer); });
    } else {
      window._KARTA_DEBUG&&console.log('[FB] Realtime OFF: modo menos leituras activo');
    }
    // Migração desactivada — inventory_counts só guarda dados novos (a partir de agora)
    // Notificações SM realtime
    // LOW COST: notificações SM realtime desativadas no arranque.
    // Ativar manualmente só se necessário: smNotifyListen();
    window._KARTA_DEBUG&&console.log('[Firestore LOW COST] activo: KPI por loja/ano, appData one-shot/cache');
  } catch(e) {
    window._KARTA_DEBUG&&console.warn('[FB] Boot error (offline mode):', e);
  }
});
