
// ── Scroll horizontal com roda do rato em todos os menus de tabs ─────────────
(function(){
  function enableHWheelScroll(el) {
    if (!el) return;
    el.addEventListener('wheel', function(e) {
      // Se o elemento tem overflow horizontal e o utilizador está a fazer scroll vertical
      var hasHScroll = el.scrollWidth > el.clientWidth;
      if (!hasHScroll) return;
      // Prevenir o scroll da página e redirecionar para scroll horizontal
      if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
        e.preventDefault();
        el.scrollLeft += e.deltaY * 1.5;
      }
    }, { passive: false });
  }

  function initTabScrolls() {
    // Aplicar a todos os elementos .stabs e #adm-stabs
    document.querySelectorAll('.stabs, #adm-stabs, .tnav').forEach(enableHWheelScroll);
  }

  // Inicializar depois do DOM carregar
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTabScrolls);
  } else {
    initTabScrolls();
  }

  // Re-aplicar após mudanças de vista (caso stabs sejam recriadas)
  var _origSwitchView = window.switchAdmTab || null;
  document.addEventListener('click', function(e) {
    var stabs = e.target.closest('.stabs, #adm-stabs');
    if (stabs) enableHWheelScroll(stabs);
  }, true);
})();
