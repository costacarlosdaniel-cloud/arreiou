
// Toggle colapsar/expandir roteiro no relatório
function repToggle(hdr, cardId) {
  var body = document.getElementById(cardId);
  var chev = hdr.querySelector('.rep-chev');
  if (!body) return;
  var open = body.style.display !== 'none';
  body.style.display = open ? 'none' : '';
  if (chev) chev.style.transform = open ? '' : 'rotate(-180deg)';
}

// Wrappers para botões da aba Admin — aguardam o módulo ES carregar
function _callModuleFn(name, fallback) {
  var fn = window['_mod_'+name];
  if (typeof fn === 'function') { fn(); return; }
  // Tentar via window directo (exposto pelo módulo)
  fn = window[name];
  if (typeof fn === 'function' && fn.toString().indexOf('_callModuleFn') === -1) { fn(); return; }
  if (typeof fallback === 'function') fallback();
}
function backupExport() {
  // Exportador autónomo e seguro: não chama window._mod_backupExport
  // para evitar recursão / Maximum call stack size exceeded.
  return new Promise(function(resolve, reject){
    try {
      function readJson(key, fallback) {
        try { var raw = localStorage.getItem(key); if (raw) return JSON.parse(raw); } catch(e) {}
        try { return JSON.parse(fallback || 'null'); } catch(e2) { return {}; }
      }
      function makeCircularReplacer() {
        var seen = [];
        return function(key, value) {
          if (typeof value === 'function') return undefined;
          if (value && typeof value === 'object') {
            if (seen.indexOf(value) !== -1) return undefined;
            seen.push(value);
          }
          return value;
        };
      }
      function safeClone(obj, fallback) {
        if (obj === null || obj === undefined) return fallback;
        try { return JSON.parse(JSON.stringify(obj, makeCircularReplacer())); } catch(e) { return fallback; }
      }

      var data = {
        version:    4,
        exported:   new Date().toISOString(),
        source:     'karta-firestore-safe-export',
        adm_data:   readJson('arreiou_adm_obj_v1',  '{}'),
        form_data:  readJson('arreiou_sm_form_v1',  '{}'),
        form_cfg:   readJson('arreiou_sm_cfg_v1',   '{"fields":[]}'),
        sup_cfg:    readJson('arreiou_sup_cfg_v1',  '{"questions":[]}'),
        sup_data:   readJson('arreiou_sup_data_v1', '{}'),
        gerente:    readJson('arreiou_gerente_v2',  '{}'),
        caixa:      readJson('arreiou_caixa_v1',    '{}'),
        lojas_cfg:  readJson('arreiou_lojas_cfg_v1','{}'),
        cont_cfg:   readJson('arreiou_cont_cfg_v1', '{}'),
        cont_data:  readJson('arreiou_cont_data_v1','{}'),
        imob_cfg:   readJson('arreiou_imob_cfg_v1', '{}'),
        imob_data:  readJson('arreiou_imob_data_v1','{}'),
        docs_cfg:   readJson('arreiou_docs_cfg_v1', '{}'),
        docs_data:  readJson('arreiou_docs_data_v1','{}'),
        entries:    safeClone(window.entries, null) || readJson('arrv6','{}'),
        escalas:    safeClone(window._escalaMemStore, null) || readJson('arreiou_escala_v2', '{"templates":[]}'),
        lojaescala: safeClone(window._lojaEscalaStore, null) || readJson('arreiou_lojaescala_v1', '{}')
      };

      var json = JSON.stringify(data, makeCircularReplacer(), 2);
      var filename = 'KPI_Arreiou_backup_' + new Date().toISOString().slice(0,10) + '.json';
      var blob = new Blob([json], {type:'application/json;charset=utf-8'});
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url; a.download = filename; a.style.display = 'none';
      document.body.appendChild(a); a.click();
      setTimeout(function(){ try { document.body.removeChild(a); } catch(e) {} try { URL.revokeObjectURL(url); } catch(e) {} }, 500);
      var bm = window.backupMsg || window._mod_backupMsg;
      if (typeof bm === 'function') { try { bm('✓ Backup exportado — ' + filename, 'green'); } catch(e) {} }
      resolve(true);
    } catch(e) {
      _showToast('✗ Erro ao exportar: ' + e.message, '#b83232');
      console.error('[backupExport safe]', e);
      reject(e);
    }
  });
}

function backupImport() {
  var fn = window['_mod_backupImport'];
  if (typeof fn === 'function') { fn(); return; }
  // Usar o input estático no HTML (label for="backup-import-file")
  // O click programático é bloqueado por browsers modernos — o <label> resolve isso.
  var inp = document.getElementById('backup-import-file');
  if (inp) { inp.click(); return; }
  _showToast('✗ Input de ficheiro não encontrado.', '#b83232');
}

function backupImportFile(inp) {
  var file = inp && inp.files && inp.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function(ev) {
    try {
      var data = JSON.parse(ev.target.result);
      // Mapeamento completo: chave JSON → chave localStorage
      var keys = {
        adm_data:   'arreiou_adm_obj_v1',
        form_data:  'arreiou_sm_form_v1',
        form_cfg:   'arreiou_sm_cfg_v1',
        sup_cfg:    'arreiou_sup_cfg_v1',
        sup_data:   'arreiou_sup_data_v1',
        gerente:    'arreiou_gerente_v2',
        caixa:      'arreiou_caixa_v1',
        lojas_cfg:  'arreiou_lojas_cfg_v1',
        entries:    'arrv6',
        cont_cfg:   'arreiou_cont_cfg_v1',
        cont_data:  'arreiou_cont_data_v1',
        imob_cfg:   'arreiou_imob_cfg_v1',
        imob_data:  'arreiou_imob_data_v1',
        docs_cfg:   'arreiou_docs_cfg_v1',
        docs_data:  'arreiou_docs_data_v1',
        escalas:    'arreiou_escala_v2',
        lojaescala: 'arreiou_lojaescala_v1',
      };
      var n = 0, skipped = 0;
      Object.keys(keys).forEach(function(k) {
        if (data[k] !== undefined) {
          try { localStorage.setItem(keys[k], JSON.stringify(data[k])); n++; } catch(e) { skipped++; }
        }
      });
      var msg = '✓ Importado: ' + n + ' secções.';
      if (skipped > 0) msg += ' ' + skipped + ' falharam (localStorage cheio?).';
      msg += ' Recarregue a página.';
      _showToast(msg, '#1a7040');
      try { inp.value = ''; } catch(e) {}
    } catch(e) {
      _showToast('✗ Ficheiro inválido: ' + e.message, '#b83232');
    }
  };
  reader.readAsText(file);
}
window.backupImportFile = backupImportFile;

function _lsGet(key, fallback) {
  try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : JSON.parse(fallback); } catch(e) { return JSON.parse(fallback||'null'); }
}

function _showToast(msg, bg) {
  var t = document.createElement('div');
  t.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:99999;background:'+(bg||'#1a7040')+';color:#fff;padding:10px 18px;border-radius:8px;font-size:12px;font-family:system-ui,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.2);max-width:360px';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(function(){ t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(function(){ if(t.parentNode) t.parentNode.removeChild(t); },300); }, 5000);
}
function headerExportJson() {
  var overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99998;display:flex;align-items:center;justify-content:center';

  var box = document.createElement('div');
  box.style.cssText = 'background:var(--w,#fff);border-radius:12px;padding:28px 32px;width:320px;max-width:92vw;box-shadow:0 16px 48px rgba(0,0,0,.28);font-family:system-ui,sans-serif';
  box.innerHTML = ''
    + '<div style="font-size:16px;font-weight:700;color:var(--tx,#111);margin-bottom:6px">🔒 Exportar JSON</div>'
    + '<div style="font-size:12px;color:var(--t2,#666);margin-bottom:18px">Introduza o PIN de Administrador para continuar.</div>'
    + '<input id="hexp-pin" type="password" placeholder="PIN" maxlength="20"'
    + ' style="width:100%;box-sizing:border-box;font-size:15px;padding:9px 12px;border:1px solid var(--bd,#ddd);border-radius:7px;background:var(--bg,#fff);color:var(--tx,#111);margin-bottom:6px;letter-spacing:4px">'
    + '<div id="hexp-err" style="font-size:11px;color:#b83232;min-height:16px;margin-bottom:12px"></div>'
    + '<div style="display:flex;gap:8px">'
    + '<button id="hexp-cancel" style="flex:1;padding:9px;border:1px solid #ddd;border-radius:7px;background:var(--bg,#fff);color:var(--t2,#666);font-size:13px;cursor:pointer">Cancelar</button>'
    + '<button id="hexp-ok" style="flex:1;padding:9px;border:none;border-radius:7px;background:#1a7040;color:#fff;font-size:13px;font-weight:600;cursor:pointer">Exportar</button>'
    + '</div>';

  overlay.appendChild(box);
  document.body.appendChild(overlay);

  var pinInp = box.querySelector('#hexp-pin');
  var errEl  = box.querySelector('#hexp-err');
  setTimeout(function(){ pinInp.focus(); }, 50);

  function doClose() { if(overlay.parentNode) overlay.parentNode.removeChild(overlay); }

  function doConfirm() {
    if (!_checkAdminPin(pinInp.value)) {
      errEl.textContent = _getAdminPin() === null ? 'PIN não configurado nas definições.' : 'PIN incorrecto.';
      pinInp.style.borderColor = '#b83232';
      pinInp.select();
      return;
    }
    doClose();
    // Mostrar toast a indicar que está a exportar
    var toast = document.createElement('div');
    toast.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:99999;background:#8a6000;color:#fff;padding:10px 18px;border-radius:8px;font-size:12px;font-family:system-ui,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.2)';
    toast.textContent = '⏳ A preparar exportação...';
    document.body.appendChild(toast);

    function tryExport(attempts) {
      var fn = window.backupExport;
      if (typeof fn === 'function') {
        try {
          Promise.resolve(fn()).then(function() {
            toast.style.background = '#1a7040';
            toast.textContent = '✓ JSON exportado com sucesso';
            setTimeout(function(){ if(toast.parentNode) toast.parentNode.removeChild(toast); }, 4000);
          }).catch(function(e) {
            toast.style.background = '#b83232';
            toast.textContent = '✗ Erro: ' + (e && e.message || e);
            setTimeout(function(){ if(toast.parentNode) toast.parentNode.removeChild(toast); }, 6000);
          });
        } catch(e) {
          toast.style.background = '#b83232';
          toast.textContent = '✗ Erro: ' + (e && e.message || e);
          setTimeout(function(){ if(toast.parentNode) toast.parentNode.removeChild(toast); }, 6000);
        }
      } else if (attempts > 0) {
        toast.textContent = '⏳ A aguardar Firebase... (' + (11 - attempts) + '/10)';
        setTimeout(function(){ tryExport(attempts - 1); }, 500);
      } else {
        // Fallback: exportar directamente do localStorage
        toast.textContent = '⏳ A exportar do localStorage...';
        var ok = exportFromLocalStorage();
        toast.style.background = ok ? '#1a7040' : '#b83232';
        toast.textContent = ok ? '✓ JSON exportado (localStorage)' : '✗ Erro ao exportar';
        setTimeout(function(){ if(toast.parentNode) toast.parentNode.removeChild(toast); }, 4000);
      }
    }
    tryExport(10);
  }

  // Fallback: exportar directamente do localStorage (não precisa do módulo ES)
  function exportFromLocalStorage() {
    try {
      var data = {
        version:    3,
        exported:   new Date().toISOString(),
        adm_data:   JSON.parse(localStorage.getItem('arreiou_adm_obj_v1')  || '{}'),
        form_data:  JSON.parse(localStorage.getItem('arreiou_sm_form_v1')  || '{}'),
        form_cfg:   JSON.parse(localStorage.getItem('arreiou_sm_cfg_v1')   || '{"fields":[]}'),
        sup_cfg:    JSON.parse(localStorage.getItem('arreiou_sup_cfg_v1')  || '{"questions":[]}'),
        sup_data:   JSON.parse(localStorage.getItem('arreiou_sup_data_v1') || '{}'),
        gerente:    JSON.parse(localStorage.getItem('arreiou_gerente_v2')  || '{}'),
        caixa:      JSON.parse(localStorage.getItem('arreiou_caixa_v1')    || '{}'),
        lojas_cfg:  JSON.parse(localStorage.getItem('arreiou_lojas_cfg_v1')|| '{}'),
        entries:    JSON.parse(localStorage.getItem('arrv6')               || '{}'),
      };
      var json     = JSON.stringify(data, null, 2);
      var date     = new Date().toISOString().slice(0,10);
      var filename = 'KPI_Arreiou_backup_' + date + '.json';
      var blob = new Blob([json], {type: 'application/json'});
      var url  = URL.createObjectURL(blob);
      var a    = document.createElement('a');
      a.href = url; a.download = filename; a.style.display = 'none';
      document.body.appendChild(a); a.click();
      setTimeout(function(){ document.body.removeChild(a); URL.revokeObjectURL(url); }, 500);
      return true;
    } catch(e) { console.error('[JSON export LS]', e); return false; }
  }

  box.querySelector('#hexp-ok').addEventListener('click', doConfirm);
  box.querySelector('#hexp-cancel').addEventListener('click', doClose);
  overlay.addEventListener('click', function(ev){ if(ev.target === overlay) doClose(); });
  pinInp.addEventListener('keydown', function(ev){
    if(ev.key === 'Enter') doConfirm();
    if(ev.key === 'Escape') doClose();
  });
  return false;
}

// Exposição explícita para onclick inline e fallback por addEventListener.
// Corrige casos em que o browser/PWA não encontra a função global no clique.
window.backupExport = backupExport;
window.backupImport = backupImport;
window.headerExportJson = headerExportJson;

(function bindExportJsonButton(){
  function bind(){
    var btn = document.getElementById('btn-export-json');
    if (!btn || btn.__kartaExportBound) return;
    btn.__kartaExportBound = true;
    btn.addEventListener('click', function(ev){
      ev.preventDefault();
      ev.stopPropagation();
      if (typeof window.headerExportJson === 'function') window.headerExportJson(ev);
      return false;
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind);
  else bind();
  window.addEventListener('load', bind);
})();
