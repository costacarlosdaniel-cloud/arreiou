
// ═══════════════════════════════════════════════════════════════════
// KARTA LOGIN SYSTEM
// ═══════════════════════════════════════════════════════════════════
(function(){
  var LS_PIN     = 'karta_login_pin';
  var LS_ENABLED = 'karta_login_enabled';
  var LS_SESSION = 'karta_login_session';

  var _buf = [];   // dígitos inseridos
  var _maxLen = 0; // comprimento do PIN guardado

  function getPin(){ try{ return localStorage.getItem(LS_PIN)||''; }catch(e){ return ''; } }
  function isEnabled(){ try{ return localStorage.getItem(LS_ENABLED)==='1'; }catch(e){ return false; } }
  function hasSession(){ try{ return sessionStorage.getItem(LS_SESSION)==='1'; }catch(e){ return false; } }
  function setSession(){ try{ sessionStorage.setItem(LS_SESSION,'1'); }catch(e){} }

  // ── Render numpad ──────────────────────────────────────────────
  function buildNumpad(){
    var np = document.getElementById('kl-numpad');
    if(!np) return;
    np.innerHTML='';
    var keys=['1','2','3','4','5','6','7','8','9','','0','⌫'];
    keys.forEach(function(k){
      var btn=document.createElement('button');
      btn.className='kl-key'+(k===''?' empty':k==='⌫'?' del':'');
      btn.textContent=k;
      if(k==='⌫') btn.onclick=function(){ _buf.pop(); renderDots(); };
      else if(k!=='') btn.onclick=function(){ pressKey(k); };
      np.appendChild(btn);
    });
  }

  function renderDots(){
    var pin=getPin();
    _maxLen=pin.length||4;
    var el=document.getElementById('kl-dots');
    if(!el) return;
    el.innerHTML='';
    for(var i=0;i<_maxLen;i++){
      var d=document.createElement('div');
      d.className='kl-dot'+(i<_buf.length?' filled':'');
      el.appendChild(d);
    }
  }

  function pressKey(k){
    var pin=getPin();
    if(_buf.length>=pin.length) return;
    _buf.push(k);
    renderDots();
    if(_buf.length===pin.length) setTimeout(checkPin,120);
  }

  function checkPin(){
    var pin=getPin();
    if(_buf.join('')===pin){
      setSession();
      hideLogin();
    } else {
      var err=document.getElementById('kl-err');
      if(err){ err.textContent='PIN incorrecto. Tente novamente.'; setTimeout(function(){err.textContent='';},2000); }
      _buf=[];
      renderDots();
    }
  }

  function showLogin(){
    var ov=document.getElementById('karta-login-overlay');
    if(!ov) return;
    ov.style.display='flex';
    _buf=[];
    buildNumpad();
    renderDots();
    document.getElementById('kl-err').textContent='';
    // Suporte teclado
    document.addEventListener('keydown', onKeyDown);
  }

  function hideLogin(){
    var ov=document.getElementById('karta-login-overlay');
    if(!ov) return;
    ov.classList.add('gone');
    setTimeout(function(){ ov.style.display='none'; ov.classList.remove('gone'); },380);
    document.removeEventListener('keydown', onKeyDown);
  }

  function onKeyDown(e){
    if(e.key>='0'&&e.key<='9') pressKey(e.key);
    else if(e.key==='Backspace'){ _buf.pop(); renderDots(); }
    else if(e.key==='Enter'){ if(_buf.length>0) checkPin(); }
  }

  // ── Inicialização após load ────────────────────────────────────
  window.addEventListener('load', function(){
    if(isEnabled() && getPin() && !hasSession()){
      showLogin();
    }
    // Sincronizar UI da config
    loginCfgSync();
  });

  // ── Funções globais para a aba Abas ───────────────────────────
  window.loginCfgSync = function(){
    var chk=document.getElementById('login-enabled-chk');
    var lbl=document.getElementById('login-enabled-lbl');
    var row=document.getElementById('login-pin-row');
    var enabled=isEnabled();
    if(chk) chk.checked=enabled;
    if(lbl) lbl.textContent=enabled?'Activado':'Desactivado';
    if(row) row.style.opacity=enabled?'1':'0.4';
  };

  window.loginCfgToggle = function(){
    var chk=document.getElementById('login-enabled-chk');
    var enabled=chk&&chk.checked;
    try{ localStorage.setItem(LS_ENABLED, enabled?'1':'0'); }catch(e){}
    window.loginCfgSync();
  };

  window.loginPinSave = function(){
    var newEl =document.getElementById('login-pin-new');
    var cfmEl =document.getElementById('login-pin-cfm');
    var msgEl =document.getElementById('login-pin-msg');
    var newPin=(newEl?newEl.value:'').trim();
    var cfmPin=(cfmEl?cfmEl.value:'').trim();
    if(!newPin){ if(msgEl){msgEl.style.color='#D93025';msgEl.textContent='Introduza um PIN.';} return; }
    if(newPin.length<3){ if(msgEl){msgEl.style.color='#D93025';msgEl.textContent='PIN deve ter pelo menos 3 caracteres.';} return; }
    if(newPin!==cfmPin){ if(msgEl){msgEl.style.color='#D93025';msgEl.textContent='Os PINs não coincidem.';} return; }
    try{ localStorage.setItem(LS_PIN, newPin); }catch(e){}
    if(newEl) newEl.value='';
    if(cfmEl) cfmEl.value='';
    if(msgEl){ msgEl.style.color='#00875A'; msgEl.textContent='✓ PIN guardado!'; setTimeout(function(){msgEl.textContent='';},3000); }
  };

})();
