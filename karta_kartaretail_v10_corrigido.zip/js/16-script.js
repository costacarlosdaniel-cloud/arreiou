
(function(){
  function hideKSplash(){
    var s=document.getElementById('k-splash');
    if(s){
      s.classList.add('gone');
      setTimeout(function(){ if(s && s.parentNode) s.parentNode.removeChild(s); },500);
    }
  }
  // Não esperar pelo evento window.load, porque em iPhone/PWA/CDN o load pode ficar preso.
  // O splash deve sair independentemente de algum recurso externo atrasar.
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', function(){ setTimeout(hideKSplash, 700); });
  } else {
    setTimeout(hideKSplash, 700);
  }
  // Fallback absoluto: nunca deixar a app presa no ecrã inicial.
  setTimeout(hideKSplash, 3500);
})();
