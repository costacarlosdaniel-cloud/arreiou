
// ── COMUNICAÇÕES — Ranking Mensal ─────────────────────────────────────────────
(function(){

// Popula o select de meses na aba Comunicações
function comRankInitMes(){
  var sel=document.getElementById('com-rank-mes');
  if(!sel||sel.options.length>0) return;
  var labels=ML_RANK||{};
  (ADMCFG.meses||[]).forEach(function(m){
    var o=document.createElement('option');
    o.value=m;
    o.textContent=labels[m]||m;
    sel.appendChild(o);
  });
  // default: mês corrente ou último com dados
  var now=new Date();
  var cur=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0');
  if([].slice.call(sel.options).some(function(o){return o.value===cur;})) sel.value=cur;
  else if(sel.options.length) sel.value=sel.options[sel.options.length-1].value;
}

// Calcula lojaScores igual ao renderRankings mas retorna o array em vez de renderizar
function comGetLojaScores(mes){
  var kpiIds=Object.keys(RANK_WEIGHTS);
  var lojaData=ADMCFG.lojas.map(function(l){
    if(!isLojaActiva(l.c,mes)) return null;
    var agg=rankingAggregate(l.c,[mes]);
    if(!agg||agg.venda==null) return null;
    var obj=((window.ADM_DATA||{})[mes]||{})[l.c]||{};
    var objM={
      venda:obj.venda?parseFloat(obj.venda):null,
      pao:obj.pao?parseFloat(obj.pao):null,
      rutura:obj.rutura?parseFloat(obj.rutura):null,
      quebra:(obj.quebra!=null&&obj.quebra!==''&&parseFloat(obj.quebra)!==0)?parseFloat(obj.quebra):null,
      h1pao:obj.h1pao||null, hupao:obj.hupao||null,
      avsup:obj.avsup?parseFloat(obj.avsup):null,
      avsm:obj.avsm?parseFloat(obj.avsm):null
    };
    return {c:l.c,n:l.n,actuals:agg,obj:objM};
  }).filter(Boolean);
  if(!lojaData.length) return [];

  // relRank helper
  function relRank(lojas,kid){
    var vals=lojas.map(function(l){
      var v=null,a=l.actuals;
      if(kid==='venda')v=a.venda; else if(kid==='pao')v=a.pao;
      else if(kid==='rutura')v=a.rutura; else if(kid==='quebra')v=a.quebra;
      else if(kid==='h1pao')v=timeToMinutes(a.h1pao); else if(kid==='hupao')v=timeToMinutes(a.hupao);
      else if(kid==='avsup')v=a.avsup; else if(kid==='avsm')v=a.avsm;
      return{c:l.c,val:v};
    }).filter(function(x){return x.val!=null;});
    if(!vals.length) return{};
    vals.sort(function(a,b){return RANK_INVERT[kid]?a.val-b.val:b.val-a.val;});
    var out={};
    var i=0;
    while(i<vals.length){
      var j=i,vi=vals[i].val;
      while(j<vals.length&&Math.abs(vals[j].val-vi)<=0.01)j++;
      var sc=(vals.length-i)/vals.length*100;
      for(var k=i;k<j;k++) out[vals[k].c]=sc;
      i=j;
    }
    return out;
  }
  var relRanks={};
  kpiIds.forEach(function(kid){relRanks[kid]=relRank(lojaData,kid);});

  var scored=lojaData.map(function(l){
    var a=l.actuals,o=l.obj,pcts={},scores={};
    kpiIds.forEach(function(kid){
      var actual=a[kid],objVal=o[kid];
      if(actual==null){scores[kid]=null;pcts[kid]=null;return;}
      if(objVal!=null){
        var op=parseFloat(objVal);
        if(!isNaN(op)&&op!==0){
          var pct;
          if(kid==='h1pao'||kid==='hupao'){
            var am=timeToMinutes(String(actual)),om=timeToMinutes(String(objVal));
            if(am&&om) pct=kid==='h1pao'?om/am*100:am/om*100;
            else{scores[kid]=null;pcts[kid]=null;return;}
          } else {
            pct=RANK_INVERT[kid]?(Math.abs(op)/Math.max(Math.abs(kid==='quebra'?actual*100:actual),0.0001)*100):actual/op*100;
          }
          pcts[kid]=pct; scores[kid]=Math.min(pct,150);
        } else {scores[kid]=null;pcts[kid]=null;}
      } else if(relRanks[kid][l.c]!=null){
        scores[kid]=relRanks[kid][l.c]; pcts[kid]=relRanks[kid][l.c];
      } else {scores[kid]=null;pcts[kid]=null;}
    });
    var totalW=0,totalS=0;
    kpiIds.forEach(function(kid){if(scores[kid]!=null){totalW+=RANK_WEIGHTS[kid];totalS+=scores[kid]*RANK_WEIGHTS[kid];}});
    var finalScore=totalW>0?totalS/totalW:null;
    return{c:l.c,n:l.n,scores:scores,pcts:pcts,finalScore:finalScore};
  }).filter(function(l){return l.finalScore!=null;});
  scored.sort(function(a,b){return b.finalScore-a.finalScore;});
  return scored;
}

// ── CANVAS RENDERER ───────────────────────────────────────────────────────────
var _comCanvas=null;

function comRankDraw(lojaScores, mesLabel){
  var top3=lojaScores.slice(0,3);
  var flop3=lojaScores.slice(-3); // pior no fundo

  var W=900, PAD=28;
  var HDR_H=72, SEC_H=36, ROW_H=82, DIV_H=28, FOOTER_H=40;
  var colW=W-PAD*2;
  var totalH=HDR_H+SEC_H+top3.length*ROW_H+DIV_H+SEC_H+flop3.length*ROW_H+FOOTER_H+8;

  var canvas=document.createElement('canvas');
  var dpr=window.devicePixelRatio||1;
  canvas.width=W*dpr; canvas.height=totalH*dpr;
  canvas.style.width=W+'px'; canvas.style.height=totalH+'px';
  var ctx=canvas.getContext('2d');
  ctx.scale(dpr,dpr);

  var DARK='#111110', WHITE='#ffffff', LIGHT='#f5f5f3', BORDER='#e5e5e2';
  var GREEN='#1a7040', GREEN_BG='#eef7f2', GREEN_BORDER='#b5dfc8';
  var RED='#b83232', RED_BG='#fdf1f0', RED_BORDER='#f5c0c0';
  var AMBER='#7a5500', FAINT='#a8a8a4';

  function rr(x,y,w,h,r){
    ctx.beginPath();
    ctx.moveTo(x+r,y);ctx.lineTo(x+w-r,y);ctx.quadraticCurveTo(x+w,y,x+w,y+r);
    ctx.lineTo(x+w,y+h-r);ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
    ctx.lineTo(x+r,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-r);
    ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);
    ctx.closePath();
  }
  function scoreColor(s){return s==null?FAINT:s>=100?GREEN:s>=85?AMBER:RED;}

  // ── HEADER ──
  ctx.fillStyle=DARK; ctx.fillRect(0,0,W,HDR_H);
  ctx.fillStyle=WHITE; ctx.font='700 20px sans-serif'; ctx.textAlign='left';
  ctx.fillText('🔄 Status Update · Ranking de Lojas · '+mesLabel, PAD, 42);
  ctx.fillStyle='rgba(255,255,255,0.45)'; ctx.font='400 12px sans-serif';
  ctx.fillText('Top 3 + Flop 3 · face a objectivos · '+lojaScores.length+' lojas', PAD, 60);
  var now=new Date();
  var dateStr=now.getDate()+'/'+(now.getMonth()+1)+'/'+now.getFullYear();
  ctx.fillStyle='rgba(255,255,255,0.35)'; ctx.font='400 12px monospace';
  ctx.textAlign='right'; ctx.fillText(dateStr, W-PAD, 46); ctx.textAlign='left';

  var KS={venda:'Vnd',pao:'Pão',quebra:'Qbr',rutura:'Rut',h1pao:'1ºP',hupao:'ÚP',avsup:'AvS',avsm:'ASM'};
  var kids=Object.keys(RANK_WEIGHTS);

  function drawSecLabel(y, isTop){
    var bg=isTop?GREEN_BG:RED_BG, border=isTop?GREEN_BORDER:RED_BORDER, fg=isTop?GREEN:RED;
    ctx.fillStyle=bg; rr(PAD,y,colW,SEC_H-4,7); ctx.fill();
    ctx.strokeStyle=border; ctx.lineWidth=1; rr(PAD,y,colW,SEC_H-4,7); ctx.stroke();
    ctx.fillStyle=fg; ctx.font='700 12px sans-serif'; ctx.textAlign='left';
    ctx.fillText(isTop?'▲  TOP 3':'▼  FLOP 3', PAD+14, y+SEC_H/2+4);
  }

  function drawRow(ry, entry, side, pos, totalLojas){
    var isTop=side==='top';
    var accent=isTop?GREEN:RED, accentBg=isTop?GREEN_BG:RED_BG;
    var rx=PAD, rw=colW;

    // card bg
    ctx.fillStyle=WHITE; rr(rx,ry+2,rw,ROW_H-4,10); ctx.fill();
    ctx.strokeStyle=BORDER; ctx.lineWidth=0.5; rr(rx,ry+2,rw,ROW_H-4,10); ctx.stroke();
    // left accent bar
    ctx.fillStyle=accent; rr(rx,ry+10,3,ROW_H-22,2); ctx.fill();

    // medal / badge
    var bdgX=rx+12, bdgCY=ry+ROW_H/2;
    var medals=['🥇','🥈','🥉'];
    ctx.font='22px sans-serif'; ctx.textAlign='center';
    if(isTop){
      ctx.fillText(medals[pos], bdgX+13, bdgCY+8);
    } else {
      // position from bottom: flop3[0] = last place, flop3[2] = 3rd from last
      ctx.fillStyle=accentBg; rr(bdgX,bdgCY-13,26,22,5); ctx.fill();
      ctx.fillStyle=accent; ctx.font='700 12px sans-serif';
      var flopPos=totalLojas-flop3.length+pos+1;
      ctx.fillText(flopPos+'º', bdgX+13, bdgCY+3);
    }
    ctx.textAlign='left';

    // name + code
    var nameX=rx+46;
    var shortN=entry.n.replace(/Arreiou\s*/i,'');
    if(shortN.length>28) shortN=shortN.slice(0,27)+'…';
    ctx.fillStyle=DARK; ctx.font='600 14px sans-serif';
    ctx.fillText(shortN, nameX, ry+28);
    ctx.fillStyle=FAINT; ctx.font='400 11px monospace';
    ctx.fillText(entry.c, nameX, ry+44);

    // score
    var sc=entry.finalScore;
    var scX=rx+rw*0.40;
    ctx.fillStyle=scoreColor(sc); ctx.font='700 24px sans-serif';
    ctx.fillText(sc!=null?sc.toFixed(1):'—', scX, ry+32);
    if(sc!=null){
      var barW=72, barH=4, barY=ry+40;
      ctx.fillStyle=accentBg; rr(scX,barY,barW,barH,2); ctx.fill();
      ctx.fillStyle=accent; rr(scX,barY,barW*Math.min(sc,100)/100,barH,2); ctx.fill();
    }

    // KPI metrics
    var metStart=rx+rw*0.56;
    var metW=(rw-(metStart-rx)-12)/kids.length;
    kids.forEach(function(kid,i){
      var mx=metStart+i*metW;
      var p=entry.pcts[kid];
      ctx.fillStyle=FAINT; ctx.font='600 9px sans-serif'; ctx.textAlign='center';
      ctx.fillText(KS[kid], mx+metW/2-2, ry+22);
      if(p==null){
        ctx.fillStyle=FAINT; ctx.font='500 12px sans-serif';
        ctx.fillText('—', mx+metW/2-2, ry+42);
      } else {
        ctx.fillStyle=scoreColor(p); ctx.font='700 12px sans-serif';
        ctx.fillText(Math.round(p)+'%', mx+metW/2-2, ry+42);
      }
      ctx.textAlign='left';
    });
  }

  // ── DRAW TOP 3 ──
  var y=HDR_H+8;
  drawSecLabel(y, true);
  y+=SEC_H;
  top3.forEach(function(l,i){ drawRow(y+i*ROW_H, l, 'top', i, lojaScores.length); });

  // ── DIVIDER ──
  y+=top3.length*ROW_H+6;
  ctx.fillStyle=BORDER; ctx.fillRect(PAD,y+DIV_H/2,colW,0.5);
  y+=DIV_H;

  // ── DRAW FLOP 3 ──
  drawSecLabel(y, false);
  y+=SEC_H;
  flop3.forEach(function(l,i){ drawRow(y+i*ROW_H, l, 'flop', i, lojaScores.length); });

  // ── FOOTER ──
  var fy=y+flop3.length*ROW_H+10;
  ctx.fillStyle=BORDER; ctx.fillRect(0,fy,W,0.5);
  ctx.fillStyle=FAINT; ctx.font='400 11px sans-serif'; ctx.textAlign='center';
  ctx.fillText('Lojas Turbo · KPI Dashboard · '+mesLabel+' · '+dateStr, W/2, fy+22);

  return canvas;
}

// ── PUBLIC API ──────────────────────────────────────────────────────────────
window.comRankGenerate=function(){
  comRankInitMes();
  var sel=document.getElementById('com-rank-mes');
  var mes=sel?sel.value:'';
  if(!mes) return;
  var label=ML_RANK[mes]||mes;
  var scores=comGetLojaScores(mes);
  var prev=document.getElementById('com-rank-preview');
  if(!scores.length){
    prev.innerHTML='<span style="font-size:12px;color:var(--t3)">Sem dados suficientes para '+label+'.</span>';
    return;
  }
  var canvas=comRankDraw(scores, label);
  _comCanvas=canvas;
  // show preview
  canvas.style.maxWidth='100%';
  canvas.style.borderRadius='8px';
  canvas.style.display='block';
  prev.innerHTML='';
  prev.appendChild(canvas);
  // show action buttons
  var cb=document.getElementById('com-rank-copy-btn');
  var dl=document.getElementById('com-rank-dl-btn');
  if(cb) cb.style.display='flex';
  if(dl) dl.style.display='flex';
};

window.comRankCopy=function(){
  if(!_comCanvas) return;
  _comCanvas.toBlob(function(blob){
    try{
      navigator.clipboard.write([new ClipboardItem({'image/png':blob})]).then(function(){
        var el=document.getElementById('com-rank-copied');
        if(el){el.style.opacity='1';setTimeout(function(){el.style.opacity='0';},2500);}
      });
    }catch(e){
      // fallback: download
      window.comRankDownload();
    }
  },'image/png');
};

window.comRankDownload=function(){
  if(!_comCanvas) return;
  var a=document.createElement('a');
  var sel=document.getElementById('com-rank-mes');
  var mes=(sel?sel.value:'ranking').replace('-','');
  a.download='ranking-lojas-turbo-'+mes+'.png';
  a.href=_comCanvas.toDataURL('image/png');
  a.click();
};

// Init mes select when admin tab opens
var _origSwitchAdmCom=window.switchAdmTab;
window.switchAdmTab=function(t){
  _origSwitchAdmCom(t);
  if(t==='com') setTimeout(comRankInitMes,100);
};

})();
// ── FIM COMUNICAÇÕES ──────────────────────────────────────────────────────────
