
// ══ DIÁRIO DE LOJAS ══════════════════════════════════════════════════════════
var _dlInited = false;
var _dlSort = { col: 'c', dir: 'asc' };

var _dlLoadedMes = null;
function _dlLoadMonth(mes) {
  if (!mes) return;
  // Arrancar listener em tempo real para este mês
  if (typeof window.fbStartEntriesLive === 'function') window.fbStartEntriesLive(mes);
  if (_dlLoadedMes === mes) return;
  _dlLoadedMes = mes;
  // Invalidar cache se tiver mais de 15 minutos — garante dados frescos sem custo excessivo
  try {
    var _dlCacheTs = +(localStorage.getItem('karta_em_' + mes + '_ts') || 0);
    if (Date.now() - _dlCacheTs > 15 * 60 * 1000) {
      localStorage.removeItem('karta_em_' + mes);
      localStorage.removeItem('karta_em_' + mes + '_ts');
    }
  } catch(e) {}
  if (typeof fbLoadEntriesMonth !== 'function') return;
  fbLoadEntriesMonth(mes).then(function(data) {
    if (!data || !Object.keys(data).length) return;
    if (!window.entries || typeof window.entries !== 'object') window.entries = {};
    Object.keys(data).forEach(function(k) { window.entries[k] = data[k]; });
    try { localStorage.setItem('arrv6', JSON.stringify(window.entries)); } catch(e) {}
    diarioLojasRender();
  }).catch(function(e) { window._KARTA_DEBUG&&console.warn('[DL] fbLoadEntriesMonth error:', e); });
}

function dlForceRefresh() {
  var btn = document.getElementById('dl-refresh-btn');
  if (btn) { btn.textContent = '⏳ A carregar...'; btn.disabled = true; }
  var dateEl = document.getElementById('dl-date');
  var dt = dateEl ? dateEl.value : '';
  var mes = dt ? dt.substring(0, 7) : new Date().toISOString().substring(0, 7);
  // Limpar TODAS as caches relacionadas com entries para forçar leitura fresca
  try {
    localStorage.removeItem('karta_em_' + mes);
    localStorage.removeItem('karta_em_' + mes + '_ts');
    // Limpar também caches de loja/ano para o mês actual
    var ano = mes.substring(0, 4);
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k && (k.startsWith('fs_entries_') || k.startsWith('karta_cache_query_')) && k.indexOf(ano) >= 0) {
        localStorage.removeItem(k); i--;
      }
    }
  } catch(e) {}
  _dlLoadedMes = null;
  // Ir directamente ao Firestore com getDocs
  var _fbLEM = window.fbLoadEntriesMonth;
  if (mes && typeof _fbLEM === 'function') {
    _fbLEM(mes).then(function(data) {
      var count = Object.keys(data || {}).length;
      window._KARTA_DEBUG&&console.log('[DL] dlForceRefresh loaded:', count, 'docs for', mes);
      if (!window.entries || typeof window.entries !== 'object') window.entries = {};
      Object.keys(data || {}).forEach(function(k) { window.entries[k] = data[k]; });
      try { localStorage.setItem('arrv6', JSON.stringify(window.entries)); } catch(e) {}
      _dlLoadedMes = mes;
      diarioLojasRender();
      if (btn) {
        btn.textContent = count > 0 ? ('✓ ' + count + ' registos') : '✓ Sem dados';
        btn.style.background = count > 0 ? '#16a34a' : '#f59e0b';
        btn.disabled = false;
        setTimeout(function(){ btn.textContent = 'Atualizar dados'; btn.style.background = '#0070F3'; }, 3000);
      }
    }).catch(function(e) {
      console.error('[DL] dlForceRefresh error:', e);
      if (btn) { btn.textContent = '⚠ Erro - tente novamente'; btn.style.background='#dc2626'; btn.disabled = false; setTimeout(function(){ btn.textContent = 'Atualizar dados'; btn.style.background = '#0070F3'; }, 3000); }
    });
  } else {
    window._KARTA_DEBUG&&console.warn('[DL] fbLoadEntriesMonth not available');
    if (btn) { btn.textContent = 'Atualizar dados'; btn.disabled = false; }
  }
}

function diarioLojasInit() {
  // Set default date: today if after 10h, yesterday otherwise
  var el = document.getElementById('dl-date');
  if (el && !el.value) {
    var _now = new Date();
    var _useToday = _now.getHours() >= 10; // antes das 10h mostra ontem (dados mais completos)
    if (!_useToday) _now.setDate(_now.getDate() - 1);
    el.value = _now.toISOString().split('T')[0];
  }
  // Populate supervisor filter (once)
  if (!_dlInited) {
    _dlInited = true;
    var supSel = document.getElementById('dl-sup-filter');
    if (supSel && supSel.options.length <= 1) {
      var sups = {};
      Object.keys(DB).forEach(function(c) {
        var l = DB[c]; if (!l) return;
        var s = l.s || (typeof supervisorDaLoja === 'function' ? supervisorDaLoja(c) : '');
        if (s && !sups[s]) { sups[s] = true; var o = document.createElement('option'); o.value = s; o.textContent = s; supSel.appendChild(o); }
      });
    }
  }
  var dateEl = document.getElementById('dl-date');
  var dt = dateEl ? dateEl.value : '';
  if (dt) _dlLoadMonth(dt.substring(0, 7));
  diarioLojasRender();
}

function dlGoDay(offset) {
  var d = new Date(); d.setDate(d.getDate() + offset);
  var el = document.getElementById('dl-date');
  if (el) {
    el.value = d.toISOString().split('T')[0];
    _dlLoadMonth(el.value.substring(0, 7));
    diarioLojasRender();
  }
}

function dlSort(col) {
  if (_dlSort.col === col) _dlSort.dir = _dlSort.dir === 'asc' ? 'desc' : 'asc';
  else { _dlSort.col = col; _dlSort.dir = (col === 'vs' || col === 'vp' || col === 'dvpct' || col === 'dppct') ? 'desc' : 'asc'; }
  diarioLojasRender();
}

function diarioLojasRender() {
  var dateEl = document.getElementById('dl-date');
  var dt = dateEl ? dateEl.value : (new Date(Date.now() - 86400000).toISOString().split('T')[0]);
  if (!dt) return;

  var mes = dt.substring(0, 7); // YYYY-MM

  var showObj = (document.getElementById('dl-show-obj') || {}).checked !== false;
  var search = ((document.getElementById('dl-search') || {}).value || '').toLowerCase();
  var supFil = ((document.getElementById('dl-sup-filter') || {}).value || '');

  // Build row data — allRows ignores filters (for missing panel), rows respects filters
  var allRows = [];
  Object.keys(DB).forEach(function(c) {
    var st = DB[c]; if (!st) return;
    if (typeof isLojaActiva === 'function' && !isLojaActiva(c, mes)) return;
    var name = st.n || c;
    var sup = st.s || (typeof supervisorDaLoja === 'function' ? supervisorDaLoja(c) : '') || '';
    var sap0 = (st.r || []).find(function(r) { return r.d === dt; }) || {};
    var ue0  = (typeof entries !== 'undefined' ? entries : {})[c + '_' + dt] || {};
    var vs0  = ue0.venda_dia != null ? ue0.venda_dia : (sap0.vs != null ? sap0.vs : null);
    allRows.push({ c: c, n: name, sup: sup, vs: vs0 });
  });

  var rows = [];
  Object.keys(DB).forEach(function(c) {
    var st = DB[c]; if (!st) return;
    if (typeof isLojaActiva === 'function' && !isLojaActiva(c, mes)) return;
    var name = st.n || c;
    var sup = st.s || (typeof supervisorDaLoja === 'function' ? supervisorDaLoja(c) : '') || '';

    // Filter
    if (search && !(c.toLowerCase().includes(search) || name.toLowerCase().includes(search) || sup.toLowerCase().includes(search))) return;
    if (supFil && sup !== supFil) return;

    // SAP data for this day
    var sap = (st.r || []).find(function(r) { return r.d === dt; }) || {};
    // Manual entries (venda_dia, tpas, padeiros)
    var ue = (typeof entries !== 'undefined' ? entries : {})[c + '_' + dt] || {};

    // Objectives — daily (divide monthly objective by days in month)
    var obj = (window.ADM_DATA && window.ADM_DATA[mes] && window.ADM_DATA[mes][c]) || {};
    var _mParts = mes.split('-');
    var _daysInMonth = new Date(parseInt(_mParts[0]), parseInt(_mParts[1]), 0).getDate();
    var objVenda = obj.venda ? Math.round(parseFloat(obj.venda) / _daysInMonth) : null;
    var objPao   = obj.pao   ? parseFloat(obj.pao)   : null; // pão já é diário

    // Values
    var vs  = ue.venda_dia != null ? ue.venda_dia : (sap.vs != null ? sap.vs : null);
    // Venda Pão pode vir do Google Sheets (sap.vp) ou do Firebase/localStorage (ue.vp).
    // Alguns uploads/sincronizações guardam aliases; aqui normalizamos e impedimos NaN.
    var _vpRaw = (sap.vp != null && !isNaN(sap.vp)) ? sap.vp
               : (ue.vp != null ? ue.vp
               : (ue.venda_pao != null ? ue.venda_pao
               : (ue.pao != null ? ue.pao : null)));
    var _vpNum = (typeof numAny === 'function') ? numAny(_vpRaw) : (_vpRaw != null ? Number(_vpRaw) : null);
    var vp  = (_vpNum != null && !isNaN(_vpNum)) ? Math.round(_vpNum) : null;
    var h1  = sap.h1  || ue.h1 || '';
    var hu  = sap.hu  || ue.hu || '';
    var hl  = sap.hl  != null ? sap.hl  : null;
    var hp  = sap.hp  != null ? sap.hp  : null;
    var ru  = sap.ru  != null ? sap.ru  : null;
    var tp  = ue.tpas     != null ? ue.tpas     : null;
    var pa  = ue.padeiros != null ? ue.padeiros : null;

    // Desvio %
    var dvpct = (vs != null && objVenda) ? ((vs - objVenda) / objVenda * 100) : null;
    var dppct = (vp != null && objPao)   ? ((vp - objPao)   / objPao   * 100) : null;

    rows.push({ c: c, n: name, sup: sup, objv: objVenda, vs: vs, dvpct: dvpct, objp: objPao, vp: vp, dppct: dppct, tp: tp, pa: pa, h1: h1, hu: hu, hl: hl, hp: hp, ru: ru });
  });

  // Sort
  var sc = _dlSort.col, sd = _dlSort.dir;
  rows.sort(function(a, b) {
    var av = a[sc], bv = b[sc];
    if (typeof av === 'string' && typeof bv === 'string') return sd === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    if (av == null && bv == null) return 0;
    if (av == null) return 1; if (bv == null) return -1;
    return sd === 'asc' ? av - bv : bv - av;
  });

  // Sort indicators
  document.querySelectorAll('[id^="dl-si-"]').forEach(function(el) { el.textContent = ''; });
  var si = document.getElementById('dl-si-' + sc);
  if (si) si.textContent = ' ' + (sd === 'asc' ? '↑' : '↓');

  // Helpers
  function fK(v) { if (v == null) return '—'; return Number(v).toLocaleString('pt-AO', { minimumFractionDigits: 0, maximumFractionDigits: 0 }); }
  function fN2(v, dec) { if (v == null) return '—'; return v.toLocaleString('pt-AO', { maximumFractionDigits: dec || 0 }); }
  function fPct(v) { if (v == null) return '—'; return (v >= 0 ? '+' : '') + v.toFixed(1) + '%'; }
  function fRu(v) { if (v == null) return '—'; return v.toFixed(2) + '%'; }
  function fH(v) {
    if (!v) return '—';
    var p = v.split(':'); var h = parseInt(p[0]), m = parseInt(p[1] || 0);
    return h + 'h' + (m > 0 ? String(m).padStart(2,'0') : '');
  }

  function desvioStyle(pct) {
    if (pct == null) return '';
    if (pct >= 5)  return 'color:var(--green);font-weight:600';
    if (pct >= 0)  return 'color:var(--green)';
    if (pct >= -5) return 'color:var(--amber)';
    return 'color:var(--red);font-weight:600';
  }
  function ruStyle(v) {
    if (v == null) return '';
    if (v > 3) return 'color:var(--red);font-weight:600';
    if (v > 1.5) return 'color:var(--amber)';
    return 'color:var(--green)';
  }
  function h1Style(v) {
    if (!v) return '';
    var p = v.split(':'); var mins = parseInt(p[0]) * 60 + parseInt(p[1] || 0);
    return mins > 485 ? 'color:var(--red);font-weight:600' : 'color:var(--green)';
  }
  function huStyle(v) {
    if (!v) return '';
    var p = v.split(':'); var mins = parseInt(p[0]) * 60 + parseInt(p[1] || 0);
    return mins < 1260 ? 'color:var(--red);font-weight:600' : 'color:var(--green)';
  }
  function dtStyle(v) {
    if (v == null) return '';
    return v > 0 ? 'color:var(--red);font-weight:600' : 'color:var(--green)';
  }

  // Count rows with data
  var withData = rows.filter(function(r) { return r.vs != null || r.vp != null || r.tp != null; }).length;
  var countEl = document.getElementById('dl-count');
  if (countEl) countEl.textContent = rows.length + ' lojas · ' + withData + ' com dados';

  var titleEl = document.getElementById('dl-table-title');
  if (titleEl) {
    var wd = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
    var dd = new Date(dt + 'T12:00:00');
    titleEl.textContent = wd[dd.getDay()] + ', ' + dt.split('-').reverse().join('/');
  }

  // Cards summary
  var cardsEl = document.getElementById('dl-cards');
  if (cardsEl) {
    var withVs  = rows.filter(function(r) { return r.vs != null; });
    var withVp  = rows.filter(function(r) { return r.vp != null; });
    var withTp  = rows.filter(function(r) { return r.tp != null; });
    var withPa  = rows.filter(function(r) { return r.pa != null; });
    var withHl  = rows.filter(function(r) { return r.hl != null; });
    var withHp  = rows.filter(function(r) { return r.hp != null; });
    var withRu  = rows.filter(function(r) { return r.ru != null; });

    var totalVs    = withVs.reduce(function(s,r){ return s+r.vs; }, 0);
    var totalVp    = withVp.reduce(function(s,r){ return s+r.vp; }, 0);
    var totalHl    = withHl.reduce(function(s,r){ return s+r.hl; }, 0);
    var totalHp    = withHp.reduce(function(s,r){ return s+r.hp; }, 0);
    var totalObjVs = rows.filter(function(r){return r.objv!=null;}).reduce(function(s,r){return s+r.objv;},0);

    var desvioGlobal = totalObjVs > 0 ? ((totalVs - totalObjVs) / totalObjVs * 100) : null;
    var medRu  = withRu.length  ? withRu.reduce(function(s,r){return s+r.ru;},0)/withRu.length  : null;
    var medVs  = withVs.length  ? totalVs / withVs.length  : null;
    var medVp  = withVp.length  ? totalVp / withVp.length  : null;
    var medTp  = withTp.length  ? withTp.reduce(function(s,r){return s+r.tp;},0)/withTp.length : null;
    var medPa  = withPa.length  ? withPa.reduce(function(s,r){return s+r.pa;},0)/withPa.length : null;

    function card(label, val, valStyle) {
      return '<div class="acard"><div class="acl">' + label + '</div>'
           + '<div class="acv"' + (valStyle ? ' style="' + valStyle + '"' : '') + '>' + val + '</div></div>';
    }

    var dStyle   = desvioGlobal == null ? '' : desvioGlobal >= 0 ? 'color:var(--green)' : 'color:var(--red)';
    var ruStyle2 = medRu == null ? '' : medRu > 3 ? 'color:var(--red)' : medRu > 1.5 ? 'color:var(--amber)' : 'color:var(--green)';

    cardsEl.innerHTML =
      card('Nº Lojas c/ Venda',    withVs.length + '<span style="font-size:12px;font-weight:400;color:var(--t3)"> / ' + rows.length + '</span>') +
      card('Obj. Venda Total',      totalObjVs > 0 ? fK(totalObjVs) : '—') +
      card('Venda Total (ICG)',     withVs.length ? fK(totalVs) : '—') +
      card('Desvio Global %',       desvioGlobal != null ? fPct(desvioGlobal) : '—', dStyle + ';font-weight:700') +
      card('Média Venda / Loja',    medVs != null ? fK(Math.round(medVs)) : '—') +
      card('Média Pão / Loja',      medVp != null ? fN2(Math.round(medVp)) : '—') +
      card('Média TPAS / Loja',     medTp != null ? medTp.toFixed(1) : '—') +
      card('Média Padeiros / Loja', medPa != null ? medPa.toFixed(1) : '—') +
      card('Total DT Loja',         withHl.length ? totalHl.toFixed(1) + 'h' : '—') +
      card('Total DT Padaria',      withHp.length ? totalHp.toFixed(1) + 'h' : '—') +
      card('Média Ruturas %',       medRu != null ? medRu.toFixed(2) + '%' : '—', ruStyle2);
  }

  // Build table rows
  var html = '';
  rows.forEach(function(r) {
    var hasAny = r.vs != null || r.vp != null || r.tp != null || r.pa != null || r.ru != null;
    html += '<tr style="' + (hasAny ? '' : 'opacity:.45') + '">';
    html += '<td style="font-family:monospace;font-size:10px;color:var(--t3)">' + r.c + '</td>';
    html += '<td class="lft" style="font-weight:500;color:var(--tx);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + (r.n||'') + '">' + (r.n||r.c) + '</td>';
    html += '<td style="color:var(--purple);font-weight:500">' + (showObj && r.objv != null ? fK(r.objv) : '—') + '</td>';
    html += '<td style="font-weight:500;color:var(--tx)">' + (r.vs != null ? fK(r.vs) : '—') + '</td>';
    html += '<td style="' + desvioStyle(r.dvpct) + '">' + (r.dvpct != null ? fPct(r.dvpct) : (r.vs == null ? '—' : 'sem obj.')) + '</td>';
    html += '<td style="color:var(--purple);font-weight:500">' + (showObj && r.objp != null ? fN2(r.objp) : '—') + '</td>';
    html += '<td style="color:var(--amber)">' + (r.vp != null ? fN2(r.vp) : '—') + '</td>';
    html += '<td style="' + desvioStyle(r.dppct) + '">' + (r.dppct != null ? fPct(r.dppct) : (r.vp == null ? '—' : 'sem obj.')) + '</td>';
    html += '<td>' + (r.tp != null ? r.tp : '—') + '</td>';
    html += '<td>' + (r.pa != null ? r.pa : '—') + '</td>';
    html += '<td style="' + h1Style(r.h1) + '">' + fH(r.h1) + '</td>';
    html += '<td style="' + huStyle(r.hu) + '">' + fH(r.hu) + '</td>';
    html += '<td style="' + dtStyle(r.hl) + '">' + (r.hl != null ? r.hl + 'h' : '—') + '</td>';
    html += '<td style="' + dtStyle(r.hp) + '">' + (r.hp != null ? r.hp + 'h' : '—') + '</td>';
    html += '<td style="' + ruStyle(r.ru) + '">' + fRu(r.ru) + '</td>';
    html += '</tr>';
  });

  var tbody = document.getElementById('dl-tbody');
  if (tbody) tbody.innerHTML = html || '<tr><td colspan="15" style="text-align:center;padding:40px;color:var(--t3)">Sem lojas a mostrar para os filtros seleccionados.</td></tr>';

  // Painel lojas sem venda do dia
  dlRenderMissing(allRows, dt);
}

// ── Lojas sem Venda do Dia ───────────────────────────────────────────────
function dlRenderMissing(allRows, dt) {
  var panel   = document.getElementById('dl-missing-panel');
  var countEl = document.getElementById('dl-missing-count');
  var wrap    = document.getElementById('dl-missing-content');
  if (!panel || !wrap) return;

  // Only active ADMCFG lojas count (if available), else all DB rows
  var admCodes = new Set(((window.ADMCFG && window.ADMCFG.lojas) || []).map(function(l){ return l.c; }));
  var missing = allRows.filter(function(r) {
    if (admCodes.size > 0 && !admCodes.has(r.c)) return false; // not a managed store
    return r.vs == null;
  });

  if (missing.length === 0) { panel.style.display = 'none'; return; }
  panel.style.display = 'block';
  if (countEl) countEl.textContent = missing.length + ' loja' + (missing.length !== 1 ? 's' : '');

  // Group by supervisor, sort sup name
  var bySup = {};
  missing.forEach(function(r) {
    var s = r.sup || 'Sem supervisor';
    if (!bySup[s]) bySup[s] = [];
    bySup[s].push(r);
  });
  var sups = Object.keys(bySup).sort();

  var html = '<div style="display:flex;flex-direction:column;gap:12px">';
  sups.forEach(function(sup) {
    var stores = bySup[sup].sort(function(a,b){ return a.c.localeCompare(b.c); });
    html += '<div>'
          + '<div style="font-size:10px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">'
          + sup + '<span style="font-weight:400;color:var(--t3);margin-left:6px">(' + stores.length + ')</span></div>'
          + '<div style="display:flex;flex-wrap:wrap;gap:5px">';
    stores.forEach(function(r) {
      html += '<span style="font-size:11px;padding:3px 10px;border-radius:20px;'
            + 'background:var(--s2);border:1px solid var(--bd2);color:var(--tx);white-space:nowrap">'
            + r.c + ' &middot; ' + (r.n || r.c) + '</span>';
    });
    html += '</div></div>';
  });
  html += '</div>';
  wrap.innerHTML = html;

  // Store for image export
  wrap._missingData = { missing: missing, bySup: bySup, sups: sups, dt: dt };
}

function dlCopyMissingImage() {
  var wrap = document.getElementById('dl-missing-content');
  var btn  = document.getElementById('dl-copy-img-btn');
  if (!wrap || !wrap._missingData) return;

  var data   = wrap._missingData;
  var bySup  = data.bySup;
  var sups   = data.sups;
  var dt     = data.dt;
  var total  = data.missing.length;

  var isDark = document.documentElement.classList.contains('dark')
            || document.body.classList.contains('dark')
            || (window.matchMedia && window.matchMedia('(prefers-color-scheme:dark)').matches);

  // Colours
  var BG    = isDark ? '#1e1e1e' : '#ffffff';
  var HDR   = isDark ? '#252523' : '#f7f7f5';
  var TX    = isDark ? '#f0f0ee' : '#1a1a18';
  var T2    = isDark ? '#a0a09c' : '#5a5a56';
  var T3    = isDark ? '#686864' : '#9a9a96';
  var BD    = isDark ? '#333330' : '#e4e4e0';
  var TAGBG = isDark ? '#2c2c2a' : '#f0f0ee';
  var TAGBD = isDark ? '#3c3c3a' : '#d4d4d0';
  var RED   = '#e74c3c';

  var SCALE = 2;
  var W = 680;
  var PAD = 22;
  var LINE = 20;
  var TAG_H = 24;
  var TAG_PX = 12;
  var GAP = 6;

  // Measure pass to get total height
  var mCvs = document.createElement('canvas');
  mCvs.width = W * SCALE; mCvs.height = 100 * SCALE;
  var mCtx = mCvs.getContext('2d');
  mCtx.scale(SCALE, SCALE);

  function measureH(ctx) {
    var y = PAD + 36 + 14; // header height
    sups.forEach(function(sup) {
      var stores = bySup[sup].sort(function(a,b){ return a.c.localeCompare(b.c); });
      y += 18; // sup label
      // wrap tags
      var cx = PAD;
      ctx.font = '11px Inter,system-ui,Arial,sans-serif';
      stores.forEach(function(r) {
        var lbl = r.c + ' · ' + (r.n || r.c);
        var tw = ctx.measureText(lbl).width + TAG_PX * 2 + 2;
        if (cx + tw > W - PAD) { cx = PAD; y += TAG_H + GAP; }
        cx += tw + GAP;
      });
      y += TAG_H + 16; // row + gap after group
    });
    y += 24; // footer
    return y;
  }

  var totalH = measureH(mCtx);

  var cvs = document.createElement('canvas');
  cvs.width  = W * SCALE;
  cvs.height = totalH * SCALE;
  var ctx = cvs.getContext('2d');
  ctx.scale(SCALE, SCALE);

  // Background
  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, totalH);

  // Header band
  ctx.fillStyle = HDR;
  ctx.fillRect(0, 0, W, 50);
  ctx.strokeStyle = BD; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(0, 50); ctx.lineTo(W, 50); ctx.stroke();

  // Red dot + title
  ctx.fillStyle = RED;
  ctx.beginPath(); ctx.arc(PAD + 5, 25, 5, 0, Math.PI * 2); ctx.fill();
  ctx.font = 'bold 14px Inter,system-ui,Arial,sans-serif';
  ctx.fillStyle = TX;
  ctx.fillText('Lojas sem Venda do Dia (AOA)', PAD + 18, 30);

  // Date + count
  ctx.font = '11px Inter,system-ui,Arial,sans-serif';
  ctx.fillStyle = T3;
  var parts = dt.split('-');
  var dtFmt = parts[2] + '/' + parts[1] + '/' + parts[0];
  var sub = dtFmt + '  ·  ' + total + ' loja' + (total !== 1 ? 's' : '') + ' sem registo';
  ctx.fillText(sub, PAD + 18, 44);

  var y = 50 + 14;

  sups.forEach(function(sup) {
    var stores = bySup[sup].sort(function(a,b){ return a.c.localeCompare(b.c); });

    // Supervisor label
    ctx.font = 'bold 9px Inter,system-ui,Arial,sans-serif';
    ctx.fillStyle = T2;
    ctx.fillText(sup.toUpperCase() + '  (' + stores.length + ')', PAD, y + 11);
    y += 18;

    // Tags
    var cx = PAD;
    ctx.font = '11px Inter,system-ui,Arial,sans-serif';
    stores.forEach(function(r) {
      var lbl = r.c + ' · ' + (r.n || r.c);
      var tw = ctx.measureText(lbl).width + TAG_PX * 2 + 2;
      if (cx + tw > W - PAD) { cx = PAD; y += TAG_H + GAP; }
      // tag background
      ctx.fillStyle = TAGBG;
      ctx.strokeStyle = TAGBD; ctx.lineWidth = 1;
      roundRect(ctx, cx, y, tw, TAG_H - 2, 12);
      ctx.fill(); ctx.stroke();
      // tag text
      ctx.fillStyle = TX;
      ctx.font = '11px Inter,system-ui,Arial,sans-serif';
      ctx.fillText(lbl, cx + TAG_PX, y + 15);
      cx += tw + GAP;
    });
    y += TAG_H + 16;
  });

  // Footer
  ctx.font = '9px Inter,system-ui,Arial,sans-serif';
  ctx.fillStyle = T3;
  var ts = new Date().toLocaleString('pt-AO', {day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
  ctx.fillText('KPI Turbo · ' + ts, PAD, y + 10);

  cvs.toBlob(function(blob) {
    if (!blob) { alert('Erro ao gerar imagem.'); return; }
    var oldHtml = btn ? btn.innerHTML : '';
    try {
      navigator.clipboard.write([new ClipboardItem({'image/png': blob})]).then(function() {
        if (btn) { btn.innerHTML = '✓ Copiado!'; setTimeout(function(){ btn.innerHTML = oldHtml; }, 2500); }
      }).catch(function(){ dlFallbackDownload(cvs, dt); });
    } catch(e) { dlFallbackDownload(cvs, dt); }
  });
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function dlFallbackDownload(cvs, dt) {
  var a = document.createElement('a');
  a.href = cvs.toDataURL('image/png');
  a.download = 'sem-venda-' + (dt || '') + '.png';
  a.click();
}

window.diarioLojasInit = diarioLojasInit;
window.diarioLojasRender = diarioLojasRender;
window.dlGoDay = dlGoDay;
window.dlSort = dlSort;
window.dlCopyMissingImage = dlCopyMissingImage;
