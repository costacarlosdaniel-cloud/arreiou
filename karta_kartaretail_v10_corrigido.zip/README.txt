Karta modularizada

Ficheiros principais:
- index.html: estrutura HTML e links para módulos.
- css/: estilos extraídos do HTML original, mantendo a mesma ordem.
- js/: scripts extraídos do HTML original, mantendo a mesma ordem de execução.
- manifest.json, sw.js, _headers, icon-192.png, icon-512.png: ficheiros PWA/deploy.

Dados existentes:
Sim, os dados continuam a ser os mesmos porque a configuração Firebase, projectId, coleções e chaves foram preservados. A app continua a apontar para o mesmo projeto Firebase usado no HTML original.

Notas:
- Faz deploy desta pasta inteira no Netlify/Vercel.
- Mantém os nomes na raiz: index.html, manifest.json, sw.js, icon-192.png e icon-512.png.
- Se mudares o service worker, atualiza CACHE_NAME no sw.js para forçar refresh nos utilizadores.

Extração automática:
- CSS extraído: 5 ficheiros
- JS inline extraído: 22 ficheiros
