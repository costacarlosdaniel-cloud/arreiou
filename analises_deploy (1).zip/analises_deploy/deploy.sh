#!/bin/bash
# deploy.sh — bumpa a versão de cache e faz deploy para Netlify
set -e
TS=$(date +%Y%m%d%H%M)
sed -i "s/karta-analises-[0-9]*/karta-analises-${TS}/" sw.js
sed -i "s/karta-analises-v[0-9]*/karta-analises-v${TS}/" index.html
echo "Cache bumped: karta-analises-${TS}"
