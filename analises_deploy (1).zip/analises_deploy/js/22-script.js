
/* PATCH FINAL — Dif. Contagens sem recursão
   Causa: _dcgGetLojas chamava _dcgNomeLoja, e _dcgNomeLoja chamava _dcgGetLojas.
   Resultado: Maximum call stack size exceeded. */
(function(){
  function _dcgFinalData(){
    try { return window.CONT_DATA || (typeof contDataLoad === 'function' ? contDataLoad() : {}) || {}; }
    catch(e){ return {}; }
  }
  function _dcgFinalAdmLojas(){
    try { return ((window.ADMCFG && window.ADMCFG.lojas) || []).filter(function(l){ return l && l.c; }); }
    catch(e){ return []; }
  }
  function _dcgFinalDates(){
    var days = window._dcgPeriodDays || 7;
    var arr = [];
    for (var i = days - 1; i >= 0; i--) {
      if (typeof isoToday === 'function') arr.push(isoToday(-i));
      else arr.push(new Date(Date.now() - i * 86400000).toISOString().slice(0,10));
    }
    return arr;
  }
  function _dcgFinalNameFromSources(code){
    code = String(code || '').trim();
    if (!code) return '';
    var adm = _dcgFinalAdmLojas();
    for (var i=0;i<adm.length;i++) {
      if (String(adm[i].c).trim() === code) return adm[i].n || code;
    }
    try {
      var paoLojas = window.D && window.D.pao && window.D.pao.lojas ? window.D.pao.lojas : [];
      for (var j=0;j<paoLojas.length;j++) {
        if (String(paoLojas[j].c).trim() === code) return paoLojas[j].n || code;
      }
    } catch(e) {}
    return code;
  }
  window._dcgNomeLoja = function(code){
    return _dcgFinalNameFromSources(code);
  };
  window._dcgGetLojas = function(){
    var map = {};
    _dcgFinalAdmLojas().forEach(function(l){
      map[String(l.c).trim()] = { c:String(l.c).trim(), n:l.n || String(l.c).trim(), s:l.s || '' };
    });
    var data = _dcgFinalData();
    _dcgFinalDates().forEach(function(d){
      var day = data[d] || {};
      Object.keys(day).forEach(function(c){
        c = String(c || '').trim();
        if (!c) return;
        if (!map[c]) map[c] = { c:c, n:_dcgFinalNameFromSources(c), s:'' };
      });
    });
    return Object.keys(map).sort().map(function(k){ return map[k]; });
  };
  window.dcgCalorRender = window.dcgCalorRender || window.dcgCaiorRender;
  window.dcgCaiorRender = window.dcgCalorRender || window.dcgCaiorRender;
})();

// ── ALERTA INVENTÁRIO — Gerentes com VD < -1% em ≥3 últimos resultados ──────
(function(){

  function fPct(v){ return v==null?'—':(v>=0?'+':'')+v.toFixed(2)+'%'; }
  function fDate(dt){ if(!dt) return '—'; var d=new Date(dt); return String(d.getDate()).padStart(2,'0')+'/'+String(d.getMonth()+1).padStart(2,'0')+'/'+d.getFullYear(); }

  window.invReportRender = function(){
    var el = document.getElementById('inv-report-content');
    if(!el) return;

    // Garantir que os dados de inventário estão carregados
    // _invLoaded/_invData são expostos via Object.defineProperty em 14-script.js
    if(!window._invLoaded){
      el.innerHTML = '<div style="padding:60px;text-align:center;color:var(--t3);font-size:12px">⏳ A carregar dados de inventário…</div>';
      // Registar callback para quando o load terminar
      if(!window._invLoadCallbacks) window._invLoadCallbacks = [];
      // Evitar registar o mesmo callback duas vezes
      if(!window._invReportPending){
        window._invReportPending = true;
        window._invLoadCallbacks.push(function(){ window._invReportPending=false; invReportRender(); });
      }
      // Disparar load se ainda não estiver em curso
      if(typeof invAdmLoad === 'function' && !window._invLoading){
        invAdmLoad();
      }
      // Polling de segurança: verificar a cada 1s se já carregou (fallback se callback falhar)
      if(!window._invReportPoll){
        window._invReportPoll = setInterval(function(){
          if(window._invLoaded){
            clearInterval(window._invReportPoll);
            window._invReportPoll = null;
            window._invReportPending = false;
            invReportRender();
          }
        }, 1000);
      }
      return;
    }
    // Limpar polling se ainda activo
    if(window._invReportPoll){ clearInterval(window._invReportPoll); window._invReportPoll=null; }

    var THRESHOLD = -1;   // %
    var MIN_HITS  =  3;   // mínimo de resultados consecutivos abaixo do threshold

    // Agrupar por gerente → loja → lista de resultados ordenados por data
    var byGerLoja = {};
    _invData.forEach(function(r){
      var gv = (r.sm || '—').trim();
      var key = gv + '|' + r.centro;
      if(!byGerLoja[key]) byGerLoja[key] = { gv:gv, centro:r.centro, loja:r.loja, records:[] };
      byGerLoja[key].records.push(r);
    });

    // Para cada gerente+loja, ordenar por data e verificar os últimos N resultados
    var alerts = [];
    Object.values(byGerLoja).forEach(function(entry){
      var recs = entry.records.filter(function(r){ return r.dt && r.vd!=null; });
      recs.sort(function(a,b){ return a.dt - b.dt; });
      if(recs.length < MIN_HITS) return;

      // Pegar os últimos MIN_HITS registos e verificar se todos têm vd < THRESHOLD
      var tail = recs.slice(-MIN_HITS);
      var allBad = tail.every(function(r){ return r.vd < THRESHOLD; });
      if(!allBad) return;

      // Calcular streak total (quantos consecutivos finais estão abaixo)
      var streak = 0;
      for(var i = recs.length-1; i >= 0; i--){
        if(recs[i].vd < THRESHOLD) streak++;
        else break;
      }

      var avgVd = tail.reduce(function(a,r){ return a+r.vd; },0) / tail.length;
      var lastRec = tail[tail.length-1];
      alerts.push({
        gv: entry.gv,
        centro: entry.centro,
        loja: entry.loja,
        streak: streak,
        total: recs.length,
        avgVd: avgVd,
        lastVd: lastRec.vd,
        lastDt: lastRec.dt,
        tail: tail,
        allRecs: recs
      });
    });

    if(!alerts.length){
      el.innerHTML =
        '<div style="font-size:17px;font-weight:700;letter-spacing:-.02em;margin-bottom:4px">⚠️ Alerta Inventário</div>'
        +'<p style="font-size:11px;color:var(--t3);margin-bottom:20px">Gerentes com Variação Desconhecida &lt; −1% nos últimos '+MIN_HITS+' inventários</p>'
        +'<div style="padding:40px;text-align:center;color:var(--t3);font-size:12px;background:var(--w);border:1px solid var(--bd);border-radius:8px">'
        +'✅ Nenhum gerente com '+MIN_HITS+' ou mais resultados consecutivos abaixo de −1%.</div>';
      return;
    }

    // Ordenar: maior streak primeiro, depois menor média de VD
    alerts.sort(function(a,b){
      if(b.streak !== a.streak) return b.streak - a.streak;
      return a.avgVd - b.avgVd;
    });

    // Agrupar por gerente
    var byGer = {};
    alerts.forEach(function(a){
      if(!byGer[a.gv]) byGer[a.gv] = [];
      byGer[a.gv].push(a);
    });

    // Stats de topo
    var totalLojas = alerts.length;
    var totalGers  = Object.keys(byGer).length;
    var worstStreak = alerts[0].streak;

    var html =
      '<div style="font-size:17px;font-weight:700;letter-spacing:-.02em;margin-bottom:4px">⚠️ Alerta Inventário — Quebras Desconhecidas Recorrentes</div>'
      +'<p style="font-size:11px;color:var(--t3);margin-bottom:16px">Gerentes com Variação Desconhecida &lt; −1% nos últimos '+MIN_HITS+' ou mais inventários consecutivos</p>'
      // Cards de resumo
      +'<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px">'
      + card('🔴', 'Lojas em alerta', totalLojas, '')
      + card('👤', 'Gerentes afectados', totalGers, '')
      + card('📉', 'Maior streak', worstStreak + ' consecutivos', '#c0392b')
      +'</div>';

    // Tabela por gerente
    Object.keys(byGer).sort().forEach(function(gv){
      var rows = byGer[gv];
      rows.sort(function(a,b){ return b.streak - a.streak || a.avgVd - b.avgVd; });

      html += '<div style="background:var(--w);border:1px solid var(--bd);border-radius:8px;overflow:hidden;margin-bottom:16px">'
        // Header do gerente
        +'<div style="padding:10px 16px;background:var(--s2);border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:10px">'
        +'<span style="font-size:13px;font-weight:700;color:var(--tx)">👤 '+gv+'</span>'
        +'<span style="font-size:10px;font-weight:600;color:var(--red);background:var(--rbg);padding:2px 8px;border-radius:10px">'+rows.length+' loja'+(rows.length>1?'s':'')+' em alerta</span>'
        +'</div>'
        // Tabela de lojas
        +'<div style="overflow-x:auto">'
        +'<table style="width:100%;border-collapse:collapse;font-size:11px">'
        +'<thead><tr style="background:var(--s2)">'
        +'<th style="padding:7px 12px;text-align:left;font-size:9px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid var(--bd)">Loja</th>'
        +'<th style="padding:7px 10px;text-align:center;font-size:9px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid var(--bd)">Streak</th>'
        +'<th style="padding:7px 10px;text-align:right;font-size:9px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid var(--bd)">Últ. VD%</th>'
        +'<th style="padding:7px 10px;text-align:right;font-size:9px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid var(--bd)">Média VD%</th>'
        +'<th style="padding:7px 10px;text-align:right;font-size:9px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid var(--bd)">Últ. Data</th>'
        +'<th style="padding:7px 12px;text-align:left;font-size:9px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid var(--bd)">Histórico (ult. '+MIN_HITS+')</th>'
        +'</tr></thead><tbody>';

      rows.forEach(function(a){
        var histDots = a.tail.map(function(r){
          var c = r.vd < -3 ? '#c0392b' : r.vd < -1 ? '#e67e22' : '#1a7040';
          return '<span title="'+fDate(r.dt)+': '+fPct(r.vd)+'" style="display:inline-block;width:28px;text-align:center;padding:2px 3px;border-radius:4px;font-size:9px;font-weight:700;color:#fff;background:'+c+';margin:1px">'+r.vd.toFixed(1)+'%</span>';
        }).join(' ');

        var streakColor = a.streak >= 6 ? '#c0392b' : a.streak >= 4 ? '#e67e22' : '#c47b00';

        html += '<tr style="border-bottom:1px solid var(--bd)">'
          +'<td style="padding:8px 12px;font-weight:600;white-space:nowrap"><span style="font-size:9px;color:var(--t3);margin-right:5px">'+a.centro+'</span>'+a.loja+'</td>'
          +'<td style="padding:8px 10px;text-align:center"><span style="font-weight:700;font-size:13px;color:'+streakColor+'">'+a.streak+'×</span></td>'
          +'<td style="padding:8px 10px;text-align:right;font-weight:700;color:#c0392b">'+fPct(a.lastVd)+'</td>'
          +'<td style="padding:8px 10px;text-align:right;color:#c0392b">'+fPct(a.avgVd)+'</td>'
          +'<td style="padding:8px 10px;text-align:right;color:var(--t2);white-space:nowrap">'+fDate(a.lastDt)+'</td>'
          +'<td style="padding:8px 12px">'+histDots+'</td>'
          +'</tr>';
      });

      html += '</tbody></table></div></div>';
    });

    el.innerHTML = html;
  };

  function card(icon, label, val, color){
    return '<div style="background:var(--w);border:1px solid var(--bd);border-radius:8px;padding:10px 16px;min-width:130px">'
      +'<div style="font-size:9px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.07em;margin-bottom:4px">'+icon+' '+label+'</div>'
      +'<div style="font-size:18px;font-weight:700;color:'+(color||'var(--tx)')+'">'+val+'</div>'
      +'</div>';
  }

})();
