
(function(){
function isoToday(offsetDays){
  var d=new Date(); d.setDate(d.getDate()+(offsetDays||0));
  // Usar hora local em vez de UTC para evitar desfasamento de fuso horário
  var y=d.getFullYear(), m=String(d.getMonth()+1).padStart(2,'0'), day=String(d.getDate()).padStart(2,'0');
  return y+'-'+m+'-'+day;
}
window.isoToday=isoToday;
window.dcfSetPeriod=function(days){
  document.getElementById('dcf-from').value=isoToday(-days+1);
  document.getElementById('dcf-to').value=isoToday(0);
  dcfHighlight('dcf-btn-'+days);
  _dcfRenderCore();
};
window.dcfSetDay=function(offset){
  var d=isoToday(offset);
  document.getElementById('dcf-from').value=d;
  document.getElementById('dcf-to').value=d;
  dcfHighlight(offset===0?'dcf-btn-hoje':'dcf-btn-ontem');
  _dcfRenderCore();
};
window.dcfHighlight=function dcfHighlight(activeId){
  ['dcf-btn-hoje','dcf-btn-ontem','dcf-btn-7','dcf-btn-14','dcf-btn-30'].forEach(function(id){
    var b=document.getElementById(id);if(!b)return;
    var on=(id===activeId);
    b.style.background=on?'var(--accent)':'var(--s2)';
    b.style.color=on?'#fff':'var(--t2)';
    b.style.borderColor=on?'var(--accent)':'var(--bd)';
  });
}
function computeLojaData(lojaCode,datas,contData,artigos,TURNOS){
  var datasSet={};
  datas.forEach(function(d){datasSet[d]=true;});
  var res={};
  artigos.forEach(function(a){res[a.id]={nome:a.nome,sku:a.sku,diffs:[],sumNeg:0,sumPos:0,count:0};});
  datas.forEach(function(date){
    if(!datasSet[date])return;
    var dayData=(contData[date]&&contData[date][lojaCode])||{};
    // Reset por dia e por artigo
    var prevQtd={};
    var prevVndAcum={};
    artigos.forEach(function(a){
      prevQtd[a.id]=null;
      prevVndAcum[a.id]=0;
    });
    TURNOS.forEach(function(t,ti){
      var entry=dayData[t.id]||{};
      artigos.forEach(function(a){
        var av=entry[a.id];
        var qtd=(av&&typeof av==='object'&&av.qtd!=null)?av.qtd:null;
        var vndTurnoA=(av&&typeof av==='object'&&ti>0)?(av.venda||0):0;
        // Manhã: referência, sem delta
        if(ti===0){
          if(qtd!==null) prevQtd[a.id]=qtd;
          return;
        }
        // Tarde / Noite: calcular delta apenas se temos prevQtd válido e qtd válida
        if(qtd!==null && prevQtd[a.id]!==null){
          var curEnt=(av&&typeof av==='object')?(av.entrada||0):0;
          var curQbr=(av&&typeof av==='object')?(av.quebra||0):0;
          // Vendas deste turno (campo directo, não acumulado)
          var vndTurno=Math.max(0, vndTurnoA);
          var esperado=prevQtd[a.id]+curEnt-curQbr-vndTurno;
          var delta=qtd-esperado;
          if(delta!==0){
            res[a.id].diffs.push({date:date,turno:t.id,delta:delta});
            res[a.id].count++;
            if(delta<0)res[a.id].sumNeg+=delta;
            else res[a.id].sumPos+=delta;
          }
        }
        // Actualizar referências para o próximo turno
        if(qtd!==null) prevQtd[a.id]=qtd;
      });
    });
  });
  return res;
}
window.difContagensRender=function(){
  var fromEl=document.getElementById('dcf-from');
  var toEl=document.getElementById('dcf-to');
  if(!fromEl||!toEl)return;
  if(!fromEl.value)fromEl.value=isoToday(0);
  if(!toEl.value)toEl.value=isoToday(0);
  _dcfRenderCore();
};

function _dcfGetLojaNome(code){
  var lojas=(typeof ADMCFG!=='undefined'&&ADMCFG&&ADMCFG.lojas)||[];
  var info=lojas.find(function(l){return l.c===code;});
  var nome=info&&info.n&&info.n!==code?info.n:null;
  if(!nome&&typeof D!=='undefined'&&D&&D.pao&&D.pao.lojas){
    var pl=D.pao.lojas.find(function(l){return l.c===code;});
    if(pl&&pl.n&&pl.n!==code) nome=pl.n;
  }
  return nome||code;
}

window._dcfRenderCore=function _dcfRenderCore(){
  var fromEl=document.getElementById('dcf-from');
  var toEl=document.getElementById('dcf-to');
  var kpisEl=document.getElementById('dcf-kpis');
  var tableEl=document.getElementById('dcf-table');
  if(!fromEl||!toEl||!kpisEl||!tableEl)return;

  var fromDate=fromEl.value||isoToday(0);
  var toDate=toEl.value||isoToday(0);

  // Validação de datas: intervalo invertido ou datas inválidas
  var errEl=document.getElementById('dcf-date-err');
  if(fromDate>toDate){
    if(errEl){errEl.textContent='⚠ Data inicial é posterior à data final.';errEl.style.display='block';}
    kpisEl.innerHTML='';
    tableEl.innerHTML='<div style="padding:20px;text-align:center;color:var(--red);font-size:12px">Intervalo de datas inválido — a data inicial deve ser anterior ou igual à data final.</div>';
    return;
  }
  // Intervalo máximo de 366 dias para evitar sobrecarga
  var msRange=new Date(toDate+'T00:00:00')-new Date(fromDate+'T00:00:00');
  if(msRange>366*24*60*60*1000){
    if(errEl){errEl.textContent='⚠ Intervalo máximo: 366 dias.';errEl.style.display='block';}
    tableEl.innerHTML='<div style="padding:20px;text-align:center;color:var(--amber);font-size:12px">Selecione um intervalo máximo de 366 dias.</div>';
    return;
  }
  if(errEl){errEl.textContent='';errEl.style.display='none';}

  kpisEl.innerHTML='';
  tableEl.innerHTML='<div style="padding:30px;text-align:center;color:var(--t3);font-size:12px">⏳ A carregar…</div>';

  var filterEl=document.getElementById('dcf-filter');
  var sortEl=document.getElementById('dcf-sort');
  var filterMode=filterEl?filterEl.value:'all';
  var sortMode=sortEl?sortEl.value:'total';
  var cfg=window.CONT_CFG||contCfgLoad();
  var artigos=(cfg.artigos||[]).filter(function(a){return a.ativo!==false;});
  var TURNOS=window.TURNOS||[{id:'manha'},{id:'tarde'},{id:'noite'}];

  var contData=window.CONT_DATA||contDataLoad()||{};

  // Build date list
  var datas=[],cur=new Date(fromDate+'T00:00:00'),end=new Date(toDate+'T00:00:00');
  while(cur<=end){datas.push(cur.toISOString().split('T')[0]);cur.setDate(cur.getDate()+1);}

  // Find lojas with real data in period
  var lojaCodesInData={};
  datas.forEach(function(d){
    if(!contData[d])return;
    Object.keys(contData[d]).forEach(function(c){
      var lojaDay=contData[d][c];
      var hasReal=Object.keys(lojaDay).some(function(turnoId){
        var entry=lojaDay[turnoId];
        if(!entry||typeof entry!=='object')return false;
        return Object.keys(entry).some(function(artId){
          if(artId==='__nota__'||artId==='__ts__'||artId==='__ts_edit__')return false;
          var av=entry[artId];
          return av&&typeof av==='object'&&av.qtd!=null;
        });
      });
      if(hasReal) lojaCodesInData[c]=true;
    });
  });

  var allCodes=Object.keys(lojaCodesInData);
  if(!allCodes.length){
    kpisEl.innerHTML='';
    // Mostrar todas as datas com dados para ajudar o utilizador
    var allDatasComDados=Object.keys(contData).sort().reverse().slice(0,5);
    var sugestao=allDatasComDados.length?'<div style="margin-top:10px;font-size:11px;color:var(--t3)">Últimas datas com dados: '+allDatasComDados.join(', ')+'</div>':'';
    tableEl.innerHTML='<div style="padding:40px;text-align:center"><div style="font-size:32px;margin-bottom:12px">📋</div><div style="font-size:14px;font-weight:600;color:var(--tx);margin-bottom:6px">Sem contagens no período seleccionado</div><div style="font-size:12px;color:var(--t2)">Não existem contagens registadas entre '+fromDate+' e '+toDate+'.</div>'+sugestao+'</div>';
    return;
  }

  var lojaRows=[];
  allCodes.forEach(function(code){
    var lojaNomeDisplay=_dcfGetLojaNome(code);
    var artigosLoja=artigos.filter(function(a){
      if(!a.lojas||!a.lojas.length)return true;
      return a.lojas.indexOf(code)>=0;
    });
    // Fallback: reconstruir artigos a partir dos dados gravados
    if(!artigosLoja.length){
      var artIdsSeen={};
      datas.forEach(function(d){
        var lojaDay=(contData[d]&&contData[d][code])||{};
        Object.keys(lojaDay).forEach(function(turnoId){
          var entry=lojaDay[turnoId]||{};
          Object.keys(entry).forEach(function(artId){
            if(artId==='__nota__'||artId==='__ts__'||artId==='__ts_edit__')return;
            artIdsSeen[artId]=true;
          });
        });
      });
      artigosLoja=Object.keys(artIdsSeen).map(function(id){
        var cfgArt=artigos.find(function(a){return a.id===id;});
        return cfgArt||{id:id,nome:id,sku:''};
      });
    }
    if(!artigosLoja.length)return;

    var artData=computeLojaData(code,datas,contData,artigosLoja,TURNOS);
    var artRows=[];
    artigosLoja.forEach(function(a){
      var ad=artData[a.id];if(!ad)return;
      if(filterMode==='neg'&&ad.sumNeg===0)return;
      if(filterMode==='pos'&&ad.sumPos===0)return;
      if(filterMode==='all'&&ad.count===0)return;
      artRows.push({id:a.id,nome:a.nome,sku:a.sku,sumNeg:ad.sumNeg,sumPos:ad.sumPos,totalAbs:Math.abs(ad.sumNeg)+ad.sumPos,count:ad.count,diffs:ad.diffs});
    });
    var lojaTotal=artRows.reduce(function(s,r){return s+r.totalAbs;},0);
    var lojaNeg=artRows.reduce(function(s,r){return s+r.sumNeg;},0);
    var lojaPos=artRows.reduce(function(s,r){return s+r.sumPos;},0);
    var lojaCount=artRows.reduce(function(s,r){return s+r.count;},0);
    if(lojaTotal===0&&lojaCount===0)return;
    lojaRows.push({code:code,nome:lojaNomeDisplay,artRows:artRows,lojaTotal:lojaTotal,lojaNeg:lojaNeg,lojaPos:lojaPos,lojaCount:lojaCount});
  });

  lojaRows.sort(function(a,b){
    if(sortMode==='total')return b.lojaTotal-a.lojaTotal;
    if(sortMode==='neg')return a.lojaNeg-b.lojaNeg;
    if(sortMode==='count')return b.lojaCount-a.lojaCount;
    return a.nome.localeCompare(b.nome);
  });

  var totalNeg=lojaRows.reduce(function(s,r){return s+r.lojaNeg;},0);
  var totalPos=lojaRows.reduce(function(s,r){return s+r.lojaPos;},0);
  var totalOcorr=lojaRows.reduce(function(s,r){return s+r.lojaCount;},0);

  kpisEl.innerHTML=[
    {label:'Lojas com diferenças',val:lojaRows.length,color:'var(--tx)',pref:'',suf:''},
    {label:'Total ocorrências',val:totalOcorr,color:'var(--tx)',pref:'',suf:''},
    {label:'Soma perdas (Δ−)',val:totalNeg,color:'var(--red)',pref:'',suf:' un'},
    {label:'Soma excessos (Δ+)',val:totalPos,color:'var(--blue)',pref:'+',suf:' un'}
  ].map(function(k){
    return '<div style="background:var(--w);border:1px solid var(--bd);border-radius:12px;padding:16px 18px;box-shadow:var(--sh-sm)">'
      +'<div style="font-size:10px;font-weight:600;color:var(--t3);text-transform:uppercase;letter-spacing:.07em;margin-bottom:8px">'+k.label+'</div>'
      +'<div style="font-size:22px;font-weight:700;color:'+k.color+';font-family:var(--mono)">'+k.pref+k.val+k.suf+'</div>'
      +'</div>';
  }).join('');

  if(!lojaRows.length){
    tableEl.innerHTML='<div style="padding:40px;text-align:center;color:var(--t3);font-size:13px">Sem diferenças com os filtros seleccionados.</div>';
    return;
  }

  var tableHtml='';
  lojaRows.forEach(function(lr,li){
    var negCol=lr.lojaNeg<0?'var(--red)':'var(--t3)';
    var posCol=lr.lojaPos>0?'var(--blue)':'var(--t3)';
    var blockId='dcf-block-'+li;
    var cardId='dcf-card-'+li;
    tableHtml+='<div id="'+cardId+'" style="background:var(--w);border:1px solid var(--bd);border-radius:10px;overflow:hidden;margin-bottom:10px">';
    tableHtml+='<div style="display:grid;grid-template-columns:1fr auto auto auto auto auto;gap:12px;align-items:center;padding:10px 16px;background:var(--s2);border-bottom:1px solid var(--bd)">';
    tableHtml+='<div onclick="dcfToggle(\''+blockId+'\')" style="cursor:pointer;display:flex;align-items:center;gap:8px;user-select:none;min-width:0">'
      +'<span id="dcf-arr-'+li+'" style="font-size:11px;color:var(--t3);transition:transform .2s;flex-shrink:0">▶</span>'
      +'<div style="min-width:0">'
      +'<div style="font-size:13px;font-weight:700;color:var(--tx);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+escHtml(lr.nome)+'</div>'
      +'<div style="font-size:10px;color:var(--t3);font-family:var(--mono)">'+lr.code+'</div>'
      +'</div></div>';
    tableHtml+='<div onclick="dcfToggle(\''+blockId+'\')" style="cursor:pointer;text-align:right;user-select:none"><div style="font-size:9px;color:var(--t3);text-transform:uppercase;margin-bottom:2px">Artigos</div><div style="font-size:14px;font-weight:700;color:var(--tx)">'+lr.artRows.length+'</div></div>';
    tableHtml+='<div onclick="dcfToggle(\''+blockId+'\')" style="cursor:pointer;text-align:right;user-select:none"><div style="font-size:9px;color:var(--t3);text-transform:uppercase;margin-bottom:2px">Ocorrências</div><div style="font-size:14px;font-weight:700;color:var(--tx)">'+lr.lojaCount+'</div></div>';
    tableHtml+='<div onclick="dcfToggle(\''+blockId+'\')" style="cursor:pointer;text-align:right;user-select:none"><div style="font-size:9px;color:var(--red);text-transform:uppercase;margin-bottom:2px">Σ Perdas</div><div style="font-size:14px;font-weight:700;color:'+negCol+'">'+(lr.lojaNeg<0?lr.lojaNeg:'—')+' un</div></div>';
    tableHtml+='<div onclick="dcfToggle(\''+blockId+'\')" style="cursor:pointer;text-align:right;user-select:none"><div style="font-size:9px;color:var(--blue);text-transform:uppercase;margin-bottom:2px">Σ Excessos</div><div style="font-size:14px;font-weight:700;color:'+posCol+'">'+(lr.lojaPos>0?'+'+lr.lojaPos:'—')+' un</div></div>';
    tableHtml+='<button onclick="dcfCopyImg(\''+cardId+'\',\''+escHtml(lr.nome)+'\',event)" title="Copiar como imagem" style="flex-shrink:0;padding:5px 10px;font-size:11px;border:1px solid var(--bd);border-radius:5px;background:var(--w);color:var(--t2);cursor:pointer;font-family:inherit;display:flex;align-items:center;gap:4px;white-space:nowrap"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>Copiar</button>';
    tableHtml+='</div>';
    tableHtml+='<div id="'+blockId+'" style="display:none">';
    tableHtml+='<div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr 3fr;background:var(--s2);border-bottom:1px solid var(--bd)">';
    ['Artigo','Δ− Perdas','Δ+ Excessos','Ocorr.','Ocorrências recentes (data · turno · Δ)'].forEach(function(h,hi){
      tableHtml+='<div style="padding:6px 12px;font-size:9.5px;font-weight:700;color:var(--t3);text-transform:uppercase;'+(hi>0?'text-align:right':'')+'">'+h+'</div>';
    });
    tableHtml+='</div>';
    lr.artRows.slice().sort(function(a,b){return b.totalAbs-a.totalAbs;}).forEach(function(ar,ai){
      var rowBg=ai%2===0?'':'background:var(--s2)';
      var negC=ar.sumNeg<0?'var(--red)':'var(--t3)';
      var posC=ar.sumPos>0?'var(--blue)':'var(--t3)';
      var chips=ar.diffs.slice(-8).map(function(d){
        var c=d.delta<0?'var(--red)':'var(--blue)';
        var bg=d.delta<0?'var(--rbg)':'var(--bbg)';
        var sign=d.delta>0?'+':'';
        var ts={manha:'M',tarde:'T',noite:'N'}[d.turno]||d.turno;
        return '<span style="display:inline-flex;align-items:center;gap:2px;font-size:9.5px;font-weight:600;color:'+c+';background:'+bg+';border-radius:3px;padding:1px 5px;white-space:nowrap">'+d.date.slice(5)+' '+ts+' '+sign+d.delta+'</span>';
      }).join(' ');
      if(ar.diffs.length>8)chips+=' <span style="font-size:9px;color:var(--t3)">+more</span>';
      tableHtml+='<div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr 3fr;align-items:center;border-bottom:1px solid var(--bd);'+rowBg+'">';
      tableHtml+='<div style="padding:7px 12px"><div style="font-size:12px;font-weight:500;color:var(--tx)">'+escHtml(ar.nome)+'</div>'+(ar.sku?'<div style="font-size:10px;color:var(--t3)">SKU '+ar.sku+'</div>':'')+'</div>';
      tableHtml+='<div style="padding:7px 12px;text-align:right;font-size:12px;font-weight:700;color:'+negC+'">'+(ar.sumNeg<0?ar.sumNeg+' un':'—')+'</div>';
      tableHtml+='<div style="padding:7px 12px;text-align:right;font-size:12px;font-weight:700;color:'+posC+'">'+(ar.sumPos>0?'+'+ar.sumPos+' un':'—')+'</div>';
      tableHtml+='<div style="padding:7px 12px;text-align:right;font-size:12px;font-weight:600;color:var(--tx)">'+ar.count+'×</div>';
      tableHtml+='<div style="padding:7px 12px;display:flex;flex-wrap:wrap;gap:4px">'+chips+'</div>';
      tableHtml+='</div>';
    });
    tableHtml+='</div></div>';
  });
  tableEl.innerHTML=tableHtml;
}
window.dcfToggle=function(id){
  var el=document.getElementById(id);if(!el)return;
  var li=id.replace('dcf-block-','');
  var arr=document.getElementById('dcf-arr-'+li);
  var open=el.style.display==='none';
  el.style.display=open?'block':'none';
  if(arr)arr.style.transform=open?'rotate(90deg)':'rotate(0deg)';
};
window.dcfCopyImg=function(cardId,nomeLoja,evt){
  if(evt)evt.stopPropagation();
  var card=document.getElementById(cardId);
  if(!card){alert('Elemento não encontrado.');return;}
  // Ensure block is visible for capture
  var blockId=cardId.replace('dcf-card-','dcf-block-');
  var block=document.getElementById(blockId);
  var wasHidden=block&&block.style.display==='none';
  if(wasHidden){block.style.display='block';}
  // Use html2canvas
  if(typeof html2canvas==='undefined'){
    var s=document.createElement('script');
    s.src='https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
    s.onload=function(){_dcfDoCapture(card,nomeLoja,block,wasHidden);};
    document.head.appendChild(s);
  } else {
    _dcfDoCapture(card,nomeLoja,block,wasHidden);
  }
};
window._dcfDoCapture=function(card,nomeLoja,block,wasHidden){
  html2canvas(card,{scale:2,backgroundColor:'#ffffff',useCORS:true,logging:false}).then(function(canvas){
    if(wasHidden&&block)block.style.display='none';
    canvas.toBlob(function(blob){
      if(navigator.clipboard&&navigator.clipboard.write){
        navigator.clipboard.write([new ClipboardItem({'image/png':blob})]).then(function(){
          _dcfToast('✓ Imagem copiada — '+nomeLoja);
        }).catch(function(){_dcfDownload(canvas,nomeLoja);});
      } else {
        _dcfDownload(canvas,nomeLoja);
      }
    },'image/png');
  }).catch(function(e){
    if(wasHidden&&block)block.style.display='none';
    alert('Erro ao capturar: '+e.message);
  });
};
window._dcfDownload=function(canvas,nome){
  var a=document.createElement('a');
  a.download=(nome||'loja').replace(/[^a-z0-9]/gi,'_')+'.png';
  a.href=canvas.toDataURL('image/png');
  a.click();
  _dcfToast('✓ Imagem guardada — '+(nome||'loja'));
};
window._dcfToast=function(msg){
  var t=document.createElement('div');
  t.textContent=msg;
  t.style.cssText='position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#1a1a2e;color:#fff;padding:10px 20px;border-radius:8px;font-size:13px;z-index:99999;box-shadow:0 4px 16px rgba(0,0,0,.3);pointer-events:none';
  document.body.appendChild(t);
  setTimeout(function(){t.remove();},2500);
};
  function _dcfInit(){
    var f=document.getElementById('dcf-from'),t=document.getElementById('dcf-to');
    var today=isoToday(0);
    if(f&&!f.value)f.value=today;
    if(t&&!t.value)t.value=today;
    if(typeof dcfHighlight==='function')dcfHighlight('dcf-btn-hoje');
    ['dcf-from','dcf-to'].forEach(function(id){
      var el=document.getElementById(id);
      if(el)el.addEventListener('change',function(){if(typeof _dcfRenderCore==='function')_dcfRenderCore();});
    });
  }
  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',_dcfInit);
  } else {
    _dcfInit();
  }
})();


// ══════════════════════════════════════════════════════════════════════════════
// DCG — ANÁLISE DE DIFERENÇAS DE CONTAGENS
// ══════════════════════════════════════════════════════════════════════════════

var _dcgPeriodDays = 7;

function _dcgTurnos() {
  try {
    if (window.TURNOS && window.TURNOS.length) return window.TURNOS;
    if (typeof TURNOS !== 'undefined' && TURNOS && TURNOS.length) return TURNOS;
  } catch(e) {}
  return [
    {id:'manha', label:'Manhã', hora:'07:00'},
    {id:'tarde', label:'Tarde', hora:'14:00'},
    {id:'noite', label:'Noite', hora:'21:30'}
  ];
}

function _dcgDates(days) {
  var d = days || _dcgPeriodDays;
  var arr = [];
  for (var i = d - 1; i >= 0; i--) arr.push(isoToday(-i));
  return arr;
}

function _dcgGetArtigos() {
  var cfg = window.CONT_CFG || contCfgLoad();
  return (cfg.artigos || []).filter(function(a) { return a.ativo !== false; });
}

function _dcgGetLojas() {
  var base = (window.ADMCFG && ADMCFG.lojas) || [];
  if (!base.length) return base;
  var lojaNome = (typeof ART_INV !== 'undefined' && ART_INV && ART_INV.loja_name) || {};
  return base.map(function(l) {
    if (l.n && l.n !== l.c) return l;
    // fallback 1: DB
    var nome = (typeof DB !== 'undefined' && DB && DB[l.c] && DB[l.c].n !== l.c) ? DB[l.c].n : null;
    // fallback 2: ART_INV.loja_name
    if (!nome) nome = lojaNome[l.c] || null;
    return nome ? Object.assign({}, l, {n: nome}) : l;
  });
}

function _dcgNomeLoja(code) {
  // 1. ADMCFG.lojas
  var lojas = (window.ADMCFG && ADMCFG.lojas) || [];
  var l = lojas.find(function(x) { return x.c === code; });
  if (l && l.n && l.n !== code) return l.n;
  // 2. DB global
  if (typeof DB !== 'undefined' && DB && DB[code] && DB[code].n && DB[code].n !== code) return DB[code].n;
  // 3. ART_INV loja_name
  if (typeof ART_INV !== 'undefined' && ART_INV && ART_INV.loja_name && ART_INV.loja_name[code]) return ART_INV.loja_name[code];
  return code;
}

function _dcgHlBtn(prefix, active) {
  [7, 14, 30].forEach(function(d) {
    var b = document.getElementById(prefix + d);
    if (!b) return;
    var on = d === active;
    b.style.background = on ? 'var(--accent)' : 'var(--s2)';
    b.style.color = on ? '#fff' : 'var(--t2)';
    b.style.borderColor = on ? 'var(--accent)' : 'var(--bd)';
  });
}

window.dcgSwitch = function(tab) {
  ['dia', 'ranking', 'tendencia', 'calor', 'semcont', 'relcont'].forEach(function(t) {
    var pane = document.getElementById('dcg-' + t);
    var btn  = document.getElementById('dcg-tab-' + t);
    if (pane) pane.style.display = t === tab ? '' : 'none';
    if (btn) {
      btn.style.borderBottomColor = t === tab ? 'var(--accent)' : 'transparent';
      btn.style.color = t === tab ? 'var(--accent)' : (t === 'semcont' ? 'var(--amber)' : 'var(--t2)');
    }
  });
  if (tab === 'dia')      dcgDiaRender();
  if (tab === 'ranking')  { _dcgFillArtSelect('dcg-rank-art'); dcgRankingRender(); }
  if (tab === 'tendencia'){ _dcgFillArtSelect('dcg-tend-art'); _dcgFillLojaSelect('dcg-tend-loja'); dcgTendenciaRender(); }
  if (tab === 'calor')    dcgCaiorRender();
  if (tab === 'semcont')  dcgSemContRender();
  if (tab === 'relcont')  dcgRelContRender();
};

window.dcgPeriod = function(days) {
  _dcgPeriodDays = days;
  ['p','tp','cp'].forEach(function(p){ _dcgHlBtn('dcg-' + p, days); });
  var tab = document.getElementById('dcg-ranking');
  if (tab && tab.style.display !== 'none') dcgRankingRender();
  tab = document.getElementById('dcg-tendencia');
  if (tab && tab.style.display !== 'none') dcgTendenciaRender();
  tab = document.getElementById('dcg-calor');
  if (tab && tab.style.display !== 'none') dcgCaiorRender();
};

window.dcgDiaSetDay = function(offset) {
  var el = document.getElementById('dcg-dia-date');
  if (el) el.value = isoToday(offset);
  dcgDiaRender();
};

// ── Sem Contagem ─────────────────────────────────────────────────────────────
window.dcgScSetDay = function(offset) {
  var el = document.getElementById('dcg-sc-date');
  if (el) el.value = isoToday(offset);
  dcgSemContRender();
};

window.dcgSemContRender = function() {
  var dateEl  = document.getElementById('dcg-sc-date');
  var turnoEl = document.getElementById('dcg-sc-turno');
  var body    = document.getElementById('dcg-sc-body');
  var ctEl    = document.getElementById('dcg-sc-ct');
  if (!body) return;

  // Inicializa data se vazio
  if (dateEl && !dateEl.value) dateEl.value = isoToday(0);
  var date   = dateEl ? dateEl.value : isoToday(0);
  var turnoF = turnoEl ? turnoEl.value : '';

  var TURNOS_SC = window.TURNOS || [{id:'manha',label:'Manhã'},{id:'tarde',label:'Tarde'},{id:'noite',label:'Noite'}];
  var turnosToCheck = turnoF ? TURNOS_SC.filter(function(t){ return t.id === turnoF; }) : TURNOS_SC;

  // Lojas activas
  var mes = date.substring(0, 7);
  var lojas = Object.keys(window.DB || {}).filter(function(c) {
    return typeof isLojaActiva !== 'function' || isLojaActiva(c, mes);
  }).sort();

  var contData = window.CONT_DATA || {};
  var dayData  = contData[date] || {};

  // Para cada loja × turno verificar se existe registo com pelo menos 1 artigo
  function hasCont(loja, turno) {
    var t = (dayData[loja] || {})[turno.id];
    if (!t) return false;
    // value pode ser objecto de artigos; consideramos preenchido se tem pelo menos 1 chave com valor
    return Object.keys(t).some(function(k) {
      return k !== '_ts' && k !== '_saved' && t[k] != null;
    });
  }

  // Construir lista: lojas que NÃO preencheram pelo menos 1 dos turnos filtrados
  var missing = []; // [{loja, nome, sup, turnos:[{id,label,ok}]}]
  lojas.forEach(function(c) {
    var st = (window.DB || {})[c] || {};
    var turnosInfo = turnosToCheck.map(function(t) {
      return { id: t.id, label: t.label || t.id, ok: hasCont(c, t) };
    });
    var anyMissing = turnosInfo.some(function(t){ return !t.ok; });
    if (!anyMissing) return; // todos preenchidos — ignorar
    missing.push({
      c: c,
      n: st.n || c,
      sup: st.s || (typeof supervisorDaLoja === 'function' ? supervisorDaLoja(c) : '') || '—',
      turnos: turnosInfo
    });
  });

  if (ctEl) ctEl.textContent = missing.length + ' loja' + (missing.length !== 1 ? 's' : '') + ' sem contagem · ' + date;

  if (!missing.length) {
    body.innerHTML = '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px;gap:10px;color:var(--green)">'
      + '<svg width="40" height="40" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="10"/></svg>'
      + '<div style="font-size:14px;font-weight:600">Todas as lojas preencheram</div>'
      + '<div style="font-size:12px;color:var(--t3)">Contagens do dia ' + date + ' completas</div>'
      + '</div>';
    return;
  }

  // Tabela
  var turnoHeaders = turnosToCheck.map(function(t) {
    return '<th style="padding:8px 14px;font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--t3);background:var(--s2);border-bottom:1px solid var(--bd);text-align:center">'
      + (t.label || t.id) + '</th>';
  }).join('');

  var rows = missing.map(function(r) {
    var turnosCells = r.turnos.map(function(t) {
      return '<td style="padding:7px 14px;text-align:center;border-bottom:1px solid var(--bd)">'
        + (t.ok
            ? '<span style="color:var(--green);font-size:13px">✓</span>'
            : '<span style="color:var(--red);font-weight:700;font-size:13px">✗</span>')
        + '</td>';
    }).join('');
    return "<tr style='transition:background .07s' onmouseover=\"this.style.background='var(--s2)'\" onmouseout=\"this.style.background=''\">" + 
      + '<td style="padding:7px 14px;font-size:12px;font-weight:600;color:var(--t2);border-bottom:1px solid var(--bd);font-family:var(--mono)">' + r.c + '</td>'
      + '<td style="padding:7px 14px;font-size:12.5px;color:var(--tx);border-bottom:1px solid var(--bd)">' + r.n + '</td>'
      + '<td style="padding:7px 14px;font-size:12px;color:var(--t2);border-bottom:1px solid var(--bd)">' + r.sup + '</td>'
      + turnosCells
      + '</tr>';
  }).join('');

  body.innerHTML = '<div style="overflow-x:auto">'
    + '<table style="width:100%;border-collapse:collapse;min-width:500px">'
    + '<thead><tr>'
    + '<th style="padding:8px 14px;font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--t3);background:var(--s2);border-bottom:1px solid var(--bd);text-align:left">Centro</th>'
    + '<th style="padding:8px 14px;font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--t3);background:var(--s2);border-bottom:1px solid var(--bd);text-align:left">Loja</th>'
    + '<th style="padding:8px 14px;font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--t3);background:var(--s2);border-bottom:1px solid var(--bd);text-align:left">Supervisor</th>'
    + turnoHeaders
    + '</tr></thead>'
    + '<tbody>' + rows + '</tbody>'
    + '</table></div>';
};

function _dcgFillArtSelect(id) {
  var sel = document.getElementById(id); if (!sel) return;
  if (sel.options.length > 1) return; // já populado
  _dcgGetArtigos().forEach(function(a) {
    var o = document.createElement('option');
    o.value = a.id; o.textContent = a.nome || a.id;
    sel.appendChild(o);
  });
}

function _dcgFillLojaSelect(id) {
  var sel = document.getElementById(id); if (!sel) return;
  if (sel.options.length > 1) return;
  var contData = window.CONT_DATA || contDataLoad();
  var lojasComDados = new Set();
  Object.values(contData).forEach(function(dia) { Object.keys(dia).forEach(function(c){ lojasComDados.add(c); }); });
  _dcgGetLojas().filter(function(l){ return lojasComDados.has(l.c); }).forEach(function(l) {
    var o = document.createElement('option');
    o.value = l.c; o.textContent = l.n || l.c;
    sel.appendChild(o);
  });
}

// ── Vista Diária: tabela loja × artigo ───────────────────────────────────────
window.dcgDiaRender = function() {
  var dateEl = document.getElementById('dcg-dia-date');
  var body   = document.getElementById('dcg-dia-body');
  var ctEl   = document.getElementById('dcg-dia-ct');
  if (!body) return;

  if (!dateEl || !dateEl.value) {
    if (dateEl) dateEl.value = isoToday(0);
  }
  var date = dateEl ? dateEl.value : isoToday(0);
  var filterMode = (document.getElementById('dcg-dia-filter') || {}).value || 'all';

  var contData = window.CONT_DATA || contDataLoad();
  var artigos  = _dcgGetArtigos();
  var dayData  = contData[date] || {};

  // Construir lista de lojas: combinar ADMCFG com lojas que têm dados no dia
  var lojasMap = {};
  (_dcgGetLojas() || []).forEach(function(l){ lojasMap[l.c] = l; });
  // Incluir também lojas com dados mas não em ADMCFG — tentar obter nome do DB
  Object.keys(dayData).forEach(function(c){
    if (!lojasMap[c]) {
      var nome = _dcgNomeLoja(c);
      // Tentar também pelo DB global
      if (nome === c && typeof DB !== 'undefined' && DB && DB[c] && DB[c].n) nome = DB[c].n;
      lojasMap[c] = { c: c, n: nome };
    }
  });
  // Para lojas sem nome (n === c ou n vazio), tentar obter do DB
  Object.values(lojasMap).forEach(function(l) {
    if ((!l.n || l.n === l.c) && typeof DB !== 'undefined' && DB && DB[l.c] && DB[l.c].n) {
      l.n = DB[l.c].n;
    }
  });
  var lojas = Object.values(lojasMap);

  // Calcular diffs por loja × artigo para esse dia
  var rows = [];
  lojas.forEach(function(l) {
    var ld = dayData[l.c];
    if (!ld) return;
    var lArts = artigos.filter(function(a){ return !a.lojas||!a.lojas.length||a.lojas.indexOf(l.c)>=0; });
    var artDiffs = {};
    var hasDiff = false;
    lArts.forEach(function(a) {
      var prevQtd = null, prevVnd = 0;
      var turnoDiffs = [];
      _dcgTurnos().forEach(function(t, ti) {
        var av = (ld[t.id] || {})[a.id];
        var qtd    = (av && typeof av === 'object' && av.qtd != null) ? av.qtd : null;
        var vndAcum= (av && typeof av === 'object') ? (av.venda || 0) : 0;
        var ent    = (av && typeof av === 'object') ? (av.entrada || 0) : 0;
        var qbr    = (av && typeof av === 'object') ? (av.quebra || 0) : 0;
        if (ti === 0) { if (qtd !== null) prevQtd = qtd; prevVnd = vndAcum; return; }
        if (qtd !== null && prevQtd !== null) {
          var vndT = Math.max(0, vndAcum - prevVnd);
          var esp  = prevQtd + ent - qbr - vndT;
          var delta = qtd - esp;
          var just = (av && typeof av === 'object') ? (av.__just__ || '') : '';
          turnoDiffs.push({ turno: t.label, delta: delta, qtd: qtd, esp: Math.round(esp * 100) / 100, just: just });
          if (delta !== 0) hasDiff = true;
        }
        if (qtd !== null) prevQtd = qtd;
        prevVnd = vndAcum;
      });
      var sumNeg = turnoDiffs.reduce(function(s,x){ return s + (x.delta < 0 ? x.delta : 0); }, 0);
      var sumPos = turnoDiffs.reduce(function(s,x){ return s + (x.delta > 0 ? x.delta : 0); }, 0);
      if (turnoDiffs.some(function(x){ return x.delta !== 0; }) || filterMode === 'any') {
        artDiffs[a.id] = { nome: a.nome, sku: a.sku, turnos: turnoDiffs, sumNeg: sumNeg, sumPos: sumPos };
      }
    });

    var anyDiff = Object.values(artDiffs).some(function(x){ return x.sumNeg < 0 || x.sumPos > 0; });
    if (filterMode === 'neg' && !Object.values(artDiffs).some(function(x){ return x.sumNeg < 0; })) return;
    if (filterMode === 'all' && !hasDiff) return;
    if (filterMode === 'any' && !Object.keys(artDiffs).length) return;

    var totalNeg = Object.values(artDiffs).reduce(function(s,x){ return s + x.sumNeg; }, 0);
    var totalPos = Object.values(artDiffs).reduce(function(s,x){ return s + x.sumPos; }, 0);
    rows.push({ c: l.c, n: _dcgNomeLoja(l.c) || l.n || l.c, artDiffs: artDiffs, totalNeg: totalNeg, totalPos: totalPos });
  });

  rows.sort(function(a, b){ return a.totalNeg - b.totalNeg; });

  if (!rows.length) {
    var _keys = Object.keys(contData);
    var _dayKeys = Object.keys(dayData);
    var _artN = artigos.length;
    var _diag = 'Sem diferenças para ' + date
      + ' · CONT_DATA tem ' + _keys.length + ' datas'
      + (_keys.length ? ' (' + _keys.slice(0,3).join(', ') + (_keys.length>3?'…':'') + ')' : '')
      + ' · ' + _dayKeys.length + ' lojas neste dia'
      + ' · ' + _artN + ' artigos configurados';
    body.innerHTML = '<div style="padding:32px;text-align:center;color:var(--t3);font-size:11px">' + _diag + '</div>';
    if (ctEl) ctEl.textContent = '';
    return;
  }

  if (ctEl) ctEl.textContent = rows.length + ' lojas · ' + date;

  var tdH = 'padding:6px 10px;font-size:9.5px;font-weight:700;color:var(--t3);text-transform:uppercase;background:var(--s2);border-bottom:1px solid var(--bd);text-align:';
  var td  = 'padding:5px 10px;font-size:11px;border-bottom:1px solid var(--bd);';

  var html = '<div style="overflow-x:auto">';
  rows.forEach(function(row) {
    var artRows = Object.values(row.artDiffs);
    if (filterMode === 'neg') artRows = artRows.filter(function(x){ return x.sumNeg < 0; });
    if (!artRows.length) return;

    html += '<details open data-dcg-loja="' + escHtml(row.c) + '" data-dcg-nome="' + escHtml(row.n || row.c) + '" style="margin-bottom:12px;border:1px solid var(--bd);border-radius:8px;overflow:hidden">'
          + '<summary style="padding:8px 14px;font-size:12px;font-weight:600;background:var(--s2);cursor:pointer;display:flex;align-items:center;gap:12px">'
          + '<span style="font-family:monospace;font-size:10px;color:var(--t3)">' + row.c + '</span>'
          + '<span>' + row.n + '</span>'
          + (row.totalNeg < 0 ? '<span style="margin-left:auto;color:var(--red);font-weight:700">' + row.totalNeg.toFixed(0) + '</span>' : '<span style="margin-left:auto"></span>')
          + (row.totalPos > 0 ? '<span style="color:var(--blue);font-weight:600;margin-left:8px">+' + row.totalPos.toFixed(0) + '</span>' : '')
          + '<button type="button" class="dcg-pop-btn" onclick="event.preventDefault();event.stopPropagation();dcgOpenLojaPopup(\'' + escHtml(row.c) + '\')">🔎 Abrir relatório</button>'
          + '</summary>'
          + '<table style="width:100%;border-collapse:collapse">'
          + '<thead><tr>'
          + '<th style="' + tdH + 'left">Artigo</th>'
          + '<th style="' + tdH + 'left">SKU</th>'
          + _dcgTurnos().slice(1).map(function(t){ return '<th style="' + tdH + 'center" colspan="2">' + t.label + '</th>'; }).join('')
          + '<th style="' + tdH + 'center">Δ−</th>'
          + '<th style="' + tdH + 'center">Δ+</th>'
          + '</tr></thead><tbody>';

    artRows.sort(function(a,b){ return a.sumNeg - b.sumNeg; }).forEach(function(art) {
      html += '<tr>'
            + '<td style="' + td + 'left;font-weight:500">' + (art.nome || art.id) + '</td>'
            + '<td style="' + td + 'left;font-family:monospace;font-size:10px;color:var(--t3)">' + (art.sku || '—') + '</td>';
      art.turnos.forEach(function(t) {
        var col = t.delta < -0.05 ? 'color:var(--red);font-weight:700' : t.delta > 0.05 ? 'color:var(--blue);font-weight:600' : 'color:var(--t3)';
        var deltaStr = t.delta === 0 ? '—' : (t.delta > 0 ? '+' : '') + t.delta.toFixed(1);
        var justHtml = (t.just && t.delta !== 0) ? '<div title="'+escHtml(t.just)+'" style="font-size:8px;color:var(--t3);font-style:italic;margin-top:1px;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">💬 '+escHtml(t.just)+'</div>' : '';
        html += '<td style="' + td + 'center;color:var(--t3)">' + t.qtd + '</td>'
              + '<td style="' + td + 'center;' + col + '">' + deltaStr + justHtml + '</td>';
      });
      html += '<td style="' + td + 'center;color:var(--red);font-weight:700">' + (art.sumNeg < 0 ? art.sumNeg.toFixed(0) : '—') + '</td>'
            + '<td style="' + td + 'center;color:var(--blue)">' + (art.sumPos > 0 ? '+' + art.sumPos.toFixed(0) : '—') + '</td>'
            + '</tr>';
    });

    html += '</tbody></table></details>';
  });
  html += '</div>';
  body.innerHTML = html;
};

// ── Pop-up: relatório expandido por loja/contagem ───────────────────────────
window.dcgOpenLojaPopup = function(loja) {
  var det = document.querySelector('#dcg-dia-body details[data-dcg-loja="' + String(loja).replace(/"/g,'\\"') + '"]');
  if (!det) return;
  var date = (document.getElementById('dcg-dia-date') || {}).value || '';
  var nome = det.getAttribute('data-dcg-nome') || loja;
  var table = det.querySelector('table');
  if (!table) return;

  var modal = document.getElementById('dcg-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'dcg-modal';
    modal.innerHTML = '<div id="dcg-modal-card">'
      + '<div id="dcg-modal-head">'
      + '<div><div id="dcg-modal-title"></div><div id="dcg-modal-sub"></div></div>'
      + '<div id="dcg-modal-actions">'
      + '<button id="dcg-modal-email" type="button" onclick="dcgEmailLojaPopup()">✉️ Enviar por email</button>'
      + '<button id="dcg-modal-close" type="button" onclick="dcgCloseLojaPopup()">Fechar</button>'
      + '</div>'
      + '</div><div id="dcg-modal-body"></div></div>';
    modal.addEventListener('click', function(e){ if (e.target === modal) dcgCloseLojaPopup(); });
    document.body.appendChild(modal);
  }
  var title = document.getElementById('dcg-modal-title');
  var sub   = document.getElementById('dcg-modal-sub');
  var body  = document.getElementById('dcg-modal-body');
  if (title) title.textContent = loja + ' · ' + nome;
  if (sub) sub.textContent = 'Relatório de diferenças de contagem · ' + date;
  if (body) body.innerHTML = '<div style="overflow:auto">' + table.outerHTML + '</div>';
  window._dcgEmailPayload = { loja: loja, nome: nome, date: date };
  modal.classList.add('on');
  document.body.style.overflow = 'hidden';
};

window.dcgEmailLojaPopup = function() {
  var payload = window._dcgEmailPayload || {};
  var loja = payload.loja || '';
  var nome = payload.nome || '';
  var date = payload.date || ((document.getElementById('dcg-dia-date') || {}).value || '');
  var modalTable = document.querySelector('#dcg-modal-body table');
  if (!modalTable) return;

  function clean(txt) {
    return String(txt || '')
      .replace(/💬/g, 'Justificação:')
      .replace(/\s+/g, ' ')
      .trim();
  }

  var lines = [];
  lines.push('Relatório de diferenças de contagem');
  lines.push('Loja: ' + loja + (nome ? ' · ' + nome : ''));
  lines.push('Data: ' + date);
  lines.push('');

  var headers = Array.prototype.map.call(modalTable.querySelectorAll('thead th'), function(th){ return clean(th.textContent); });
  if (headers.length) lines.push(headers.join(' | '));

  Array.prototype.forEach.call(modalTable.querySelectorAll('tbody tr'), function(tr){
    var cells = Array.prototype.map.call(tr.children, function(td){ return clean(td.innerText || td.textContent); });
    if (cells.length) lines.push(cells.join(' | '));
  });

  lines.push('');
  lines.push('Enviado a partir da app Karta.');

  var subject = 'Relatório diferenças de contagem - ' + loja + ' - ' + date;
  var body = lines.join('\r\n');
  var mailto = 'mailto:?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);

  // Abre no cliente de email padrão do computador. Se o Outlook estiver definido como padrão, abre no Outlook.
  window.location.href = mailto;
};

window.dcgCloseLojaPopup = function() {
  var modal = document.getElementById('dcg-modal');
  if (modal) modal.classList.remove('on');
  document.body.style.overflow = '';
};
document.addEventListener('keydown', function(e){ if(e.key === 'Escape') dcgCloseLojaPopup && dcgCloseLojaPopup(); });


// ── Ranking Lojas ─────────────────────────────────────────────────────────────
window.dcgRankingRender = function() {
  var body = document.getElementById('dcg-ranking-body'); if (!body) return;
  var artFil = (document.getElementById('dcg-rank-art') || {}).value || '';
  var datas  = _dcgDates();
  var contData = window.CONT_DATA || contDataLoad();
  var artigos  = _dcgGetArtigos();
  if (artFil) artigos = artigos.filter(function(a){ return a.id === artFil; });
  var lojas = _dcgGetLojas();

  var rows = lojas.map(function(l) {
    var res = computeLojaData(l.c, datas, contData, artigos, _dcgTurnos());
    var sumNeg = 0, sumPos = 0, nDiff = 0;
    Object.values(res).forEach(function(r){ sumNeg += r.sumNeg; sumPos += r.sumPos; nDiff += r.count; });
    return { c: l.c, n: _dcgNomeLoja(l.c) || l.n || l.c, sumNeg: sumNeg, sumPos: sumPos, nDiff: nDiff };
  }).filter(function(r){ return r.nDiff > 0; }).sort(function(a,b){ return a.sumNeg - b.sumNeg; });

  if (!rows.length) { body.innerHTML = '<div style="padding:32px;text-align:center;color:var(--t3);font-size:12px">Sem diferenças nos últimos ' + _dcgPeriodDays + ' dias.</div>'; return; }

  var maxNeg = Math.abs(rows[0].sumNeg) || 1;
  var tdH = 'padding:7px 10px;font-size:10px;font-weight:700;color:var(--t3);text-transform:uppercase;background:var(--s2);border-bottom:1px solid var(--bd);text-align:';
  var td  = 'padding:6px 10px;font-size:11px;border-bottom:1px solid var(--bd);';

  var html = '<div style="overflow-x:auto;border:1px solid var(--bd);border-radius:8px">'
    + '<table style="width:100%;border-collapse:collapse"><thead><tr>'
    + '<th style="' + tdH + 'left">Loja</th>'
    + '<th style="' + tdH + 'center">Δ Negativo</th>'
    + '<th style="' + tdH + 'center">Barra</th>'
    + '<th style="' + tdH + 'center">Δ Positivo</th>'
    + '<th style="' + tdH + 'center">Nº Difs</th>'
    + '</tr></thead><tbody>';

  rows.forEach(function(r, i) {
    var negPct = Math.round(Math.abs(r.sumNeg) / maxNeg * 100);
    var bar = '<div style="width:' + negPct + '%;min-width:2px;height:10px;background:var(--red);border-radius:2px"></div>';
    html += '<tr style="background:' + (i % 2 === 0 ? 'var(--bg)' : 'var(--s2)') + '">'
          + '<td style="' + td + 'left"><span style="font-family:monospace;font-size:10px;color:var(--t3)">' + r.c + '</span> ' + r.n + '</td>'
          + '<td style="' + td + 'center;color:var(--red);font-weight:700">' + r.sumNeg.toFixed(0) + '</td>'
          + '<td style="' + td + 'center;min-width:120px">' + bar + '</td>'
          + '<td style="' + td + 'center;color:var(--blue)">' + (r.sumPos > 0 ? '+' + r.sumPos.toFixed(0) : '—') + '</td>'
          + '<td style="' + td + 'center;color:var(--t2)">' + r.nDiff + '</td>'
          + '</tr>';
  });
  html += '</tbody></table></div>';
  body.innerHTML = html;
};

// ── Tendência: evolução diária das diferenças ─────────────────────────────────
window.dcgTendenciaRender = function() {
  var body = document.getElementById('dcg-tendencia-body'); if (!body) return;
  var artFil  = (document.getElementById('dcg-tend-art')  || {}).value || '';
  var lojaFil = (document.getElementById('dcg-tend-loja') || {}).value || '';
  var datas   = _dcgDates();
  var contData = window.CONT_DATA || contDataLoad();
  var artigos  = _dcgGetArtigos();
  if (artFil) artigos = artigos.filter(function(a){ return a.id === artFil; });
  var lojas = _dcgGetLojas();
  if (lojaFil) lojas = lojas.filter(function(l){ return l.c === lojaFil; });

  // Agregar por dia
  var byDate = {};
  datas.forEach(function(d){ byDate[d] = { neg: 0, pos: 0 }; });
  lojas.forEach(function(l) {
    var res = computeLojaData(l.c, datas, contData, artigos, _dcgTurnos());
    Object.values(res).forEach(function(r) {
      r.diffs.forEach(function(df) {
        if (!byDate[df.date]) return;
        if (df.delta < 0) byDate[df.date].neg += df.delta;
        else byDate[df.date].pos += df.delta;
      });
    });
  });

  var maxAbs = Math.max(1, Math.max.apply(null, datas.map(function(d){ return Math.max(Math.abs(byDate[d].neg), byDate[d].pos); })));
  var h = 140;
  var barW = Math.max(8, Math.min(32, Math.floor(560 / datas.length) - 2));
  var totalW = datas.length * (barW + 2) + 60;

  var svgBars = datas.map(function(d, i) {
    var x = 50 + i * (barW + 2);
    var neg = byDate[d].neg, pos = byDate[d].pos;
    var hNeg = Math.round(Math.abs(neg) / maxAbs * h * 0.9);
    var hPos = Math.round(pos / maxAbs * h * 0.9);
    var label = d.slice(5); // MM-DD
    return (hNeg > 0 ? '<rect x="' + x + '" y="' + (h - hNeg) + '" width="' + barW + '" height="' + hNeg + '" fill="var(--red)" opacity=".8" rx="2"/>' : '')
         + (hPos > 0 ? '<rect x="' + x + '" y="' + (h - hNeg - hPos) + '" width="' + barW + '" height="' + hPos + '" fill="var(--blue)" opacity=".7" rx="2"/>' : '')
         + '<text x="' + (x + barW/2) + '" y="' + (h + 14) + '" text-anchor="middle" font-size="8" fill="var(--t3)">' + label + '</text>'
         + (neg < 0 ? '<text x="' + (x + barW/2) + '" y="' + (h - hNeg - 3) + '" text-anchor="middle" font-size="8" fill="var(--red)">' + neg.toFixed(0) + '</text>' : '');
  }).join('');

  var svg = '<svg viewBox="0 0 ' + totalW + ' ' + (h + 30) + '" style="width:100%;max-width:' + totalW + 'px;overflow:visible">'
    + '<line x1="50" y1="0" x2="50" y2="' + h + '" stroke="var(--bd)" stroke-width="1"/>'
    + '<line x1="50" y1="' + h + '" x2="' + totalW + '" y2="' + h + '" stroke="var(--bd)" stroke-width="1"/>'
    + svgBars + '</svg>';

  var totNeg = datas.reduce(function(s,d){ return s + byDate[d].neg; }, 0);
  var totPos = datas.reduce(function(s,d){ return s + byDate[d].pos; }, 0);

  body.innerHTML = '<div style="display:flex;gap:16px;margin-bottom:12px">'
    + '<div style="background:var(--rbg);border:1px solid var(--red);border-radius:6px;padding:8px 16px;text-align:center"><div style="font-size:18px;font-weight:700;color:var(--red)">' + totNeg.toFixed(0) + '</div><div style="font-size:10px;color:var(--t3)">Δ Total Negativo</div></div>'
    + '<div style="background:var(--bbg);border:1px solid var(--blue);border-radius:6px;padding:8px 16px;text-align:center"><div style="font-size:18px;font-weight:700;color:var(--blue)">+' + totPos.toFixed(0) + '</div><div style="font-size:10px;color:var(--t3)">Δ Total Positivo</div></div>'
    + '</div>'
    + '<div style="overflow-x:auto">' + svg + '</div>';
};

// ── Mapa de Calor: loja × dia da semana ──────────────────────────────────────
window.dcgCaiorRender = function() {
  var body = document.getElementById('dcg-calor-body'); if (!body) return;
  var datas = _dcgDates();
  var contData = window.CONT_DATA || contDataLoad();
  var artigos  = _dcgGetArtigos();
  var lojas    = _dcgGetLojas();
  var WD = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];

  // {loja: {0..6: {neg, count}}}
  var heat = {};
  lojas.forEach(function(l){ heat[l.c] = [0,1,2,3,4,5,6].map(function(){ return {neg:0,count:0}; }); });

  datas.forEach(function(d) {
    var dow = new Date(d + 'T12:00:00').getDay();
    lojas.forEach(function(l) {
      var res = computeLojaData(l.c, [d], contData, artigos, _dcgTurnos());
      Object.values(res).forEach(function(r) {
        if (r.sumNeg < 0) { heat[l.c][dow].neg += r.sumNeg; heat[l.c][dow].count++; }
      });
    });
  });

  var lojasComDados = lojas.filter(function(l){ return Object.values(heat[l.c]).some(function(x){ return x.count > 0; }); });
  if (!lojasComDados.length) { body.innerHTML = '<div style="padding:32px;text-align:center;color:var(--t3);font-size:12px">Sem dados para os últimos ' + _dcgPeriodDays + ' dias.</div>'; return; }

  var allNegs = [];
  lojasComDados.forEach(function(l){ heat[l.c].forEach(function(x){ if(x.neg<0) allNegs.push(Math.abs(x.neg)); }); });
  var maxNeg = allNegs.length ? Math.max.apply(null, allNegs) : 1;

  var tdH = 'padding:5px 10px;font-size:9.5px;font-weight:700;color:var(--t3);text-transform:uppercase;background:var(--s2);border-bottom:1px solid var(--bd);text-align:center;white-space:nowrap';
  var tdC = 'padding:5px 8px;text-align:center;font-size:10px;border-bottom:1px solid var(--bd);border-right:1px solid var(--bd)';

  var html = '<div style="overflow-x:auto;border:1px solid var(--bd);border-radius:8px">'
    + '<table style="width:100%;border-collapse:collapse"><thead><tr>'
    + '<th style="' + tdH + ';text-align:left">Loja</th>'
    + WD.map(function(d){ return '<th style="' + tdH + '">' + d + '</th>'; }).join('')
    + '<th style="' + tdH + '">Total</th>'
    + '</tr></thead><tbody>';

  lojasComDados.sort(function(a, b) {
    var totA = heat[a.c].reduce(function(s,x){ return s+x.neg; }, 0);
    var totB = heat[b.c].reduce(function(s,x){ return s+x.neg; }, 0);
    return totA - totB;
  }).forEach(function(l, i) {
    var total = heat[l.c].reduce(function(s,x){ return s+x.neg; }, 0);
    html += '<tr style="background:' + (i%2===0?'var(--bg)':'var(--s2)') + '">'
          + '<td style="padding:5px 10px;font-size:11px;border-bottom:1px solid var(--bd);font-weight:500;white-space:nowrap">'
          + '<span style="font-family:monospace;font-size:9px;color:var(--t3)">' + l.c + '</span> ' + (_dcgNomeLoja(l.c) || l.n || l.c) + '</td>';
    heat[l.c].forEach(function(x) {
      var pct = x.neg < 0 ? Math.min(1, Math.abs(x.neg) / maxNeg) : 0;
      var r = Math.round(183 * pct), gb = Math.round(255 - 255 * pct);
      var bg = pct > 0.05 ? 'rgb(' + (183 + Math.round((255-183)*(1-pct))) + ',' + gb + ',' + gb + ')' : '';
      var col = pct > 0.5 ? '#fff' : 'var(--tx)';
      html += '<td style="' + tdC + ';background:' + bg + ';color:' + col + '">' + (x.neg < 0 ? x.neg.toFixed(0) : '—') + '</td>';
    });
    html += '<td style="' + tdC + ';font-weight:700;color:var(--red)">' + (total < 0 ? total.toFixed(0) : '—') + '</td>'
          + '</tr>';
  });
  html += '</tbody></table></div>';
  body.innerHTML = html;
};

// Init: arrancar na Vista Diária quando a secção abre
window.dcgCalorRender = window.dcgCaiorRender;

window._dcgInit = function() {
  var dateEl = document.getElementById('dcg-dia-date');
  var today = isoToday(0);
  if (dateEl && !dateEl.value) dateEl.value = today;

  // Garantir que a Vista Diária fica mesmo activa quando a aba é aberta
  try {
    ['dia','ranking','tendencia','calor'].forEach(function(t){
      var pane = document.getElementById('dcg-' + t);
      var btn  = document.getElementById('dcg-tab-' + t);
      if (pane) pane.style.display = (t === 'dia') ? '' : 'none';
      if (btn) {
        btn.style.borderBottomColor = (t === 'dia') ? 'var(--accent)' : 'transparent';
        btn.style.color = (t === 'dia') ? 'var(--accent)' : 'var(--t2)';
      }
    });
  } catch(e) {}

  function safeRender() {
    try { dcgDiaRender(); }
    catch(e) {
      var body = document.getElementById('dcg-dia-body');
      if (body) body.innerHTML = '<div style="padding:32px;text-align:center;color:var(--red);font-size:12px">Erro ao carregar Dif. Contagens: ' + (e && e.message ? e.message : e) + '</div>';
      if (window._KARTA_DEBUG) console.warn('[DCG] dcgDiaRender error:', e);
    }
  }

  safeRender();

  // Aguardar sincronização Firebase/localStorage quando a aba abre antes dos dados chegarem
  var _retries = 0;
  function _dcgRetry() {
    var cd = window.CONT_DATA || contDataLoad() || {};
    var date = (dateEl && dateEl.value) || today;
    var hasLojas = cd[date] && Object.keys(cd[date]).length > 0;
    if (!hasLojas && _retries < 12) {
      _retries++;
      setTimeout(function() { safeRender(); _dcgRetry(); }, 700);
    } else if (!hasLojas && _retries >= 12) {
      // Sem dados para hoje — ir para Sem Contagem automaticamente
      try { if (typeof dcgSwitch === 'function') dcgSwitch('semcont'); } catch(e) {}
    }
  }
  _dcgRetry();
};


// ══════════════════════════════════════════════════════════════════════════════
// REUNIÃO DE SUPERVISORES
// ══════════════════════════════════════════════════════════════════════════════
(function(){

var _reuTab = 'sup';

// ── Helpers ───────────────────────────────────────────────────────────────────
function _reuMesLabel(mes) {
  var mNames = ['','Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
  if (!mes) return mes;
  var p = mes.split('-'); return mNames[parseInt(p[1])] + ' ' + p[0];
}

function _reuPrevMes(mes) {
  if (!mes) return null;
  var p = mes.split('-'), y = parseInt(p[0]), m = parseInt(p[1]);
  m--; if (m === 0) { m = 12; y--; }
  return y + '-' + String(m).padStart(2, '0');
}

function _reuGetSup(lojaCode) {
  var s = (window.LOJA_SUPERVISORES && LOJA_SUPERVISORES[lojaCode] && LOJA_SUPERVISORES[lojaCode].sup) || '';
  if (!s && window.ADMCFG && ADMCFG.lojas) {
    var l = ADMCFG.lojas.find(function(x){ return String(x.c||'') === String(lojaCode||''); });
    if (l) s = l.s || '';
  }
  if (!s && window.DB && DB[lojaCode]) s = DB[lojaCode].s || DB[lojaCode].sup || '';
  return String(s || '').trim();
}

function _reuFmt(v, unit) {
  if (v == null || isNaN(v)) return '—';
  if (unit === 'aoa') return Math.round(v).toLocaleString('pt-AO') + ' AOA';
  if (unit === 'pct') return v.toFixed(1) + '%';
  if (unit === 'h')   return v.toFixed(1) + 'h';
  return Math.round(v).toLocaleString('pt-AO');
}

function _reuPctColor(pct, invert) {
  if (pct == null) return 'var(--t3)';
  var good = invert ? pct <= 100 : pct >= 100;
  var ok   = invert ? pct <= 110 : pct >= 85;
  if (good) return 'var(--green,#16a34a)';
  if (ok)   return 'var(--amber,#d97706)';
  return 'var(--red)';
}

function _reuSemaforo(pct, invert) {
  var col = _reuPctColor(pct, invert);
  var dot = pct == null ? '⬜' : (invert ? pct <= 100 : pct >= 100) ? '🟢' : (invert ? pct <= 110 : pct >= 85) ? '🟡' : '🔴';
  return dot;
}

// ── Recolha de dados por loja para um mês ─────────────────────────────────────
function _reuLojaData(lojaCode, mes) {
  var prevMes = _reuPrevMes(mes);
  var out = { c: lojaCode, n: (window.DB && DB[lojaCode] && DB[lojaCode].n) || lojaCode, sup: _reuGetSup(lojaCode) };

  // Vendas
  var lm = window.SALES_DATA && SALES_DATA.lm && SALES_DATA.lm[lojaCode];
  var lmMes = lm && lm[mes];
  var lmPrev = lm && prevMes && lm[prevMes];
  out.vt     = lmMes ? lmMes.vt   : null;
  out.vtPrev = lmPrev? lmPrev.vt  : null;
  out.cl     = lmMes ? lmMes.cl   : null;
  out.tk     = lmMes ? lmMes.tk   : null;
  out.ru     = lmMes ? lmMes.ru   : null;

  // Fallback robusto: quando a aba Reunião abre antes do SALES_DATA.lm ficar
  // preenchido, calcular os totais a partir dos registos diários já sincronizados
  // para window.DB. Isto evita o ecrã "Sem dados" mesmo quando a aba Vendas já
  // tem os dados carregados.
  try {
    if ((out.vt == null || out.vt === 0) && window.DB && DB[lojaCode] && DB[lojaCode].r) {
      var _rowsMes = (DB[lojaCode].r || []).filter(function(r){ return r.d && r.d.substring(0,7) === mes; });
      var _vsRows = _rowsMes.filter(function(r){ return r.vs != null && !isNaN(r.vs) && Number(r.vs) > 0; });
      if (_vsRows.length) {
        out.vt = Math.round(_vsRows.reduce(function(s,r){ return s + Number(r.vs || 0); }, 0));
      }
      var _clRows = _rowsMes.filter(function(r){ return r.cl != null && !isNaN(r.cl); });
      if (out.cl == null && _clRows.length) out.cl = Math.round(_clRows.reduce(function(s,r){ return s + Number(r.cl || 0); }, 0) / _clRows.length);
      var _tkRows = _rowsMes.filter(function(r){ return r.tk != null && !isNaN(r.tk); });
      if (out.tk == null && _tkRows.length) out.tk = Math.round(_tkRows.reduce(function(s,r){ return s + Number(r.tk || 0); }, 0) / _tkRows.length);
      var _ruRows = _rowsMes.filter(function(r){ return r.ru != null && !isNaN(r.ru); });
      if (out.ru == null && _ruRows.length) out.ru = Math.round((_ruRows.reduce(function(s,r){ return s + Number(r.ru || 0); }, 0) / _ruRows.length) * 10) / 10;
    }
    if ((out.vtPrev == null || out.vtPrev === 0) && prevMes && window.DB && DB[lojaCode] && DB[lojaCode].r) {
      var _prevRows = (DB[lojaCode].r || []).filter(function(r){ return r.d && r.d.substring(0,7) === prevMes && r.vs != null && !isNaN(r.vs) && Number(r.vs) > 0; });
      if (_prevRows.length) out.vtPrev = Math.round(_prevRows.reduce(function(s,r){ return s + Number(r.vs || 0); }, 0));
    }
  } catch(_eReuSalesFallback) { window._KARTA_DEBUG&&console.warn('[Reunião] fallback vendas:', _eReuSalesFallback); }

  // Objectivos
  var obj = (window.ADM_DATA && ADM_DATA[mes] && ADM_DATA[mes][lojaCode]) || {};
  out.vtObj  = obj.venda ? parseFloat(obj.venda) : null;
  out.paoObj = obj.pao   ? parseFloat(obj.pao)   : null;
  out.ruObj  = obj.rutura? parseFloat(obj.rutura) : null;
  out.qbObj  = obj.quebra? parseFloat(obj.quebra) : null;

  // Pão
  var paoMes = window.PAO_DATA && PAO_DATA[lojaCode] && PAO_DATA[lojaCode][mes];
  out.pao     = paoMes ? paoMes.pao : null;
  var paoPrev = window.PAO_DATA && PAO_DATA[lojaCode] && prevMes && PAO_DATA[lojaCode][prevMes];
  out.paoPrev = paoPrev ? paoPrev.pao : null;

  // Fallback do pão via DB, quando PAO_DATA ainda não foi construído.
  try {
    if ((out.pao == null || out.pao === 0) && window.DB && DB[lojaCode] && DB[lojaCode].r) {
      var _pRows = (DB[lojaCode].r || []).filter(function(r){ return r.d && r.d.substring(0,7) === mes && r.vp != null && !isNaN(r.vp) && Number(r.vp) > 0; });
      if (_pRows.length) out.pao = Math.round((_pRows.reduce(function(s,r){ return s + Number(r.vp || 0); }, 0) / _pRows.length) * 10) / 10;
    }
    if ((out.paoPrev == null || out.paoPrev === 0) && prevMes && window.DB && DB[lojaCode] && DB[lojaCode].r) {
      var _ppRows = (DB[lojaCode].r || []).filter(function(r){ return r.d && r.d.substring(0,7) === prevMes && r.vp != null && !isNaN(r.vp) && Number(r.vp) > 0; });
      if (_ppRows.length) out.paoPrev = Math.round((_ppRows.reduce(function(s,r){ return s + Number(r.vp || 0); }, 0) / _ppRows.length) * 10) / 10;
    }
  } catch(_eReuPaoFallback) { window._KARTA_DEBUG&&console.warn('[Reunião] fallback pão:', _eReuPaoFallback); }

  // Inventário
  var inv = window.INV_HIST_LIVE && INV_HIST_LIVE[lojaCode] && INV_HIST_LIVE[lojaCode][mes];
  out.invC = inv ? inv.vC : null;
  out.invD = inv ? inv.vD : null;
  out.invT = (inv && inv.vC != null && inv.vD != null) ? inv.vC + inv.vD : null;

  // Downtime
  var dtRecs = (window.DT_RAW && DT_RAW.records || []).filter(function(r){ return r.c === lojaCode && r.mes === mes; });
  out.dtHL = dtRecs.reduce(function(s,r){ return s + (r.hL||0); }, 0) || null;
  out.dtHP = dtRecs.reduce(function(s,r){ return s + (r.hP||0); }, 0) || null;

  // Quebras — por supervisor (aproximação: usar D.quebras.data filtrado por sup)
  // (quebras não têm loja directo, usamos por supervisor)
  return out;
}

// ── Calcular % cumprimento ────────────────────────────────────────────────────
function _pct(real, obj) {
  if (real == null || !obj || obj === 0) return null;
  return Math.round(real / obj * 1000) / 10;
}

// ── Detectar meses com dados reais para a Reunião ──────────────────────────────
function _reuMesesComDados() {
  var set = {};
  try {
    if (window.SALES_DATA && SALES_DATA.lm) {
      Object.values(SALES_DATA.lm).forEach(function(lm){
        Object.keys(lm || {}).forEach(function(m){
          var v = lm[m] || {};
          if ((v.vt != null && Number(v.vt) > 0) || (v.cl != null && Number(v.cl) > 0) || (v.tk != null && Number(v.tk) > 0)) set[m] = true;
        });
      });
    }
  } catch(e) {}
  try {
    if (window.PAO_DATA) {
      Object.values(PAO_DATA).forEach(function(pm){
        Object.keys(pm || {}).forEach(function(m){
          var v = pm[m] || {};
          if ((v.pao != null && Number(v.pao) > 0) || (v.vp != null && Number(v.vp) > 0)) set[m] = true;
        });
      });
    }
  } catch(e) {}
  try {
    if (window.DB) {
      Object.values(DB).forEach(function(loja){
        (loja.r || []).forEach(function(r){
          if (r && r.d && /^\d{4}-\d{2}/.test(r.d)) {
            if ((r.vs != null && Number(r.vs) > 0) || (r.vp != null && Number(r.vp) > 0) || (r.cl != null && Number(r.cl) > 0)) {
              set[String(r.d).substring(0,7)] = true;
            }
          }
        });
      });
    }
  } catch(e) {}
  try {
    if (window.ADM_DATA) {
      Object.keys(ADM_DATA || {}).forEach(function(m){
        if (ADM_DATA[m] && Object.keys(ADM_DATA[m]).length) set[m] = true;
      });
    }
  } catch(e) {}
  return Object.keys(set).sort().reverse();
}

function _reuMesTemDados(mes) {
  if (!mes) return false;
  try {
    var lojas = (window.ADMCFG && ADMCFG.lojas || []);
    return lojas.some(function(l){
      var d = _reuLojaData(l.c, mes);
      return d && (d.vt!=null || d.cl!=null || d.tk!=null || d.ru!=null || d.pao!=null || d.vtObj!=null || d.paoObj!=null || d.ruObj!=null || d.qbObj!=null || d.invT!=null || d.dtHL!=null || d.dtHP!=null);
    });
  } catch(e) { return false; }
}

// ── Inicializar selectores ────────────────────────────────────────────────────
function _reuInitSelectors() {
  var mesSel = document.getElementById('reu-mes');
  var supSel = document.getElementById('reu-sup');
  if (!mesSel) return;

  // Default = mês anterior
  var now = new Date();
  var prevM = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  var defMes = prevM.getFullYear() + '-' + String(prevM.getMonth()+1).padStart(2,'0');

  // Meses: preferir meses que tenham dados reais; depois completar com ADMCFG
  var mesesSet = {};
  var mesesDados = _reuMesesComDados();
  mesesDados.forEach(function(m){ mesesSet[m] = true; });

  if (window.ADMCFG && ADMCFG.meses) {
    ADMCFG.meses.forEach(function(m){ mesesSet[m]=true; });
  }

  // Fallback final: gerar meses dos últimos 12
  if (!Object.keys(mesesSet).length) {
    for (var i=0; i<12; i++) {
      var d = new Date(now.getFullYear(), now.getMonth()-i, 1);
      mesesSet[d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')] = true;
    }
  }
  var meses = Object.keys(mesesSet).sort().reverse();

  // Repopular se vazio ou se tiver mais meses do GS
  if (!mesSel._reuInited || mesSel.options.length === 0 || mesSel.options.length < meses.length) {
    var curVal = mesSel.value || defMes;
    mesSel.innerHTML = '';
    meses.forEach(function(m) {
      var o = document.createElement('option');
      o.value = m; o.textContent = _reuMesLabel(m);
      if (m === curVal) o.selected = true;
      mesSel.appendChild(o);
    });
    var melhorMes = (mesesDados && mesesDados.length) ? mesesDados[0] : (meses.indexOf(defMes)>=0 ? defMes : meses[0]);
    if (!mesSel.value && meses.length) mesSel.value = melhorMes;
    if (mesSel.value && !_reuMesTemDados(mesSel.value) && melhorMes) mesSel.value = melhorMes;
    mesSel._reuInited = true;
  }

  // Supervisores — sempre repopular para apanhar dados frescos do GS
  var sups = {};
  (window.ADMCFG && ADMCFG.lojas || []).forEach(function(l){
    var s = _reuGetSup(l.c) || l.s;
    if (s) sups[s] = true;
  });
  if (Object.keys(sups).length > supSel.options.length - 1) {
    while (supSel.options.length > 1) supSel.remove(1);
    Object.keys(sups).sort().forEach(function(s){
      var o = document.createElement('option'); o.value = s; o.textContent = s;
      supSel.appendChild(o);
    });
  }
}

// ── Render principal ──────────────────────────────────────────────────────────
window.reuniaoSync = function() {
  var btn = document.getElementById('reu-sync-btn');
  if (btn) { btn.disabled=true; btn.textContent='⏳ A sincronizar...'; }
  var body = document.getElementById('reu-body');
  if (body) body.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);font-size:12px">A carregar dados do Google Sheets...</div>';
  (typeof gsSyncAll === 'function' ? gsSyncAll() : Promise.resolve()).then(async function(){
    try { if (typeof vndInjectDBIntoSalesData === 'function') vndInjectDBIntoSalesData(); } catch(e) {}
    try {
      var _mesReu = (document.getElementById('reu-mes') || {}).value || '';
      if (_mesReu && typeof vdSyncMes === 'function') await vdSyncMes(_mesReu);
    } catch(e) {}
    if (btn) { btn.disabled=false; btn.textContent='🔄 Sincronizar'; }
    reuniaoRender();
  }).catch(function(){
    try { if (typeof vndInjectDBIntoSalesData === 'function') vndInjectDBIntoSalesData(); } catch(e) {}
    if (btn) { btn.disabled=false; btn.textContent='🔄 Sincronizar'; }
    reuniaoRender();
  });
};

window.reuniaoRender = function() {
  try { if (typeof vndInjectDBIntoSalesData === 'function') vndInjectDBIntoSalesData(); } catch(e) {}
  _reuInitSelectors();
  var mes  = (document.getElementById('reu-mes') || {}).value || '';
  var supF = (document.getElementById('reu-sup') || {}).value || '';
  if (!mes) return;

  var lojas = (window.ADMCFG && ADMCFG.lojas || []).filter(function(l){
    if (!l.c) return false;
    var sup = _reuGetSup(l.c) || l.s || '';
    if (supF && String(sup||'').trim().toLowerCase() !== String(supF||'').trim().toLowerCase()) return false;
    return true;
  });

  var lojasData = lojas.map(function(l){ return _reuLojaData(l.c, mes); });

  // Verificar se há algum dado real (não só nulos)
  var hasData = lojasData.some(function(l){ return l.vt!=null||l.cl!=null||l.tk!=null||l.ru!=null||l.pao!=null||l.vtObj!=null||l.paoObj!=null||l.ruObj!=null||l.qbObj!=null||l.invT!=null||l.dtHL!=null||l.dtHP!=null; });
  if (!hasData) {
    var mesesComDados = _reuMesesComDados();
    var mesSelEl = document.getElementById('reu-mes');
    if (mesesComDados.length && mesSelEl && mesSelEl.value !== mesesComDados[0]) {
      mesSelEl.value = mesesComDados[0];
      mes = mesesComDados[0];
      lojasData = lojas.map(function(l){ return _reuLojaData(l.c, mes); });
      hasData = lojasData.some(function(l){ return l.vt!=null||l.cl!=null||l.tk!=null||l.ru!=null||l.pao!=null||l.vtObj!=null||l.paoObj!=null||l.ruObj!=null||l.qbObj!=null||l.invT!=null||l.dtHL!=null||l.dtHP!=null; });
    }
  }

  if (!hasData) {
    var body = document.getElementById('reu-body');
    if (body) body.innerHTML = '<div style="padding:60px 40px;text-align:center">'
      + '<div style="font-size:32px;margin-bottom:12px">📊</div>'
      + '<div style="font-size:14px;font-weight:600;color:var(--tx);margin-bottom:8px">Sem dados para ' + _reuMesLabel(mes) + '</div>'
      + '<div style="font-size:12px;color:var(--t3);margin-bottom:20px">Não foram encontrados dados de vendas, pão, objectivos, inventário ou downtime para este mês. Clique em sincronizar ou escolha outro mês.</div>'
      + '<button onclick="reuniaoSync()" style="font-size:12px;padding:8px 20px;border:none;border-radius:8px;background:var(--accent);color:#fff;cursor:pointer;font-weight:600">🔄 Sincronizar agora</button>'
      + '</div>';
    return;
  }

  if (_reuTab === 'sup')  _reuRenderSup(lojasData, mes);
  if (_reuTab === 'loja') _reuRenderLoja(lojasData, mes);
  if (_reuTab === 'rank') _reuRenderRank(lojasData, mes);
};

window.reuniaoTabSwitch = function(tab) {
  _reuTab = tab;
  ['sup','loja','rank'].forEach(function(t){
    var btn = document.getElementById('reu-tab-' + t);
    if (!btn) return;
    var on = t === tab;
    btn.style.background    = on ? 'var(--accent)' : 'var(--s2)';
    btn.style.color         = on ? '#fff' : 'var(--t2)';
    btn.style.border        = on ? 'none' : '1px solid var(--bd)';
    btn.style.fontWeight    = on ? '600' : '400';
  });
  reuniaoRender();
};

// ── Vista Por Supervisor ──────────────────────────────────────────────────────
function _reuRenderSup(lojasData, mes) {
  var body = document.getElementById('reu-body'); if (!body) return;

  // Agrupar por supervisor
  var supMap = {};
  lojasData.forEach(function(l){
    var sup = l.sup || '(sem supervisor)';
    if (!supMap[sup]) supMap[sup] = { sup: sup, lojas: [] };
    supMap[sup].lojas.push(l);
  });

  if (!Object.keys(supMap).length) {
    body.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3)">Sem dados para ' + _reuMesLabel(mes) + ' — verifique se o GS sincronizou.</div>';
    return;
  }

  var thS = 'padding:7px 10px;font-size:9.5px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.04em;white-space:nowrap;background:var(--s2);border-bottom:1px solid var(--bd);text-align:';
  var td  = 'padding:6px 10px;font-size:11px;border-bottom:1px solid var(--bd);white-space:nowrap;';

  var html = '';

  Object.keys(supMap).sort().forEach(function(sup) {
    var sg = supMap[sup];
    var ls = sg.lojas;

    // Agregar para o supervisor
    var totVt = ls.reduce(function(s,l){ return s + (l.vt||0); }, 0);
    var totVtObj = ls.reduce(function(s,l){ return s + (l.vtObj||0); }, 0);
    var totVtPrev = ls.reduce(function(s,l){ return s + (l.vtPrev||0); }, 0);
    var avgPao = ls.filter(function(l){ return l.pao!=null; });
    var avgPaoV = avgPao.length ? avgPao.reduce(function(s,l){ return s+(l.pao||0);},0)/avgPao.length : null;
    var avgPaoObj = ls.filter(function(l){ return l.paoObj!=null; });
    var avgPaoObjV = avgPaoObj.length ? avgPaoObj.reduce(function(s,l){ return s+(l.paoObj||0);},0)/avgPaoObj.length : null;
    var avgRu = ls.filter(function(l){ return l.ru!=null; });
    var avgRuV = avgRu.length ? avgRu.reduce(function(s,l){ return s+(l.ru||0);},0)/avgRu.length : null;
    var totDtHL = ls.reduce(function(s,l){ return s+(l.dtHL||0); }, 0);
    var avgInvT = ls.filter(function(l){ return l.invT!=null; });
    var avgInvTV = avgInvT.length ? avgInvT.reduce(function(s,l){ return s+(l.invT||0);},0)/avgInvT.length : null;

    var pctVt   = _pct(totVt, totVtObj);
    var pctPao  = _pct(avgPaoV, avgPaoObjV);
    var pctVtYoy= totVtPrev ? Math.round(totVt/totVtPrev*1000)/10 : null;

    html += '<details open style="margin-bottom:16px;border:1px solid var(--bd);border-radius:10px;overflow:hidden">'
          + '<summary style="padding:12px 16px;background:var(--s2);cursor:pointer;display:flex;align-items:center;gap:12px;list-style:none">'
          + '<span style="font-size:14px;font-weight:700;color:var(--tx)">' + escHtml(sup) + '</span>'
          + '<span style="font-size:11px;color:var(--t3)">' + ls.length + ' lojas</span>'
          + '<span style="margin-left:auto;display:flex;gap:16px;align-items:center">'
          + '<span style="font-size:12px;font-weight:700;color:' + _reuPctColor(pctVt, false) + '">' + _reuSemaforo(pctVt,false) + ' Vendas ' + (pctVt!=null?pctVt+'%':'—') + '</span>'
          + '<span style="font-size:12px;font-weight:700;color:' + _reuPctColor(pctPao, false) + '">' + _reuSemaforo(pctPao,false) + ' Pão ' + (pctPao!=null?pctPao+'%':'—') + '</span>'
          + (avgRuV!=null?'<span style="font-size:12px;color:var(--t2)">Rutura ' + avgRuV.toFixed(1) + '%</span>':'')
          + '</span>'
          + '</summary>'

          // Tabela de lojas
          + '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse">'
          + '<thead><tr>'
          + '<th style="' + thS + 'left;position:sticky;left:0;z-index:1">Loja</th>'
          + '<th style="' + thS + 'right">Venda Real</th>'
          + '<th style="' + thS + 'right">Obj. Venda</th>'
          + '<th style="' + thS + 'center">% Venda</th>'
          + '<th style="' + thS + 'right">Vs Mês Ant.</th>'
          + '<th style="' + thS + 'right">Pão Real</th>'
          + '<th style="' + thS + 'right">Obj. Pão</th>'
          + '<th style="' + thS + 'center">% Pão</th>'
          + '<th style="' + thS + 'right">Rutura %</th>'
          + '<th style="' + thS + 'right">DT Loja (h)</th>'
          + '<th style="' + thS + 'right">DT Pad. (h)</th>'
          + '<th style="' + thS + 'right">Inv. C+D %</th>'
          + '</tr></thead><tbody>';

    ls.sort(function(a,b){ return (b.vt||0)-(a.vt||0); }).forEach(function(l, i) {
      var pv = _pct(l.vt, l.vtObj);
      var pp = _pct(l.pao, l.paoObj);
      var pvYoy = l.vtPrev ? Math.round(l.vt/l.vtPrev*1000)/10 : null;
      var bg = i%2===0?'':'background:var(--s2)';
      html += '<tr style="' + bg + '">'
            + '<td style="' + td + 'left;font-weight:500;position:sticky;left:0;background:' + (i%2===0?'var(--bg)':'var(--s2)') + '">'
            + '<span style="font-family:monospace;font-size:9px;color:var(--t3)">' + l.c + '</span> ' + escHtml(l.n) + '</td>'
            + '<td style="' + td + 'right">' + _reuFmt(l.vt,'aoa') + '</td>'
            + '<td style="' + td + 'right;color:var(--t3)">' + _reuFmt(l.vtObj,'aoa') + '</td>'
            + '<td style="' + td + 'center;font-weight:700;color:' + _reuPctColor(pv,false) + '">' + _reuSemaforo(pv,false) + ' ' + (pv!=null?pv+'%':'—') + '</td>'
            + '<td style="' + td + 'right;color:' + (pvYoy!=null?(pvYoy>=100?'var(--green,#16a34a)':'var(--red)'):'var(--t3)') + '">' + (pvYoy!=null?(pvYoy>=100?'+':'')+pvYoy+'%':'—') + '</td>'
            + '<td style="' + td + 'right">' + _reuFmt(l.pao,'') + '</td>'
            + '<td style="' + td + 'right;color:var(--t3)">' + _reuFmt(l.paoObj,'') + '</td>'
            + '<td style="' + td + 'center;font-weight:700;color:' + _reuPctColor(pp,false) + '">' + _reuSemaforo(pp,false) + ' ' + (pp!=null?pp+'%':'—') + '</td>'
            + '<td style="' + td + 'right;color:' + (l.ru!=null?(l.ru>2?'var(--red)':l.ru>1?'var(--amber)':'var(--t2)'):'var(--t3)') + '">' + (l.ru!=null?l.ru.toFixed(1)+'%':'—') + '</td>'
            + '<td style="' + td + 'right;color:' + (l.dtHL?(l.dtHL>20?'var(--red)':l.dtHL>5?'var(--amber)':'var(--t2)'):'var(--t3)') + '">' + (l.dtHL?l.dtHL.toFixed(0)+'h':'—') + '</td>'
            + '<td style="' + td + 'right;color:' + (l.dtHP?(l.dtHP>20?'var(--red)':l.dtHP>5?'var(--amber)':'var(--t2)'):'var(--t3)') + '">' + (l.dtHP?l.dtHP.toFixed(0)+'h':'—') + '</td>'
            + '<td style="' + td + 'right;color:' + (l.invT!=null?(l.invT<-1?'var(--red)':l.invT<0?'var(--amber)':'var(--t2)'):'var(--t3)') + '">' + (l.invT!=null?l.invT.toFixed(2)+'%':'—') + '</td>'
            + '</tr>';
    });

    // Linha de totais do supervisor
    html += '<tr style="background:var(--s2);font-weight:700">'
          + '<td style="' + td + 'left;font-weight:700">TOTAL / MÉDIA</td>'
          + '<td style="' + td + 'right">' + _reuFmt(totVt,'aoa') + '</td>'
          + '<td style="' + td + 'right;color:var(--t3)">' + _reuFmt(totVtObj,'aoa') + '</td>'
          + '<td style="' + td + 'center;color:' + _reuPctColor(pctVt,false) + '">' + (pctVt!=null?pctVt+'%':'—') + '</td>'
          + '<td style="' + td + 'right;color:' + (pctVtYoy!=null?(pctVtYoy>=100?'var(--green,#16a34a)':'var(--red)'):'var(--t3)') + '">' + (pctVtYoy!=null?pctVtYoy+'%':'—') + '</td>'
          + '<td style="' + td + 'right">' + _reuFmt(avgPaoV,'') + '</td>'
          + '<td style="' + td + 'right;color:var(--t3)">' + _reuFmt(avgPaoObjV,'') + '</td>'
          + '<td style="' + td + 'center;color:' + _reuPctColor(pctPao,false) + '">' + (pctPao!=null?pctPao+'%':'—') + '</td>'
          + '<td style="' + td + 'right">' + (avgRuV!=null?avgRuV.toFixed(1)+'%':'—') + '</td>'
          + '<td style="' + td + 'right">' + (totDtHL?totDtHL.toFixed(0)+'h':'—') + '</td>'
          + '<td style="' + td + 'right">—</td>'
          + '<td style="' + td + 'right">' + (avgInvTV!=null?avgInvTV.toFixed(2)+'%':'—') + '</td>'
          + '</tr>';

    html += '</tbody></table></div></details>';
  });

  body.innerHTML = html;
}

// ── Vista Por Loja (tabela flat) ──────────────────────────────────────────────
function _reuRenderLoja(lojasData, mes) {
  var body = document.getElementById('reu-body'); if (!body) return;

  var thS = 'padding:7px 10px;font-size:9.5px;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:.04em;white-space:nowrap;background:var(--s2);border-bottom:1px solid var(--bd);text-align:';
  var td  = 'padding:6px 10px;font-size:11px;border-bottom:1px solid var(--bd);white-space:nowrap;';

  var sorted = lojasData.slice().sort(function(a,b){ return (b.vt||0)-(a.vt||0); });

  var html = '<div style="overflow-x:auto;border:1px solid var(--bd);border-radius:10px">'
    + '<table style="width:100%;border-collapse:collapse"><thead><tr>'
    + '<th style="' + thS + 'left;position:sticky;left:0;z-index:1">Loja</th>'
    + '<th style="' + thS + 'left">Supervisor</th>'
    + '<th style="' + thS + 'right">Venda Real</th>'
    + '<th style="' + thS + 'center">% Obj.</th>'
    + '<th style="' + thS + 'center">% Ant.</th>'
    + '<th style="' + thS + 'right">Pão Real</th>'
    + '<th style="' + thS + 'center">% P.Obj.</th>'
    + '<th style="' + thS + 'right">Clientes/dia</th>'
    + '<th style="' + thS + 'right">Ticket</th>'
    + '<th style="' + thS + 'right">Rutura %</th>'
    + '<th style="' + thS + 'right">DT Loja</th>'
    + '<th style="' + thS + 'right">DT Pad.</th>'
    + '<th style="' + thS + 'right">Inv. C+D</th>'
    + '</tr></thead><tbody>';

  sorted.forEach(function(l, i) {
    var pv  = _pct(l.vt, l.vtObj);
    var pp  = _pct(l.pao, l.paoObj);
    var pvY = l.vtPrev ? Math.round(l.vt/l.vtPrev*1000)/10 : null;
    var bg  = i%2===0?'var(--bg)':'var(--s2)';
    html += '<tr style="background:'+bg+'">'
          + '<td style="' + td + 'left;font-weight:600;position:sticky;left:0;background:'+bg+'">'
          + '<span style="font-family:monospace;font-size:9px;color:var(--t3)">' + l.c + '</span> ' + escHtml(l.n) + '</td>'
          + '<td style="' + td + 'left;font-size:10px;color:var(--t2)">' + escHtml(l.sup) + '</td>'
          + '<td style="' + td + 'right">' + _reuFmt(l.vt,'aoa') + '</td>'
          + '<td style="' + td + 'center;font-weight:700;color:' + _reuPctColor(pv,false) + '">' + _reuSemaforo(pv,false) + ' ' + (pv!=null?pv+'%':'—') + '</td>'
          + '<td style="' + td + 'center;color:' + (pvY!=null?(pvY>=100?'var(--green,#16a34a)':'var(--red)'):'var(--t3)') + '">' + (pvY!=null?(pvY>=100?'+':'')+pvY+'%':'—') + '</td>'
          + '<td style="' + td + 'right">' + _reuFmt(l.pao,'') + '</td>'
          + '<td style="' + td + 'center;font-weight:700;color:' + _reuPctColor(pp,false) + '">' + _reuSemaforo(pp,false) + ' ' + (pp!=null?pp+'%':'—') + '</td>'
          + '<td style="' + td + 'right">' + (l.cl!=null?Math.round(l.cl):'—') + '</td>'
          + '<td style="' + td + 'right">' + (l.tk!=null?Math.round(l.tk).toLocaleString('pt-AO')+' AOA':'—') + '</td>'
          + '<td style="' + td + 'right;color:' + (l.ru!=null?(l.ru>2?'var(--red)':l.ru>1?'var(--amber,#d97706)':'var(--t2)'):'var(--t3)') + '">' + (l.ru!=null?l.ru.toFixed(1)+'%':'—') + '</td>'
          + '<td style="' + td + 'right;color:' + (l.dtHL&&l.dtHL>0?(l.dtHL>20?'var(--red)':'var(--amber,#d97706)'):'var(--t3)') + '">' + (l.dtHL&&l.dtHL>0?l.dtHL.toFixed(0)+'h':'—') + '</td>'
          + '<td style="' + td + 'right;color:' + (l.dtHP&&l.dtHP>0?(l.dtHP>20?'var(--red)':'var(--amber,#d97706)'):'var(--t3)') + '">' + (l.dtHP&&l.dtHP>0?l.dtHP.toFixed(0)+'h':'—') + '</td>'
          + '<td style="' + td + 'right;color:' + (l.invT!=null?(l.invT<-1?'var(--red)':l.invT<-0.2?'var(--amber,#d97706)':'var(--t2)'):'var(--t3)') + '">' + (l.invT!=null?l.invT.toFixed(2)+'%':'—') + '</td>'
          + '</tr>';
  });

  html += '</tbody></table></div>';
  body.innerHTML = html;
}

// ── Ranking transversal ───────────────────────────────────────────────────────
function _reuRenderRank(lojasData, mes) {
  var body = document.getElementById('reu-body'); if (!body) return;

  var kpis = [
    { id:'vt',   label:'Vendas (AOA)',     fmt:'aoa', invert:false, fn:function(l){return l.vt;} },
    { id:'pctVt',label:'% Obj. Vendas',    fmt:'pct', invert:false, fn:function(l){return _pct(l.vt,l.vtObj);} },
    { id:'pao',  label:'Pão (unid/dia)',   fmt:'',    invert:false, fn:function(l){return l.pao;} },
    { id:'ru',   label:'Rutura %',         fmt:'pct', invert:true,  fn:function(l){return l.ru;} },
    { id:'dtHL', label:'Downtime Loja (h)',fmt:'h',   invert:true,  fn:function(l){return l.dtHL;} },
    { id:'invT', label:'Inv. C+D %',       fmt:'pct', invert:true,  fn:function(l){return l.invT;} },
  ];

  var thS = 'padding:7px 12px;font-size:9.5px;font-weight:700;color:var(--t3);text-transform:uppercase;background:var(--s2);border-bottom:1px solid var(--bd);text-align:';
  var td  = 'padding:6px 12px;font-size:11px;border-bottom:1px solid var(--bd);';

  var html = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:16px">';

  kpis.forEach(function(kpi) {
    var ranked = lojasData
      .filter(function(l){ return kpi.fn(l) != null; })
      .sort(function(a,b){
        var va = kpi.fn(a), vb = kpi.fn(b);
        return kpi.invert ? va - vb : vb - va;
      });
    if (!ranked.length) return;

    html += '<div style="border:1px solid var(--bd);border-radius:10px;overflow:hidden">'
          + '<div style="padding:10px 14px;background:var(--s2);font-size:12px;font-weight:700;color:var(--tx)">' + kpi.label + '</div>'
          + '<table style="width:100%;border-collapse:collapse"><thead><tr>'
          + '<th style="' + thS + 'center">Pos.</th>'
          + '<th style="' + thS + 'left">Loja</th>'
          + '<th style="' + thS + 'left">Sup.</th>'
          + '<th style="' + thS + 'right">Valor</th>'
          + '</tr></thead><tbody>';

    ranked.slice(0, 10).forEach(function(l, i) {
      var val = kpi.fn(l);
      var medal = i===0?'🥇':i===1?'🥈':i===2?'🥉':(i+1)+'.';
      var col = _reuPctColor(kpi.invert ? (val<=0?110:val<1?100:val<2?85:0) : null, false);
      html += '<tr style="background:' + (i%2===0?'var(--bg)':'var(--s2)') + '">'
            + '<td style="' + td + 'center;font-weight:700">' + medal + '</td>'
            + '<td style="' + td + 'left;font-size:10px;max-width:120px;overflow:hidden;text-overflow:ellipsis">'
            + '<span style="font-family:monospace;font-size:9px;color:var(--t3)">' + l.c + '</span> ' + escHtml(l.n) + '</td>'
            + '<td style="' + td + 'left;font-size:9px;color:var(--t3);max-width:80px;overflow:hidden;text-overflow:ellipsis">' + escHtml(l.sup.split(' ').slice(0,2).join(' ')) + '</td>'
            + '<td style="' + td + 'right;font-weight:700">' + _reuFmt(val, kpi.fmt) + '</td>'
            + '</tr>';
    });

    html += '</tbody></table></div>';
  });

  html += '</div>';
  body.innerHTML = html;
}

})(); // end IIFE


// ══════════════════════════════════════════════════════════════════════════════
// EXPORTAR VS OBJECTIVOS PARA PDF
// ══════════════════════════════════════════════════════════════════════════════
window.vsobjExportPDF = function() {
  // 1. Verificar PIN
  var pin = prompt('Introduza o PIN de administrador para exportar o relatório:');
  if (pin === null) return;
  if (!_checkAdminPin(pin)) {
    alert('PIN incorrecto. Acesso negado.');
    return;
  }

  // 2. Verificar se há conteúdo
  var content = document.getElementById('kpi-obj-content');
  if (!content || !AS) {
    alert('Seleccione uma loja antes de exportar.');
    return;
  }

  var btn = document.getElementById('vsobj-export-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ A gerar...'; }

  // 3. Gerar HTML do relatório para impressão
  var lojaName = (DB[AS] && DB[AS].n) || AS;
  var now = new Date();
  var mesLabel = window._admSelectedMes
    ? ((ADMCFG.mes_labels && ADMCFG.mes_labels[window._admSelectedMes]) || window._admSelectedMes)
    : (now.toLocaleString('pt-PT', {month:'long', year:'numeric'}));
  var exportDate = now.toLocaleDateString('pt-PT', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit'});

  // Clonar conteúdo
  var clone = content.cloneNode(true);
  // Remover botões e elementos interactivos
  clone.querySelectorAll('button, input, select, [onclick]').forEach(function(el){ el.removeAttribute('onclick'); if(el.tagName==='BUTTON') el.style.display='none'; });

  var printHTML = '<!DOCTYPE html><html lang="pt"><head><meta charset="UTF-8">'
    + '<title>Vs Objectivos — ' + lojaName + ' — ' + mesLabel + '</title>'
    + '<style>'
    + '* { box-sizing: border-box; margin: 0; padding: 0; }'
    + 'body { font-family: Inter, Arial, sans-serif; font-size: 11px; color: #1a1a2e; background: #fff; padding: 20px; }'
    + '.print-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 2px solid #5030a0; }'
    + '.print-header h1 { font-size: 18px; font-weight: 700; color: #5030a0; }'
    + '.print-header .meta { font-size: 10px; color: #666; text-align: right; line-height: 1.6; }'
    + '.print-footer { margin-top: 20px; padding-top: 10px; border-top: 1px solid #e0e0e0; font-size: 9px; color: #999; text-align: center; }'
    + 'h2 { font-size: 14px; font-weight: 700; color: #1a1a2e; margin: 16px 0 8px; }'
    + 'h3 { font-size: 12px; font-weight: 600; color: #444; margin: 12px 0 6px; }'
    + 'table { width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 10px; }'
    + 'th { background: #f0ebff; color: #5030a0; font-weight: 700; padding: 5px 8px; text-align: left; border: 1px solid #d8cfff; font-size: 9px; text-transform: uppercase; }'
    + 'td { padding: 5px 8px; border: 1px solid #e8e8e8; }'
    + 'tr:nth-child(even) td { background: #fafafa; }'
    + '.card-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin: 12px 0; }'
    + '.card { border: 1px solid #e0e0e0; border-radius: 6px; padding: 10px 12px; background: #fafafa; }'
    + '.card-label { font-size: 8px; text-transform: uppercase; color: #888; font-weight: 600; letter-spacing: .05em; }'
    + '.card-val { font-size: 16px; font-weight: 700; color: #1a1a2e; margin: 3px 0 2px; }'
    + '.card-obj { font-size: 9px; color: #888; }'
    + '.card-pct { font-size: 11px; font-weight: 700; }'
    + '.green { color: #16a34a; } .red { color: #dc2626; } .amber { color: #d97706; }'
    + '.ranking-card { border: 1px solid #e0e0e0; border-radius: 8px; padding: 12px; margin: 6px 0; }'
    + '.medal { font-size: 18px; }'
    + '@media print { body { padding: 10px; } .no-print { display: none; } }'
    + '</style></head><body>'
    + '<div class="print-header">'
    + '<div><div style="font-size:11px;color:#888;margin-bottom:4px">🤝 Karta · Retail Intelligence</div>'
    + '<h1>' + escHtml(lojaName) + ' — Vs Objectivos</h1>'
    + '<div style="font-size:12px;color:#5030a0;font-weight:600;margin-top:4px">' + mesLabel + '</div></div>'
    + '<div class="meta">Exportado em ' + exportDate + '<br>Confidencial — Uso Interno</div>'
    + '</div>'
    + clone.innerHTML
    + '<div class="print-footer">Karta Retail Intelligence · ' + exportDate + ' · ' + escHtml(lojaName) + ' · ' + mesLabel + '</div>'
    + '</body></html>';

  // 4. Abrir janela de impressão
  var win = window.open('', '_blank', 'width=900,height=700');
  if (!win) {
    alert('O browser bloqueou a janela de impressão. Permita pop-ups para este site.');
    if (btn) { btn.disabled = false; btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Exportar PDF'; }
    return;
  }
  win.document.write(printHTML);
  win.document.close();
  win.onload = function() {
    setTimeout(function() {
      win.focus();
      win.print();
    }, 400);
  };

  if (btn) { btn.disabled = false; btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Exportar PDF'; }
};


// ══════════════════════════════════════════════════════════════════════════════
// EXPORTAR RANKING SUPERVISORES PARA PDF
// ══════════════════════════════════════════════════════════════════════════════
window.suprankExportPDF = function() {
  // 1. Verificar PIN
_adminPinPrompt('Exportar Ranking Supervisores', function(ok) {
  if (!ok) return;
  var contentEl = document.getElementById('suprank-content');
  if (!contentEl || !contentEl.innerHTML.trim()) {
    alert('Sem dados para exportar. Aguarde a sincronização.');
    return;
  }

  var btn = document.getElementById('suprank-export-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ A gerar...'; }

  // 2. Metadados
  var mesEl = document.getElementById('suprank-mes');
  var mesVal = mesEl ? mesEl.value : '';
  var mesLabel = (ADMCFG.mes_labels && ADMCFG.mes_labels[mesVal]) || mesVal || 'Todos os meses';
  var exportDate = new Date().toLocaleDateString('pt-PT', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit'});

  // 3. Clonar conteúdo
  var clone = contentEl.cloneNode(true);
  clone.querySelectorAll('button,[onclick]').forEach(function(el){ el.removeAttribute('onclick'); if(el.tagName==='BUTTON') el.style.display='none'; });

  // 4. Construir CSS de impressão inspirado no design da app
  var css = [
    '* { box-sizing: border-box; margin: 0; padding: 0; }',
    'body { font-family: Inter, Arial, sans-serif; font-size: 11px; color: #1a1a2e; background: #fff; padding: 20px; }',
    /* Header */
    '.print-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 3px solid #1a4a8a; }',
    '.print-header h1 { font-size: 20px; font-weight: 700; color: #1a4a8a; }',
    '.print-header .sub { font-size: 11px; color: #666; margin-top: 4px; }',
    '.print-header .meta { font-size: 10px; color: #888; text-align: right; line-height: 1.7; }',
    /* Supervisor cards */
    '.sup-cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin: 14px 0; }',
    '.sup-card { border: 1px solid #e0e0e0; border-radius: 8px; padding: 12px 14px; }',
    '.sup-card .score { font-size: 22px; font-weight: 800; color: #1a4a8a; float: right; }',
    '.sup-card .name { font-size: 12px; font-weight: 700; color: #1a1a2e; clear: both; }',
    '.sup-card .lojas { font-size: 10px; color: #888; margin-top: 2px; }',
    '.sup-card .pos { font-size: 10px; color: #888; }',
    /* KPI ranking tables */
    '.kpi-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin: 14px 0; }',
    '.kpi-block { border: 1px solid #e0e0e0; border-radius: 6px; overflow: hidden; }',
    '.kpi-block-title { background: #f5f8ff; padding: 7px 10px; font-size: 10px; font-weight: 700; color: #1a4a8a; text-transform: uppercase; letter-spacing: .04em; display: flex; justify-content: space-between; }',
    '.kpi-block-title .peso { font-weight: 400; color: #888; }',
    'table { width: 100%; border-collapse: collapse; font-size: 10px; }',
    'th { background: #f5f8ff; color: #1a4a8a; font-weight: 700; padding: 5px 8px; text-align: left; border-bottom: 1px solid #dde4f0; font-size: 9px; }',
    'td { padding: 5px 8px; border-bottom: 1px solid #f0f0f0; }',
    'tr:last-child td { border-bottom: none; }',
    '.bar-pos { color: #16a34a; font-weight: 700; }',
    '.bar-neg { color: #dc2626; font-weight: 700; }',
    '.bar-amb { color: #d97706; font-weight: 700; }',
    '.print-footer { margin-top: 24px; padding-top: 10px; border-top: 1px solid #e8e8e8; font-size: 9px; color: #aaa; text-align: center; }',
    /* CSS vars fallback */
    ':root { --green: #16a34a; --red: #dc2626; --amber: #d97706; --blue: #1d4ed8; --accent: #1a4a8a; }',
    /* Preserve coloured bars */
    '[style*="background:#16a34a"],[style*="background:var(--green"] { background: #16a34a !important; }',
    '[style*="background:#dc2626"],[style*="background:var(--red"] { background: #dc2626 !important; }',
    '[style*="background:#d97706"],[style*="background:var(--amber"] { background: #d97706 !important; }',
    '[style*="color:#16a34a"],[style*="color:var(--green"] { color: #16a34a !important; }',
    '[style*="color:#dc2626"],[style*="color:var(--red"] { color: #dc2626 !important; }',
    '[style*="color:#d97706"],[style*="color:var(--amber"] { color: #d97706 !important; }',
    '@media print { body { padding: 8px; } @page { margin: 1cm; } }',
  ].join('\n');

  var printHTML = '<!DOCTYPE html><html lang="pt"><head><meta charset="UTF-8">'
    + '<title>Ranking Supervisores — ' + mesLabel + '</title>'
    + '<style>' + css + '</style></head><body>'
    + '<div class="print-header">'
    + '<div><div style="font-size:10px;color:#888;margin-bottom:4px;font-weight:600;letter-spacing:.05em">KARTA · RETAIL INTELLIGENCE</div>'
    + '<h1>Ranking de Supervisores</h1>'
    + '<div class="sub">Vendas 25% · Pão 15% · Quebras 20% · Rutura 10% · 1ºPão 10% · ÚltPão 10% · Av.SM 10% · face a objectivos</div>'
    + '<div style="font-size:13px;color:#1a4a8a;font-weight:700;margin-top:6px">' + mesLabel + '</div></div>'
    + '<div class="meta">Exportado em ' + exportDate + '<br><span style="color:#dc2626;font-weight:600">Confidencial — Uso Interno</span></div>'
    + '</div>'
    + clone.outerHTML
    + '<div class="print-footer">Karta Retail Intelligence &nbsp;·&nbsp; ' + exportDate + ' &nbsp;·&nbsp; Ranking Supervisores &nbsp;·&nbsp; ' + mesLabel + '</div>'
    + '</body></html>';

  // 5. Abrir janela de impressão
  var win = window.open('', '_blank', 'width=1000,height=750');
  if (!win) {
    alert('O browser bloqueou a janela. Permita pop-ups para karta-retail.netlify.app.');
    if (btn) { btn.disabled=false; btn.innerHTML='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Exportar PDF'; }
    return;
  }
  win.document.write(printHTML);
  win.document.close();
  win.onload = function(){ setTimeout(function(){ win.focus(); win.print(); }, 400); };

  if (btn) { btn.disabled=false; btn.innerHTML='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Exportar PDF'; }
});
};


// ══════════════════════════════════════════════════════════════════════════════
// EXPORTAR RANKING GERENTES PARA PDF
// ══════════════════════════════════════════════════════════════════════════════
window.gerrankExportPDF = function() {
  _adminPinPrompt('Exportar Ranking Gerentes', function(_grok) {
  if (!_grok) return;
  var btn = document.getElementById('gerrank-export-btn');
  if (btn) { btn.disabled=true; btn.textContent='⏳ A gerar...'; }

  var resetBtn = function() {
    if (btn) { btn.disabled=false; btn.innerHTML='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Exportar PDF'; }
  };

  // Obter dados dos gerentes já calculados no DOM
  var sel = document.getElementById('gerrank-mes');
  var selVal = sel ? sel.value : '';
  var meses = rankingGetMeses(selVal);
  var isMulti = meses.length > 1;
  var label = isMulti ? ('Ano ' + selVal.split(':')[1]) : (ML_RANK[selVal]||selVal);
  var exportDate = new Date().toLocaleDateString('pt-PT', {day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});

  // Reconstruir gerData (reutilizar lógica de renderGerRanking)
  var gerMap = {};
  meses.forEach(function(mes){
    ADMCFG.lojas.filter(function(l){ return isLojaActiva(l.c, mes); }).forEach(function(l){
      var nome = gerenteDoMes(l.c, mes);
      if(!nome) return;
      if(!gerMap[nome]) gerMap[nome] = {nome:nome, lojasMeses:{}};
      if(!gerMap[nome].lojasMeses[l.c]) gerMap[nome].lojasMeses[l.c] = {c:l.c, n:l.n, meses:[]};
      gerMap[nome].lojasMeses[l.c].meses.push(mes);
    });
  });

  var gerData = Object.values(gerMap).map(function(gd){
    var lojaList = Object.values(gd.lojasMeses);
    var lojaActuals = lojaList.map(function(li){
      var agg = rankingAggregate(li.c, li.meses);
      var objVendas=[],objPao=[],objRutura=[],objQuebra=[],objH1=[],objHu=[],objAvsup=[],objAvsm=[];
      li.meses.forEach(function(mes){
        var obj=((window.ADM_DATA||{})[mes]||{})[li.c]||{};
        if(obj.venda) objVendas.push(parseFloat(obj.venda));
        if(obj.pao) objPao.push(parseFloat(obj.pao));
        if(obj.rutura) objRutura.push(parseFloat(obj.rutura));
        if(obj.quebra!=null&&obj.quebra!==''&&parseFloat(obj.quebra)!==0) objQuebra.push(parseFloat(obj.quebra));
        if(obj.h1pao) objH1.push(obj.h1pao);
        if(obj.hupao) objHu.push(obj.hupao);
        if(obj.avsup) objAvsup.push(parseFloat(obj.avsup));
        if(obj.avsm) objAvsm.push(parseFloat(obj.avsm));
      });
      function avg(a){return a.length?a.reduce(function(s,v){return s+v;},0)/a.length:null;}
      var obj={venda:avg(objVendas),pao:avg(objPao),rutura:avg(objRutura),quebra:avg(objQuebra),
               h1pao:objH1[0]||null,hupao:objHu[0]||null,avsup:avg(objAvsup),avsm:avg(objAvsm)};
      return {c:li.c, n:li.n, actuals:agg, obj:obj};
    }).filter(function(l){ return l.actuals&&l.actuals.venda!=null; });
    if(!lojaActuals.length) return null;
    function avgFn(fn){var vs=lojaActuals.map(fn).filter(function(v){return v!=null&&!isNaN(v);});return vs.length?vs.reduce(function(a,b){return a+b;},0)/vs.length:null;}
    function avgO(k){var vs=lojaActuals.map(function(l){return l.obj[k];}).filter(function(v){return v!=null&&!isNaN(v);});return vs.length?vs.reduce(function(a,b){return a+b;},0)/vs.length:null;}
    return {
      nome:gd.nome, n_lojas:lojaActuals.length, lojas:lojaActuals,
      actuals:{venda:avgFn(function(l){return l.actuals.venda;}),pao:avgFn(function(l){return l.actuals.pao;}),
               rutura:avgFn(function(l){return l.actuals.rutura;}),quebra:avgFn(function(l){return l.actuals.quebra;}),
               h1pao:lojaActuals[0]&&lojaActuals[0].actuals.h1pao||null,
               hupao:lojaActuals[0]&&lojaActuals[0].actuals.hupao||null,
               avsup:avgFn(function(l){return l.actuals.avsup;}),
               avsm:avgFn(function(l){return l.actuals.avsm;})},
      obj:{venda:avgO('venda'),pao:avgO('pao'),rutura:avgO('rutura'),quebra:avgO('quebra'),
           h1pao:lojaActuals[0]&&lojaActuals[0].obj.h1pao||null,
           hupao:lojaActuals[0]&&lojaActuals[0].obj.hupao||null,
           avsup:avgO('avsup'),avsm:avgO('avsm')}
    };
  }).filter(Boolean);

  if(!gerData.length){ alert('Sem dados de gerentes para exportar.'); resetBtn(); return; }

  // ── Calcular scores (reutilizar GER_WEIGHTS) ─────────────────────────────
  function calcScore(g) {
    var s=0, wt=0;
    Object.keys(GER_WEIGHTS).forEach(function(k){
      var w=GER_WEIGHTS[k], real=g.actuals[k], obj=g.obj[k];
      if(real==null||obj==null) return;
      var pct;
      if(typeof real==='string'&&typeof obj==='string'){
        var rm=timeToMinutes(real), om=timeToMinutes(obj);
        if(rm==null||om==null||om===0) return;
        pct = GER_RANK_INVERT[k] ? (om/rm)*100 : (rm/om)*100;
      } else {
        if(!obj||isNaN(obj)) return;
        pct = GER_RANK_INVERT[k] ? (obj<0?(real<=obj?100:Math.max(0,(1-(real-obj)/Math.abs(obj))*100)):(real===0?100:real<=obj?100:Math.max(0,obj/real*100))) : (obj===0?100:real/obj*100);
      }
      pct = Math.min(150, Math.max(0, pct));
      s += pct*w; wt += w;
    });
    return wt>0 ? Math.round(s/wt*10)/10 : null;
  }

  gerData.forEach(function(g){ g.score=calcScore(g); });
  gerData.sort(function(a,b){ return (b.score||0)-(a.score||0); });

  // ── Helpers de formatação ──────────────────────────────────────────────────
  function fmt(v, unit){
    if(v==null||isNaN(v)) return '—';
    if(unit==='aoa') return Math.round(v).toLocaleString('pt-AO')+' AOA';
    if(unit==='pct') return (typeof v==='number'?v.toFixed(2):v)+'%';
    if(unit==='h')   return typeof v==='string'?v:(Math.floor(v/60)+':'+String(Math.round(v%60)).padStart(2,'0'));
    if(unit==='un')  return Math.round(v)+' un/dia';
    if(unit==='av')  return (typeof v==='number'?v.toFixed(1):v)+'/10';
    return String(Math.round(v));
  }
  function pctCol(pct, invert){
    if(pct==null) return '#888';
    var good=invert?pct>=90:pct>=95, bad=invert?pct<80:pct<85;
    return good?'#16a34a':bad?'#dc2626':'#d97706';
  }
  function pctVal(real, obj, invert, unit){
    if(real==null||obj==null||obj===0) return null;
    var rm = (unit==='h'&&typeof real==='string') ? timeToMinutes(real) : real;
    var om = (unit==='h'&&typeof obj==='string')  ? timeToMinutes(obj)  : obj;
    if(rm==null||om==null||om===0) return null;
    return invert ? Math.round(om/rm*1000)/10 : Math.round(rm/om*1000)/10;
  }
  function scoreColor(s){
    if(s==null) return '#888';
    return s>=100?'#16a34a':s>=90?'#d97706':'#dc2626';
  }
  function medal(i){ return i===0?'🥇':i===1?'🥈':i===2?'🥉':(i+1)+'º'; }

  // ── CSS ───────────────────────────────────────────────────────────────────
  var css = [
    '*{box-sizing:border-box;margin:0;padding:0}',
    'body{font-family:Inter,Arial,sans-serif;font-size:11px;color:#1a1a2e;background:#fff;padding:20px}',
    'h1{font-size:20px;font-weight:800;color:#1a7040}',
    'h2{font-size:13px;font-weight:700;color:#1a1a2e;margin:18px 0 8px;border-bottom:2px solid #e0f0e8;padding-bottom:5px}',
    '.hdr{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:18px;padding-bottom:14px;border-bottom:3px solid #1a7040}',
    '.hdr-meta{font-size:10px;color:#888;text-align:right;line-height:1.7}',
    '.kpi-line{font-size:10px;color:#666;margin-top:3px}',
    /* Sumário table */
    'table{width:100%;border-collapse:collapse;font-size:10px;margin:8px 0}',
    'th{background:#f0faf4;color:#1a7040;font-weight:700;padding:6px 8px;text-align:left;border-bottom:2px solid #c8e6d4;white-space:nowrap;font-size:9px}',
    'td{padding:5px 8px;border-bottom:1px solid #f0f0f0;vertical-align:middle}',
    'tr:last-child td{border-bottom:none}',
    'tr:nth-child(even) td{background:#fafffe}',
    '.score-cell{font-weight:800;font-size:13px}',
    '.rank-num{font-weight:700;color:#888;width:28px}',
    '.medal-num{font-size:14px}',
    /* Top 3 banner */
    '.top3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin:12px 0 20px}',
    '.top3-card{border-radius:10px;padding:14px;text-align:center}',
    '.top3-card.gold{background:#fffbeb;border:2px solid #f59e0b}',
    '.top3-card.silver{background:#f8faff;border:2px solid #94a3b8}',
    '.top3-card.bronze{background:#fff7f3;border:2px solid #c2855a}',
    '.top3-name{font-size:12px;font-weight:700;margin:6px 0 2px}',
    '.top3-score{font-size:24px;font-weight:900}',
    '.top3-lojas{font-size:9px;color:#888}',
    /* Detalhe gerente */
    '.ger-block{break-inside:avoid;border:1px solid #e0e0e0;border-radius:10px;padding:14px;margin-bottom:14px}',
    '.ger-header{display:flex;align-items:center;gap:12px;margin-bottom:10px}',
    '.ger-pos{font-size:18px;font-weight:900;color:#888;min-width:28px}',
    '.ger-name{font-size:14px;font-weight:700;color:#1a1a2e;flex:1}',
    '.ger-score{font-size:22px;font-weight:900}',
    '.ger-lojas{font-size:10px;color:#888;margin-top:1px}',
    '.kpi-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:8px}',
    '.kpi-card{border:1px solid #e8e8e8;border-radius:6px;padding:7px 9px;background:#fafafa}',
    '.kpi-label{font-size:8px;text-transform:uppercase;color:#888;font-weight:700;letter-spacing:.04em}',
    '.kpi-val{font-size:13px;font-weight:800;margin:3px 0 1px}',
    '.kpi-obj{font-size:9px;color:#aaa}',
    '.kpi-pct{font-size:10px;font-weight:700}',
    '.loja-row{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}',
    '.loja-chip{font-size:9px;background:#f0faf4;border:1px solid #c8e6d4;border-radius:4px;padding:2px 7px;color:#1a7040;font-weight:600}',
    '.footer{margin-top:20px;padding-top:10px;border-top:1px solid #e0e0e0;font-size:9px;color:#aaa;text-align:center}',
    '.page-break{page-break-before:always}',
    '@media print{body{padding:8px}@page{margin:1cm}th,td{border-color:#e0e0e0!important}.ger-block{break-inside:avoid}}'
  ].join('\n');

  // ── Página 1: sumário ─────────────────────────────────────────────────────
  var kpiDefs = [
    {k:'venda', label:'Vendas', unit:'aoa', invert:false, w:'25%'},
    {k:'pao',   label:'Pão',   unit:'un',  invert:false, w:'15%'},
    {k:'quebra',label:'Quebra',unit:'pct', invert:true,  w:'20%'},
    {k:'rutura',label:'Rutura',unit:'pct', invert:true,  w:'10%'},
    {k:'h1pao', label:'1ºPão', unit:'h',   invert:true,  w:'10%'},
    {k:'hupao', label:'ÚltPão',unit:'h',   invert:false, w:'10%'},
    {k:'avsup', label:'Av.Sup',unit:'av',  invert:false, w:'5%'},
    {k:'avsm',  label:'Av.SM', unit:'av',  invert:false, w:'5%'},
  ];

  // Top 3
  var top3HTML = '<div class="top3">';
  [0,1,2].forEach(function(i){
    var g = gerData[i]; if(!g) return;
    var cls = i===0?'gold':i===1?'silver':'bronze';
    var sc = g.score!=null ? g.score.toFixed(1) : '—';
    top3HTML += '<div class="top3-card '+cls+'">'
      +'<div style="font-size:22px">'+medal(i)+'</div>'
      +'<div class="top3-name">'+escHtml(g.nome)+'</div>'
      +'<div class="top3-score" style="color:'+scoreColor(g.score)+'">'+sc+'%</div>'
      +'<div class="top3-lojas">'+g.n_lojas+' loja'+(g.n_lojas>1?'s':'')+'</div>'
      +'</div>';
  });
  top3HTML += '</div>';

  // Tabela sumário
  var summaryTable = '<table><thead><tr>'
    +'<th>#</th><th>Gerente</th><th>Lojas</th><th>Score</th>'
    + kpiDefs.map(function(k){ return '<th>'+k.label+'<br><span style="font-weight:400;color:#888">'+k.w+'</span></th>'; }).join('')
    +'</tr></thead><tbody>';

  gerData.forEach(function(g, i){
    var sc = g.score!=null ? g.score.toFixed(1) : '—';
    var lojaNames = g.lojas.map(function(l){ return l.c; }).join(', ');
    summaryTable += '<tr>'
      +'<td class="rank-num"><span class="medal-num">'+medal(i)+'</span></td>'
      +'<td style="font-weight:600">'+escHtml(g.nome)+'</td>'
      +'<td style="font-size:9px;color:#888">'+lojaNames+'</td>'
      +'<td class="score-cell" style="color:'+scoreColor(g.score)+'">'+sc+'%</td>';
    kpiDefs.forEach(function(kd){
      var real=g.actuals[kd.k], obj=g.obj[kd.k];
      var pct=pctVal(real,obj,kd.invert,kd.unit);
      var col=pct!=null?pctCol(pct,kd.invert):'#888';
      summaryTable += '<td style="color:'+col+';font-weight:'+(pct!=null?'700':'400')+'">'+fmt(real,kd.unit)
        +(pct!=null?'<br><span style="font-size:9px">'+pct+'%</span>':'')+'</td>';
    });
    summaryTable += '</tr>';
  });
  summaryTable += '</tbody></table>';

  // ── Página 2+: detalhe por gerente (4 por página) ────────────────────────
  var detailHTML = '<div class="page-break"><h2>Detalhe por Gerente</h2>';
  gerData.forEach(function(g, i){
    var sc = g.score!=null?g.score.toFixed(1):'—';
    var lojaChips = g.lojas.map(function(l){
      return '<span class="loja-chip">'+l.c+' — '+escHtml(l.n)+'</span>';
    }).join('');

    var kpiCards = kpiDefs.map(function(kd){
      var real=g.actuals[kd.k], obj=g.obj[kd.k];
      var pct=pctVal(real,obj,kd.invert,kd.unit);
      var col=pct!=null?pctCol(pct,kd.invert):'#888';
      return '<div class="kpi-card">'
        +'<div class="kpi-label">'+kd.label+' <span style="color:#bbb">('+kd.w+')</span></div>'
        +'<div class="kpi-val" style="color:'+col+'">'+fmt(real,kd.unit)+'</div>'
        +(obj!=null?'<div class="kpi-obj">Obj: '+fmt(obj,kd.unit)+'</div>':'')
        +(pct!=null?'<div class="kpi-pct" style="color:'+col+'">'+pct+'%</div>':'')
        +'</div>';
    }).join('');

    detailHTML += '<div class="ger-block">'
      +'<div class="ger-header">'
      +'<span class="ger-pos">'+medal(i)+'</span>'
      +'<div><div class="ger-name">'+escHtml(g.nome)+'</div>'
      +'<div class="ger-lojas">'+g.n_lojas+' loja'+(g.n_lojas>1?'s':'')+'</div></div>'
      +'<span class="ger-score" style="color:'+scoreColor(g.score)+'">'+sc+'%</span>'
      +'</div>'
      +'<div class="kpi-grid">'+kpiCards+'</div>'
      +'<div class="loja-row">'+lojaChips+'</div>'
      +'</div>';
  });
  detailHTML += '</div>';

  var printHTML = '<!DOCTYPE html><html lang="pt"><head><meta charset="UTF-8">'
    +'<title>Ranking Gerentes — '+label+'</title>'
    +'<style>'+css+'</style></head><body>'
    +'<div class="hdr">'
    +'<div><div style="font-size:10px;color:#888;font-weight:700;letter-spacing:.06em;margin-bottom:3px">KARTA · RETAIL INTELLIGENCE</div>'
    +'<h1>Ranking de Gerentes</h1>'
    +'<div class="kpi-line">Vendas 25% · Pão 15% · Quebras 20% · Rutura 10% · 1ºPão 10% · ÚltPão 10% · Av.Sup 5% · Av.SM 5% · face a objectivos</div>'
    +'<div style="font-size:14px;font-weight:700;color:#1a7040;margin-top:6px">'+label+'</div></div>'
    +'<div class="hdr-meta">Exportado em '+exportDate+'<br><span style="color:#dc2626;font-weight:600">Confidencial — Uso Interno</span></div>'
    +'</div>'
    +'<h2>Sumário Executivo — '+gerData.length+' Gerentes</h2>'
    +top3HTML
    +summaryTable
    +detailHTML
    +'<div class="footer">Karta Retail Intelligence &nbsp;·&nbsp; '+exportDate+' &nbsp;·&nbsp; Ranking Gerentes &nbsp;·&nbsp; '+label+'</div>'
    +'</body></html>';

  var win = window.open('', '_blank', 'width=1100,height=800');
  if(!win){ alert('O browser bloqueou a janela. Permita pop-ups para karta-retail.netlify.app.'); resetBtn(); return; }
  win.document.write(printHTML);
  win.document.close();
  win.onload = function(){ setTimeout(function(){ win.focus(); win.print(); }, 500); };
  resetBtn();
});
};

// [object Object] workaround removido — causa raiz corrigida em supAnswerDisplayHTML e supHistRender



// ── RELATÓRIO DE CONTAGENS ────────────────────────────────────────────────────
window.dcgRelSetDay = function(offset) {
  var d = new Date(); d.setDate(d.getDate() + offset);
  var el = document.getElementById('dcg-rel-date');
  if (el) { el.value = d.toISOString().split('T')[0]; dcgRelContRender(); }
};

window.dcgRelContRender = function() {
  var body = document.getElementById('dcg-rel-body');
  if (!body) return;

  // Init date
  var dateEl = document.getElementById('dcg-rel-date');
  var today = new Date().toISOString().split('T')[0];
  if (dateEl && !dateEl.value) dateEl.value = today;
  var date = (dateEl && dateEl.value) || today;

  var contData = window.CONT_DATA || {};
  var lojas = (window.ADMCFG && ADMCFG.lojas) || [];

  // Se CONT_DATA vazio, disparar sync automático
  var hasContData = Object.keys(contData).length > 0;
  if (!hasContData && window.fbSyncContagens) {
    body.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);font-size:12px">⏳ A carregar contagens…</div>';
    window.fbSyncContagens(30).then(function() {
      window.dcgRelContRender();
    }).catch(function() {
      body.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);font-size:12px">Sem dados de contagens. Clica em ↻ Sync Contagens.</div>';
    });
    return;
  }

  if (!lojas.length) {
    body.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);font-size:12px">Sem lojas configuradas. Importa o backup JSON primeiro.</div>';
    return;
  }
  var cfg = window.CONT_CFG || {};
  var artigos = (cfg.artigos && cfg.artigos.length) ? cfg.artigos : [];
  var lojas = (window.ADMCFG && ADMCFG.lojas) || [];
  var TURNOS = ['manha', 'tarde', 'noite'];
  var TURNO_LABELS = { manha: 'Manhã', tarde: 'Tarde', noite: 'Noite' };
  var _supMap = window.LOJA_SUPERVISORES || {};

  var dateData = contData[date] || {};

  var lines = []; // para relatório texto (email)
  var html = [];

  var dateFormatted = date.split('-').reverse().join('/');
  html.push('<div style="font-size:13px;font-weight:700;color:var(--tx);margin-bottom:16px">Relatório de Contagens · ' + dateFormatted + '</div>');
  lines.push('RELATÓRIO DE CONTAGENS — ' + dateFormatted);
  lines.push('');

  var lojasSemDados = [], lojasComDados = [];

  lojas.forEach(function(l) {
    var lojaData = dateData[l.c] || {};
    var turnosFilled = TURNOS.filter(function(t) { return lojaData[t]; });
    var sup = (_supMap[l.c] && _supMap[l.c].sup) || l.s || '';
    if (turnosFilled.length === 0) {
      lojasSemDados.push({ c: l.c, n: l.n, sup: sup });
    } else {
      lojasComDados.push({ c: l.c, n: l.n, sup: sup, lojaData: lojaData, turnosFilled: turnosFilled });
    }
  });

  // ── Lojas COM contagens ──
  lojasComDados.forEach(function(l) {
    var lojaData = l.lojaData;
    var turnosFilled = l.turnosFilled;
    var missing3 = turnosFilled.length < 3;

    // Agregar diferenças por artigo (soma de todos os turnos)
    var artDifs = {};
    turnosFilled.forEach(function(turno) {
      var td = lojaData[turno] || {};
      var val = td.value || td;
      Object.keys(val).forEach(function(k) {
        if (k === '_x_ts_x_') return;
        var entry = val[k];
        if (typeof entry === 'object' && entry !== null) {
          var qtd = entry.qtd != null ? entry.qtd : (entry.q != null ? entry.q : null);
          var exp = entry.expected != null ? entry.expected : (entry.e != null ? entry.e : null);
          if (qtd != null && exp != null) {
            var dif = qtd - exp;
            if (!artDifs[k]) artDifs[k] = { desc: entry.desc || entry.d || k, dif: 0, n: 0 };
            artDifs[k].dif += dif;
            artDifs[k].n++;
          }
        }
      });
    });

    // Artigos com diferença ≠ 0
    var difKeys = Object.keys(artDifs).filter(function(k) { return artDifs[k].dif !== 0; });
    difKeys.sort(function(a, b) { return artDifs[a].dif - artDifs[b].dif; });

    var hasDif = difKeys.length > 0;
    var borderCol = hasDif ? 'var(--red)' : 'var(--green)';
    var statusIcon = hasDif ? '⚠️' : '✅';

    html.push('<div style="border:1px solid var(--bd);border-left:3px solid ' + borderCol + ';border-radius:8px;padding:12px 16px;margin-bottom:10px">');
    html.push('<div style="display:flex;align-items:baseline;gap:8px;margin-bottom:6px">');
    html.push('<span style="font-size:10px;color:var(--t3)">' + l.c + '</span>');
    html.push('<span style="font-size:13px;font-weight:700;color:var(--tx)">' + l.n + '</span>');
    if (sup) html.push('<span style="font-size:10px;color:var(--t3)">· ' + sup + '</span>');
    html.push('<span style="margin-left:auto;font-size:11px">' + statusIcon);
    if (missing3) html.push(' <span style="color:var(--amber);font-size:10px">(apenas ' + turnosFilled.map(function(t){return TURNO_LABELS[t];}).join(', ') + ')</span>');
    html.push('</span></div>');

    // Texto para email
    lines.push(l.c + ' · ' + l.n + (sup ? ' [' + sup + ']' : ''));
    if (missing3) lines.push('  ⚠️ Realizou apenas: ' + turnosFilled.map(function(t){return TURNO_LABELS[t];}).join(', '));

    if (!hasDif) {
      html.push('<div style="font-size:11px;color:var(--green)">Sem diferenças</div>');
      lines.push('  ✅ Sem diferenças');
    } else {
      html.push('<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:4px">');
      difKeys.forEach(function(k) {
        var a = artDifs[k];
        var col = a.dif < 0 ? 'var(--red)' : 'var(--green)';
        var sign = a.dif > 0 ? '+' : '';
        html.push('<span style="font-size:11px;padding:2px 8px;border-radius:12px;background:var(--s2);color:' + col + ';font-weight:600">' + a.desc + ' ' + sign + a.dif + '</span>');
        lines.push('  ' + a.desc + ': ' + sign + a.dif);
      });
      html.push('</div>');
    }
    html.push('</div>');
    lines.push('');
  });

  // ── Lojas SEM contagens ──
  if (lojasSemDados.length > 0) {
    html.push('<div style="margin-top:8px;margin-bottom:6px;font-size:10px;font-weight:700;color:var(--amber);text-transform:uppercase;letter-spacing:.06em">⚠️ Lojas sem contagem (' + lojasSemDados.length + ')</div>');
    html.push('<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px">');
    lines.push('');
    lines.push('LOJAS SEM CONTAGEM (' + lojasSemDados.length + '):');
    lojasSemDados.forEach(function(l) {
      html.push('<span style="font-size:11px;padding:3px 10px;border-radius:12px;background:rgba(245,158,11,.1);color:var(--amber);border:1px solid var(--amber)">' + l.c + ' · ' + l.n + '</span>');
      lines.push('  ❌ ' + l.c + ' · ' + l.n + (l.sup ? ' [' + l.sup + ']' : '') + ' — Não realizou contagem');
    });
    html.push('</div>');
  }

  if (lojas.length === 0) {
    body.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);font-size:12px">Sem lojas configuradas.</div>';
    return;
  }

  body.innerHTML = html.join('');
  window._dcgRelLines = lines;
  window._dcgRelDate = date;
};

window.dcgRelEmail = function() {
  var lines = window._dcgRelLines;
  var date = window._dcgRelDate || new Date().toISOString().split('T')[0];
  if (!lines || !lines.length) { dcgRelContRender(); lines = window._dcgRelLines; }
  if (!lines || !lines.length) { alert('Gera o relatório primeiro.'); return; }
  var subject = encodeURIComponent('Relatório Contagens Diárias — ' + date.split('-').reverse().join('/'));
  var body = encodeURIComponent(lines.join('\n'));
  window.location.href = 'mailto:?subject=' + subject + '&body=' + body;
};
