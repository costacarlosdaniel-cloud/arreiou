// netlify/functions/drive-proxy.js
// Proxy para download de imagens do Google Drive + Vision OCR
// Corre no servidor — sem problemas de CORS

const GDRIVE_API_KEY = process.env.GDRIVE_API_KEY;

exports.handler = async function(event) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  // preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { fileId, mimeType } = JSON.parse(event.body || '{}');
    if (!fileId) return { statusCode: 400, headers, body: JSON.stringify({ error: 'fileId em falta' }) };

    const apiKey = GDRIVE_API_KEY;
    if (!apiKey) return { statusCode: 500, headers, body: JSON.stringify({ error: 'GDRIVE_API_KEY não configurada' }) };

    // ── 1. Download da imagem via Drive API (servidor não tem CORS) ──
    const dlUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media&key=${apiKey}`;
    const dlRes = await fetch(dlUrl);
    if (!dlRes.ok) throw new Error(`Drive download falhou: ${dlRes.status}`);

    const arrayBuf = await dlRes.arrayBuffer();
    const b64      = Buffer.from(arrayBuf).toString('base64');
    const mime     = mimeType || dlRes.headers.get('content-type') || 'image/png';

    // ── 2. Vision OCR ──
    const visionUrl = `https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`;
    const visionRes = await fetch(visionUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        requests: [{
          image: { content: b64 },
          features: [{ type: 'TEXT_DETECTION', maxResults: 1 }]
        }]
      })
    });

    if (!visionRes.ok) throw new Error(`Vision API falhou: ${visionRes.status}`);
    const visionData = await visionRes.json();
    const ann = visionData.responses?.[0];
    if (ann?.error) throw new Error(`Vision: ${ann.error.message}`);

    // devolve as anotações de texto ao browser para parsing
    return {
      statusCode: 200,
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ textAnnotations: ann?.textAnnotations || [] })
    };

  } catch(e) {
    console.error('drive-proxy erro:', e.message);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: e.message })
    };
  }
};
